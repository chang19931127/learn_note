package me.czd.test.ioc.lookup;

import org.springframework.beans.factory.annotation.Lookup;

import me.czd.test.bean.Car;

/**
 * 
 * @author 43994897
 *	这里为什么定义一个接口，
 *										为了满足一个需求，
 *													需求是，我们要通过配制来为接口提供动态实现
 *																		让gatCar()接口方法每次都返回新的Car Bean。
 *
 *---------------------大环境是，我们有一个Boss bean  是单例的      
 *																	 因此我们的Boss bean中的getCar()返回的也是单例的	，那个最开始被注入的
 *																		即使我们的Car是prototype
 *
 *								因此我们通过Lookup解决方式来解决这个，我们自己整一个接口，然后通过配制来动态实现
 *																		然后通过这个getCar()来返回不同的prototype
 *
 */
public interface MagicBoss {
	@Lookup("car")
	Car getCar();
}
