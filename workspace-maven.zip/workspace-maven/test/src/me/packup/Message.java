package me.packup;

import java.io.PrintStream;

public class Message {
	private String m_text;
	public Message(String text){
		m_text=text;
	}
	public void print(PrintStream ps){
		ps.print(m_text);
	}
}
