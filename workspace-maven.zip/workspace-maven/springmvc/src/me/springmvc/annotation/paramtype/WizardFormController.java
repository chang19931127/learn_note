package me.springmvc.annotation.paramtype;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import me.springmvc.annotation.model.UserModel;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.util.WebUtils;

/*
 * 表单向导Controller
 */
@Controller
@RequestMapping("/wizard")
@SessionAttributes(value={"user"})
//标示模型对象中名字如果是user的存储到会话中，并自动暴露到模型数据中
public class WizardFormController {
		
	public static final String PARAM_TARGET="_target";//下一页
	public static final String PARAM_PAGE="_page";//当前页面
	
	//这里面，我们在配制文件中进行了依赖注入
	private String[] pageViews;//分步骤试图
	private String successView;//成功视图
	private String cancelView;//取消试图
	public void setPageViews(String[] pageViews) {
		this.pageViews = pageViews;
	}
	public void setSuccessView(String successView) {
		this.successView = successView;
	}
	public void setCancelView(String cancelView) {
		this.cancelView = cancelView;
	}
	
	//得到目标页码-----即下一个页码
	public int getTargetPage(HttpServletRequest request,int currentPage){
		return WebUtils.getTargetPage(request, PARAM_TARGET, currentPage);
	}
	
	@ModelAttribute("user")
	//如果模型数据中没有名字为user的对象，则调用该方法并存储到模型数据中
	public UserModel initUser(){
		UserModel user = new UserModel();
		user.setUsername("Richard");
		user.setRealname("chang");
		return user;
	}
		
	@ModelAttribute
	//返回值为void将不暴露表单引用数据到模型数据
	public void referenceData(@RequestParam(value="_page",defaultValue="0")int currentPage,HttpServletRequest request,Map<String, List<String>> model){
		if(getTargetPage(request, currentPage) == 1){
			model.put("schoolTypeList", Arrays.asList("高中","中专","大学"));
		}
		if(getTargetPage(request, currentPage) == 2){
			model.put("cityList", Arrays.asList("济南","北京","上海"));
		}
	}
	
	@RequestMapping(params={"!_finish","!_cancel"})
	public String form(HttpServletRequest request,@RequestParam(value="_page",defaultValue="0")int currentPage,@ModelAttribute("user")UserModel user){
		System.out.println(pageViews);
		System.out.println(successView);
		System.out.println(cancelView);
		return pageViews[getTargetPage(request, currentPage)];
	}
	
	@RequestMapping(params="_cancel")
	public String cancel(UserModel user,SessionStatus status){
		System.out.println(user);
		status.setComplete();//清空session
		return cancelView;
	}
	
	@RequestMapping(params="_finish")
	public String finish(@ModelAttribute("user")UserModel user,SessionStatus status){
		System.out.println(user);
		status.setComplete();
		return successView;
	}
}
