package com.example.demo.datajpa;

import java.util.List;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;

/**
 * 这里使用了 配置类 生成bean ApplicationRunner和CommandLineRunner的区别
 * 
 * CommondLineRunner 会在ApplicationRunner run之后，然后clr 在进行run
 * f you need to run some specific code once
 * run 一些特殊的代码，例如我们这里是  使用的h2 的内嵌式方式的数据库，也就是数据库中没有内容
 * 我们需要向里面加入内容，那么就可以使用  CommondLineRunner来进行预处理
 * 
 * @author 43994897
 *
 */
@Configuration
public class JpaConfig {

    //也就是我们可以通过CommandLineRunner 来进行一些操作的提前执行
    @Bean
    public CommandLineRunner jpaDemo(PersonRepository repository) {
	// lambda 表达式，其实就是run 方法 匿名类
	return (args) -> {
	    // 加入数据
	    System.out.println("添加数据 save()");
	    repository.save(new Person("jack", 18, "北京"));
	    repository.save(new Person("park", 19, "上海"));
	    repository.save(new Person("james", 18, "深圳"));
	    repository.save(new Person("david", 18, "广州"));
	    repository.save(new Person("duke", 18, "澳门"));
	    System.out.println("***************************************");

	    System.out.println("通过地址查找 findByAddress()");
	    List<Person> persons = repository.findByAddress("北京");
	    System.out.println(persons);
	    System.out.println("***************************************");

	    System.out.println("通过name 和address 查找findByNameAndAddress()");
	    Person person = repository.findByNameAndAddress("james", "深圳");
	    System.out.println(person);
	    System.out.println("***************************************");


	    System.out.println("测试排序");
	    persons = repository.findAll(new Sort(Direction.ASC, "age"));
	    System.out.println(persons);
	    System.out.println("***************************************");

	    System.out.println("测试分页");
	    Page<Person> pagePersons = repository.findAll(new PageRequest(1, 2));
	    System.out.println(pagePersons);
	    System.out.println("***************************************");
	};
    }
}
