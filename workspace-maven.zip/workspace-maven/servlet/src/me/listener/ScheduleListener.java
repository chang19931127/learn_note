package me.listener;

import java.util.Date;
import java.util.Timer;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

/**
 * Application Lifecycle Listener implementation class ScheduleListener
 * Listener介绍
 * 				Listener的作用就是一个监听器，Web应用启动时，启动某些后台程序。
 * 				使用Listener只需要两个步骤，
 * 												1，创建Listener实现类
 * 												2，在web.xml文件中配置Listener
 * 				有很多Listener接口，需要哪个就去实现哪个
 *				ServletContextListener     context监听器       启动应用调用 contextInitialized()方法  关闭应用调用contextDesotry()方法
 *	需要配置 xml中
 *	<listener>
 *		<listener-class>me.listener.ScheduleListener</listener-class>
 *	</listener>
 *我们使用的注解
 */
@WebListener
public class ScheduleListener implements ServletContextListener {
	
	//计时器来作为人物调度
	private Timer timer = null;
	
    public ScheduleListener() {
    }

    public void contextInitialized(ServletContextEvent sce) {
    	timer = new Timer(true);
    	sce.getServletContext().log(new Date() +"计时器已经启动。。。。");
    	sce.getServletContext().log(new Date() + "计时器已经启动。。。");
    	//调度任务 每4分钟执行一次
    	timer.schedule(new MyTask(), 0, 2*60*1000);
    	sce.getServletContext().log(new Date() + "计时器执行一次！！！");
    	sce.getServletContext().log(new Date() + "计时器执行一次！！！");
    }

    public void contextDestroyed(ServletContextEvent sce) {
    	timer.cancel();
    	sce.getServletContext().log(new Date() + "计时器被销毁！！！");
     	sce.getServletContext().log(new Date() + "计时器被销毁！！！");
    }
	
}
