package me.czd.test.bean;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * 
 * @author 43994897
 *	很显然这里是一个配置类，我们通过的是注解来进行Bean的注册
 *	这样就不需要配置文件了
 */

//1,表示这是一个配置信息提供类
@Configuration
public class Beans {
	//2，定义一个bean
	@Bean(name ="car")
	public Car buildCar(){
		Car car = new Car();
		car.setBrand("红旗");
		car.setMaxSpeed(200);
		return car;
	}
	
	public void test(){
		
	}
}
