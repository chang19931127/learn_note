package me.czd.test.ioc.lookup;

import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import me.czd.test.bean.Car;

//单例Boos
public class Boss {
	//不能邦定，邦定了就不符合我们的设计原则，框架和设计类联系到一起就麻烦了
	//private static ApplicationContext ac = new  ClassPathXmlApplicationContext("beanfactory/beans_lookup.xml");
	private Car car;
	
	public void setCar(Car car) {
		this.car = car;
	}
	
	public Car getCar(){
		return car;
	}
/*	
 * 
 * 其实通过下面的方也可以得到prototype Car，但是我们需要 分离框架，不能再这里 使用 Context
 * public Car getCar(){
 *			return (Car) ac.getBean("car");
 *	}
 */
	
	
	
	/*
	 * 其实 这里我们可以实现这个接口 ApplicationContextAware
	 * 	 就可以获得   ApplicationContext，然后就可以得到car
	 */
}
