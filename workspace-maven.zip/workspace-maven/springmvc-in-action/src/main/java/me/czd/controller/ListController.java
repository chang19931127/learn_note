package me.czd.controller;

import java.util.ArrayList;
import java.util.List;

import me.czd.entity.Userinfo;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

/**
 * 
 * @author 43994897 这里用来控制层返回List
 *         和实体，并通过配置，来进行转发到jsp页面，这样子相当于请求转发，数据也会放到request中
 *         ModelAndView>ModelMap>Model
 *         根据情况来选择使用
 */
@Controller
public class ListController {

	//stringList
	@RequestMapping(value = "listUserinfo")
	public List<String> listUserinfo() {
		List<String> listString = new ArrayList<>();
		for (int i = 0; i < 10; i++) {
			listString.add("username" + (i + 1));
		}
		return listString;
		/*
		 * 这里有几个要点 1，因为返回不是string，因此跳转jsp根据请求的路径去寻找 2，因为是转发，因此数据也会跟着传送，
		 * 因此listString这个数据会被存到默认stringList(List中存放的String
		 * 默认的)中放入到request中，可以使用@ModelAttribute来指定
		 */
	}

	//userinfo
	//其实这两个都是将参数放到了Model中 并且key值是默认的命名
	@RequestMapping(value = "getUserinfo")
	public Userinfo getUserinfo() {
		Userinfo userinfo = new Userinfo("a", "aa");
		return userinfo;
	}

	//数据放到ModelMap 然后再request中传递
	//也可以放到Model中，也可以放到Map中，其实他们都是Map
	@RequestMapping(value="getUserinfoList")
	public ModelMap getUserinfoList(Model model,ModelAndView mov) {
		List<String> userinfoList = new ArrayList<>();
		for (int i = 0; i < 10; i++) {
			userinfoList.add("userinfoList" + (i + 1));
		}
		model.addAttribute("model", userinfoList);
		mov.addObject("modelAndView", userinfoList);
		ModelMap modelMap = new ModelMap();
		modelMap.addAttribute("modelMap", userinfoList);
		return modelMap;
	}
}
