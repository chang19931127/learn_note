package me.czd.test.resource;

import java.io.IOException;
import java.io.InputStream;

import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.EncodedResource;
import org.springframework.util.FileCopyUtils;

/**
 * 
 * @author 43994897 
 * spring提供的资源管理 相对于jdk提供的更加强大，这里我们进行一个测试 使用Resource来进行文件的访问-----访问
 * 起到了一层封装的作用，其实我们的框架往往都是封装了JDK的代码，然后是的JDK代码的功能更加强大
 * FileSystemResource
 * ClassPathResource
 * ServletContextResource       --------------这个就是针对Web应用根路径的方式表示了
 * 										eg：new ServletContestResource(application,"/WEB-INF/classes/dir")
 * 
 */
public class FileSourceExample {
	public static void main(String[] args) {
		try {
			String filePath = "C:\\Users\\43994897\\IBM\\test\\workspace-maven\\spring-demo\\target\\classes\\me\\czd\\test\\resource\\a.txt";

			// 1,使用系统文件路径方式加载文件，绝对系统路径
			Resource res1 = new FileSystemResource(filePath);

			// 2,使用类路径方式加载文件,类路径
			Resource res2 = new ClassPathResource("me/czd/test/resource/a.txt");
			
			
			//封装了类加载器         getResource   URL
			System.out.println("ClassLoaderPATH：" + Thread.currentThread().getContextClassLoader().getResource("me/czd/test/resource/a.txt"));
			
			InputStream is1 = res1.getInputStream();
			InputStream is2 = res2.getInputStream();
			System.out.println("res1:"+res1.getFilename());
			System.out.println("res2:"+res2.getFilename());
			
			EncodedResource encRes = new EncodedResource(res2, "UTF-8");
			// 直接 获得了流，剩下就是对流的操作就完美了。。。
			String content = FileCopyUtils.copyToString(encRes.getReader());
			System.out.println(content);
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
