package me.test;

import java.util.HashMap;
import java.util.Map;

public class Demo3 {
	public static void main(String[] args) {
			String s = "one,two,one,two";
			Map<String, Integer> map = new HashMap<>();
			String[] strings = s.split(",");
			for (String string : strings) {
				Integer initValue = 1;
				Integer oldValue = map.put(string, initValue);
				if(oldValue != null){
					initValue = oldValue+1;
					map.put(string, initValue);
				}
			}
			System.out.println(map.get("one"));
	}
}
