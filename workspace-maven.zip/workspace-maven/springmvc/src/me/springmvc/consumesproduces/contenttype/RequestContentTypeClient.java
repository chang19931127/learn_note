package me.springmvc.consumesproduces.contenttype;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

import org.springframework.http.HttpMethod;
import org.springframework.http.client.ClientHttpRequest;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.http.client.SimpleClientHttpRequestFactory;

/*
 * 这里我们进行模拟客户端发送Json数据！！！！！！！！通过spring提供的，一般情况下我们可以使用HttpClient
 * 伴随着HttpClient的过时，我们主要开始使用HttpURLConnection jdk中就有
 */
public class RequestContentTypeClient  {
	public static void main(String[] args) throws IOException, URISyntaxException {
		//请求的地址
		String url = "http://localhost:8080/springmvc/app/request/ContentType";
		//1，创建Http Reqeust（内部使用HttpURLConnection）
		ClientHttpRequest request = new SimpleClientHttpRequestFactory().createRequest(new URI(url), HttpMethod.POST);
		//2，设置请求头的内容类型头和内容编码
		request.getHeaders().set("Content-Type", "application/json;charset=UTF-8");
		//3，以UTF-8的编码写出响应内容
		String jsonData="{\"username\":\"zhang\",\"password\":\"123\"}";
		request.getBody().write(jsonData.getBytes("UTF-8"));
		//4，发送请求并得到响应
		ClientHttpResponse response = request.execute();
		System.out.println(response.getStatusCode());
	}
}
