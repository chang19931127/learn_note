package me.springmvc.first.flight.domain;

import java.util.Date;

/*
 *  搜索航班类
 *  起飞降落没有设计成飞机场，是为了方便 搜索
 */
public class SearchFlights {
	private String departFrom;	//起飞
	private String arriveAt;		//降落
	private Date departOn;		//时间
	private Date returnOn;		//时间
	
	//这里就是提供所有 get  set方法
	public String getDepartFrom() {
		return departFrom;
	}
	public void setDepartFrom(String departFrom) {
		this.departFrom = departFrom;
	}
	public String getArriveAt() {
		return arriveAt;
	}
	public void setArriveAt(String arriveAt) {
		this.arriveAt = arriveAt;
	}
	public Date getDepartOn() {
		return departOn;
	}
	public void setDepartOn(Date departOn) {
		this.departOn = departOn;
	}
	public Date getReturnOn() {
		return returnOn;
	}
	public void setReturnOn(Date returnOn) {
		this.returnOn = returnOn;
	}
	
}
