
//定义模块，并帮定路由模块，并配置路由 oper为路由名称
var actionApp = angular.module("actionApp",["ngRoute"]);
console.log("app.js加载成功");
actionApp.config(["$routeProvider",function($routeProvider){
	$routeProvider.when("/oper",{
		controller:"View1Controller",
		templateUrl:"views/view1.html",
	}).when("/directive",{
		controller:"View2Controller",
		templateUrl:"views/view2.html",
	});
}]);
