package me.czd.test.aop.pointcut.staticmethod;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/*
 * 测试静态方法匹配切面
 */
public class Main {
	public static void main(String[] args) {
		String configLocation = "beanfactory/beans_static.xml";
		ApplicationContext ctx =  new ClassPathXmlApplicationContext(configLocation);
		Waiter waiter = (Waiter) ctx.getBean("waiter");
		Seller seller = (Seller) ctx.getBean("seller");
		waiter.greetTo("John");
		waiter.serveTo("John");
		seller.greetTo("Jobn");
		
		/*
		 * 这里我们的切面规则是，必须是Waiter的类或者子类，必须是greetTo方法
		 * 
		 * 这里就可以了解到
		 * 增强！Advice
		 * 切点！pointcut
		 * 切面！Advisor
		 * 以及切点如果匹配，如果管理
		 */
	}
}
