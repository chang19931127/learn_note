package me.script;

//HelloWorld
public class HelloWorld {
	String s = "Hello World";
	public void sayHello(){
		System.out.println(s);
	}
}
