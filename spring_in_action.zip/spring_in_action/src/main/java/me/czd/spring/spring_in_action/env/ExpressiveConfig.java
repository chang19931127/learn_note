package me.czd.spring.spring_in_action.env;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

import me.czd.spring.spring_in_action.BlankDisc;

/**
 * 动态注入值
 * 
 * @author 43994897
 *
 */
@Configuration
@PropertySource("classpath:/me/env/app.properties")
public class ExpressiveConfig {

    @Autowired
    Environment env;

    @Bean
    public BlankDisc disc() {
	return new BlankDisc(env.getProperty("disc.title"), env.getProperty("disc.artist"));
    }
}
