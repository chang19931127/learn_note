package me.czd.spring.spring_in_action.springaware;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * Aware 的配置类
 * @author 43994897
 *
 */
@Configuration
@ComponentScan
public class AwareConfig {

}
