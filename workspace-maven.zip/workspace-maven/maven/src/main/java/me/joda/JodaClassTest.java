package me.joda;

import java.io.ByteArrayInputStream;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import org.joda.time.DateTime;
import org.joda.time.Days;
import org.joda.time.LocalDate;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.junit.Test;

/*
 * Joda 提供的日期处理类，这个开源项目针对java8t提供了开源支持
 * 
 * 多次封装	System.currentTimeMillis()
 * 
 * DateTime     --------------->String 
 * String ------------------------->DateTimeFormatter--------------------------->DateTime
 */
public class JodaClassTest {
	@Test
	public  void dateTime() {
		//2017年2月13号10点30分50秒333毫秒
		DateTime dateTime1 = new DateTime(2017,2,13,10,30,50,333);
		DateTime dateTime2 = new DateTime(2012,6,12,16,36,54,222);
		
		//按照格式化输出
		String str1 = dateTime1.toString("MM/dd/yyyy hh:mm:ss.SSSa");
		String str2 = dateTime1.toString("dd-MM-yyyy HH:mm:ssa");
		String str3 = dateTime1.toString("EEEE dd MMMM, yyyy HH:mm:ssa");
		String str4 = dateTime2.toString("MM/dd/yyyy HH:mm ZZZZ");
		String str5 = dateTime1.toString("MM/dd/yyyy HH:mm Z");
		System.out.println(str1);
		System.out.println(str2);
		System.out.println(str3);
		System.out.println(str4);
		System.out.println(str5);
		
		//格式化器 -----------时间解析
		DateTimeFormatter format = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss");
		DateTime dateTime3 = DateTime.parse("2012-12-21 23:22:45", format);
		String str6 = dateTime3.toString("yyyy/MM/dd HH:mm:ss EE");
		//格式化带Local
		String localeStr6 =dateTime3.toString("yyyy年MM月dd日 HH:mm:ss EE", Locale.CHINESE);
		System.out.println(str6);
		System.out.println(localeStr6);
		
		//获取现在时间
		DateTime nowDate = new DateTime();
		System.out.println(nowDate);
		System.out.println(DateTime.now());
	}
	
	@Test
	public void dateOperator(){
		//计算两个日期的时间差
		LocalDate start = new LocalDate(2012,12,14);
		LocalDate end = new LocalDate(2013,01,15);
		int days = Days.daysBetween(start, end).getDays();
		System.out.println(days);
		
		//增加日期            这个可以一直进行操作       new DateTime 实例，类似于String的concat
		DateTime dateTime1 = DateTime.parse("2012-12-03");
		System.out.println(dateTime1.plusDays(30));
		System.out.println(dateTime1.plusHours(3));
		System.out.println(dateTime1.plusMinutes(3));
		System.out.println(dateTime1.plusMonths(2));
		System.out.println(dateTime1.plusWeeks(5));
		System.out.println(dateTime1.plusYears(3));
		
		//判断是否是闰月
		DateTime.Property month = dateTime1.monthOfYear();
		System.out.println("是否是闰月！"+month.isLeap());
		//取得3秒前的时间
		DateTime dt5 = dateTime1.secondOfMinute().addToCopy(-3);
		System.out.println(dt5);
		System.out.println("得到正分钟后，获得秒钟数"+dt5.getSecondOfMinute());
		System.out.println("得到整天后，获得秒钟数"+dt5.getSecondOfDay());
	}
	
	@Test
	public void jodaDate(){
		DateTime dt1 = new DateTime(new Date());
		System.out.println("DateTime"+dt1);
		
		Date date = dt1.toDate();
		System.out.println("Date:"+date);
		
		dt1 = new DateTime(System.currentTimeMillis());
		System.out.println("通过当前秒来获取时间"+dt1);
		System.out.println("获得当前秒"+dt1.getMillis());
		
		Calendar calendar = Calendar.getInstance();
		dt1=new DateTime(calendar);
		System.out.println("通过Calendar来进行构造"+dt1);

	}
}
