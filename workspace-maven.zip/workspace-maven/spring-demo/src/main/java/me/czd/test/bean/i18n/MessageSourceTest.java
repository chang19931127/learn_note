package me.czd.test.bean.i18n;

import java.util.GregorianCalendar;
import java.util.Locale;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.MessageSource;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/*
 * 这里是Spring 提供的 将我们JDK提供的包封了一层，是我们用的时候更加方便
 * 
 * 我们使用Spring 的MessageSource来使用
 */
public class MessageSourceTest {
	@Test
	public void messageSourceTest(){
		String configLocation = "beanfactory/beans_i18n.xml";
		ApplicationContext ctx = new ClassPathXmlApplicationContext(configLocation);
		
		MessageSource ms = (MessageSource) ctx.getBean("myResource");
		Object[] params = {"john",new GregorianCalendar().getTime()};
		
		String str1 = ms.getMessage("greeting.common", params, Locale.US);
		String str2 = ms.getMessage("greeting.morning", params, Locale.CHINA);
		String str3 = ms.getMessage("greeting.afternoon", params, Locale.US);
		
		System.out.println(str1);
		System.out.println(str2);
		System.out.println(str3);
	}
	
	/*
	 * 这里 更有意思，就是MessageSource------和我们的容器绑定，仔细观察
	 * 我们的ApplicationContext  实现了MessageSource,
	 * 那么 意思就是我们可以直接将这个bean  邦定到我们的 容器中，
	 * 因此我们需要将id 设置成规定的值，方便被注入
	 *                      id = messageSource
	 */
	@Test
	public void messageSourceTest1(){
		String configLocation = "beanfactory/beans_i18n.xml";
		ApplicationContext ctx = new ClassPathXmlApplicationContext(configLocation);
		
		//这里我们就不用再 通过这个bean 来 国际化了，因为已经邦定到了容器
		Object[] params = {"john",new GregorianCalendar().getTime()};
		
		String str1 = ctx.getMessage("greeting.common", params, Locale.US);
		String str2 = ctx.getMessage("greeting.morning", params, Locale.CHINA);
		String str3 = ctx.getMessage("greeting.afternoon", params, Locale.US);
		
		System.out.println(str1);
		System.out.println(str2);
		System.out.println(str3);
	}
}
