package me.czd.spring.spring_in_action.taskschedule;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * 定时任务配置类
 * @EnalbeScheduling 这个类来进行定时任务的自动装配
 * @author 43994897
 *
 */
@Configuration
@ComponentScan
@EnableScheduling
public class TaskSchedulerConfig {

}
