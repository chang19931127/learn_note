package me.springmvc.first.flight.domain;

/*
 * 飞机场类
 *  javabean Airport对象
 *  只读数据，封装内部
 */
public class Airport {
	private String name ;//名
	private String airportCode ;//编号
	public Airport(String name, String airportCode) {
		super();
		this.name = name;
		this.airportCode = airportCode;
	}
	public String getName() {
		return name;
	}
	public String getAirportCode() {
		return airportCode;
	}
	public String toString(){
		return name + "("+airportCode+")";
	}
}
