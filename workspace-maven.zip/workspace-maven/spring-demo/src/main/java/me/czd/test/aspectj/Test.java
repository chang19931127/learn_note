package me.czd.test.aspectj;

public class Test {
	/*
	 * 				通过学习了spring  AOP  发现spring AOP 比较复杂，每次都要大量配置，或者多个
	 * 接口，
	 * 					因此spring 就会有改善，用户可以使用@AspectJ注解来轻松的定义切面，对于没有使用jdk5的
	 * 同志，可以通过基于Schema的配置定义切面。都是非常的方便，
	 * 	首先AspectJ就是 aop的领导者，spring也是接受AspectJ的，因此现在的Aop很强大了
	 * 
	 * 注解很清楚
	 * Schema 也很清楚							命名空间
	 * 
	 * 也就是spring 通过对AspectJ  的扩展，使得spring   Aop功能更加强大！
	 * spring对AspectJ是部分支持，仅支持部分方法
	 * 
	 * 
	 * 						基于XMl配置的AOP和基于@AspectJ注解的AOP，
	 * 		底层同样是使用得代理
	 * 
	 * 
	 * 
	 * 当使用AspectJ的时候，需要一些相应类库
	 * 
	 * ASM和aspectjweaver
	 * 基于注解的AOP是超级的好用
	 * 
	 * 
	 * 通配符
	 * *：表示任意字符，但是只能表示一个元素，例如返回值
	 * ..：表示任意字符，可以匹配多个元素，表示类时，必须和*联合使用
	 * +：表示按类型匹配的指定类的所有类，必须跟在类名后面                       继承或扩展的类的方法
	 * @AspectJ  						标记 切面
	 * 
	 * @Before 						前置增强
	 * @AfterReturning		后置增强
	 * @Around						环绕增强
	 * @AfterThrowing		抛出增强
	 * @After							Final增强
	 * @DeclareParents		引介增强
	 * 
	 * @Pointcut						命名切点          		这里仅提供切点的入口，修饰的方法名，可以被别的切点调用，但是方法体不执行
	 * 									通过注解以及切面类方法对切点进行命名，这些切点就可以在别的增强中使用
	 * 
	 * 
	 * 切点函数
	 * args()						this()					target()				@args()				@within()				@target()			@annotation
	 * 			切点函数除了可以指定类名外，还可以指定参数名，将目标连接点上的方法如参，异常，返回值 等 
	 * 邦定到增强的方法中，意思就是，连接点上的方法的参数，抛出的异常可以在增强中得到
	 * ，但是前提条件就是，传递的名称一定要相同，就是声明增强的参数名，和执行增强方法的参数名相同
	 */
}
