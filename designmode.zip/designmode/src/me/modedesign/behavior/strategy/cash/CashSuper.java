package me.modedesign.behavior.strategy.cash;

public abstract class CashSuper {
	public abstract double acceptCash(double money);
}
