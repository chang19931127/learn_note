package me.simplemvc;

import java.io.IOException;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LoginServlet 解决处理登陆的Servlet
 */
@WebServlet(urlPatterns= "/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public LoginServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		this.doPost(request, response);
	}

	// 响应客户端请求
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// 由于我们的Servlet不再管理页面，仅仅作为后台的控制逻辑，请求转发
		// 这里不包含业务，因此我们需要Dao
		// 获取请求参数
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		
		String errMsg = "" ;

		// 连接数据库
		try {
			DbDao dd = DbDao.instance("org.apache.derby.jdbc.EmbeddedDriver",
					"jdbc:derby:c:/users/43994897/mydb", "root", "root");
			//查询结果集
			ResultSet rs = dd
					.query("select password from t_user where name='"
							+ username + "'");
			if(rs.next()){
				if(rs.getString("password").equals(password)){
					//获取session对象
					HttpSession session = request.getSession(true);
					session.setAttribute("name", username);
					request.getRequestDispatcher("/mvc/welcome.jsp").forward(request, response);
				}else{
					errMsg += "您的用户名密码不符合，请重新输入";
				}
			}else{
				errMsg += "您的用户名不存在，请先注册";
			}
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("exception", "业务异常");
			request.getRequestDispatcher("/mvc/error.jsp").forward(request, response);
		}
		if(errMsg != null && !errMsg.equals("")){
			request.setAttribute("err", errMsg);
			request.getRequestDispatcher("/mvc/login.jsp").forward(request, response);
		}

	}

}
