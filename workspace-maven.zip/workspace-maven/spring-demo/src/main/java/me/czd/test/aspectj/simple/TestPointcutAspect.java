package me.czd.test.aspectj.simple;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
public class TestPointcutAspect {
	// 这里运用的是其他地方的 命名切点
	@Before("me.czd.test.aspectj.simple.TestNamePointcut.greetTo()")
	public void beforeGreeting() {
		System.out.println("这里是通过 Pointcut 连接点 增强的");
		System.out.println("How are you!!!!!");
	}
}
