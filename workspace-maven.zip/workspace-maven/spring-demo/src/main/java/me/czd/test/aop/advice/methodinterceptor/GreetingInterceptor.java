package me.czd.test.aop.advice.methodinterceptor;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;

/*
 * 这里就有意思了，这里是环绕增强，
 * 也就是前后 都增强，我们需要实现一个类MethodInterceptor
 * 
 */	
public class GreetingInterceptor implements MethodInterceptor{

	/**
	 *这里很像我们之前自己写的  动态代理，有没有发现！！！！！！！！
	 *直接在我们的方法执行中，随便加东西
	 */
	
	//截获目标类方法
	@Override
	public Object invoke(MethodInvocation invocation) throws Throwable {
		//获取方法的调用参数
		Object[] args = invocation.getArguments();
		String clientName = (String) args[0];
		System.out.println("How are you ! Mr."+clientName +".");//这里是目标方法执行前调用
		
		Object  obj = invocation.proceed();//通过反射，调用目标方法
		
		System.out.println("Please enjoy yourself");//在目标方法后调用
		return obj;
	}

}
