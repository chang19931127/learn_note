package me.czd.webservice.adapter;

import java.util.List;

import me.czd.webservice.entity.Role;

/*
 * 自定义实体，cxf能接受
 * 这里就是使用自定义实体来代替Map的Entry
 */
public class MyRole {
	private String key;
	private List<Role> value;
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public List<Role> getValue() {
		return value;
	}
	public void setValue(List<Role> value) {
		this.value = value;
	}
	
	
}
