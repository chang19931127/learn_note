package com.sys.service.impl;

import lombok.extern.slf4j.Slf4j;

import org.springframework.stereotype.Service;

import com.spring.test.UserVo;
import com.sys.service.IUserService;

@Service
@Slf4j
public class UserServiceImpl implements IUserService {


	public boolean add(UserVo t) {
		log.info(t.toString());
		return true;
	}

}
