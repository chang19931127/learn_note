package com.example.demo.security;

import org.springframework.context.annotation.Configuration;
/*import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;*/

/**
 * 这里是spring 搭spring security 进行的设置 当我们需要这个的时候，我们要引入 依赖，然后进行过滤
 * 
 * 这个开启之后只要我们访问我们的站点，并且在我们的访问控制信息里面，那么就必须进行身份认证
 * 
 * 一般网站开发进度到最后再进行 登陆和安全的配置
 * 
 * @author 43994897
 *
 */
/*@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

    // 这里我们自己配置

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
	auth.inMemoryAuthentication().withUser("wtf").password("wtf").roles("USER").and()
	.withUser("wyf").password("wyf").roles("USER");
    }

    //我们没啥好自定义的
    @Override
    protected void configure(HttpSecurity http) throws Exception {
	//就使用默认的登陆页面把
	//super.configure(http);
	//自定义登陆页面
	http.authorizeRequests()
	.antMatchers("/","/login").permitAll()
	.anyRequest().authenticated()
	.and()
	.formLogin()
	.loginPage("/login")
	.defaultSuccessUrl("/websocket/chats").permitAll()
	.and()
	.logout().permitAll();
    }

    @Override
    public void configure(WebSecurity web) throws Exception {
	//静态资源不 需要授权
	web.ignoring().antMatchers("/resources/static/**","/webjars/**");
    }

}*/
