package me.czd.test.aop.pointcut.staticmethod;

import java.lang.reflect.Method;

import org.springframework.aop.MethodBeforeAdvice;

/*
 * 增强类，用于增加某些特定功能
 */
public class GreetingBeforeAdvice implements MethodBeforeAdvice {

	@Override
	public void before(Method method, Object[] args, Object target)
			throws Throwable {
		System.out
				.println(target.getClass().getName() + "." + method.getName());
		String clientName = (String) args[0];
		System.out.println("How are you ! Mr." + clientName + "......");
	}

}
