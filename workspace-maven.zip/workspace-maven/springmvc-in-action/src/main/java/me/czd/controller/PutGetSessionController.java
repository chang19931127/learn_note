package me.czd.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

/**
 * 
 * @author 43994897
 *	针对session的玩
 */

@Controller
@RequestMapping(value="usernameInSession")
@SessionAttributes(value="usernameInSession")
public class PutGetSessionController {
	
	//由于session如果不存在就报错，因此这里我们就直接先给usernameInSession一个值
	@ModelAttribute(value="usernameInSession")
	public String init(){
		return "init";
	}
	
	@RequestMapping(value="/putSession")
	public String putSession(Model model){
		model.addAttribute("usernameInSession", "usernameInSessionValue");
		return "index";
	}
	
	//这里通过ModelAttribute拿数据的话，一定要有数据，如果没有肯定报错
	@RequestMapping(value="/getSession")
	public String getSession(@ModelAttribute("usernameInSession") String getUsernameFormSession){
		System.out.println("getUsernameFromSession = "+getUsernameFormSession);
		return "index";
	}
}
