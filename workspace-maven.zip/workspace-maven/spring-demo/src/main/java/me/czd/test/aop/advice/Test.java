package me.czd.test.aop.advice;

public class Test {
	/*
	 * Spring 支持五种类型的增强
	 * 
	 * 
	 * 					前置增强：
	 * BeforeAdvice，代表前置增强，
	 * 					后置增强：
	 * AfterAdvice，代表后置增强。
	 * 					环绕增强：
	 * MethodInterceptor，代表环绕增强。
	 * 					异常抛出增强：
	 * ThrowsAdvice：代表抛出异常增强
	 * 					引介增强：
	 * IntroductionInterceptor，代表引介增强。表示在目标类中添加一些新的方法和属性。
	 */
}
