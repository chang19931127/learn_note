package me.czd.test.aop.proxy.ordinary;

/*
* 一个具有横切逻辑的实例
* 是一个性能监视横切逻辑
* 通过这个逻辑  我们需要搞清楚   一些可以 aop的类 所具有的特点
*/
public class ForumServiceImpl implements ForumService{
	@SuppressWarnings("static-access")
	@Override
	public void removeTopic(int topicId) {
		//横切点---------开始对该方法进行性能监视
		PerformanceMonitor.begin("ForumServiceImpl.removeTopic");
		
		System.out.println("模拟删除Topic 记录："+topicId);
		try {
			Thread.currentThread().sleep(20);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		//横切点---------结束对该方法进行性能监视
		PerformanceMonitor.end();
	}
	@SuppressWarnings("static-access")
	@Override
	public void removeForum(int forumId) {
		//横切点---------开始对该方法进行性能监视
		PerformanceMonitor.begin("ForumServiceImpl.removeForum");
		
		System.out.println("模拟删除Forum 记录："+forumId);
		try {
			Thread.currentThread().sleep(20);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		//横切点---------结束对该方法进行性能监视
		PerformanceMonitor.end();
	}

}
