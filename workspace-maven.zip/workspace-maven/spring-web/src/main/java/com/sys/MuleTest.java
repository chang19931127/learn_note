package com.sys;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.net.URI;
import java.net.URISyntaxException;
import org.junit.Test;
import org.springframework.http.HttpMethod;
import org.springframework.http.client.ClientHttpRequest;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.http.client.SimpleClientHttpRequestFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sys.vo.JsonVo;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class MuleTest {

	@Test
	public void test() throws IOException, URISyntaxException, ClassNotFoundException {
		URI uri = new URI("http://localhost:8080/spring-web/testJson");
		ClientHttpRequest request = new SimpleClientHttpRequestFactory().
			createRequest(uri, HttpMethod.POST);
		ClientHttpResponse response = request.execute();
		System.out.println(response.getHeaders().getContentLength());
		InputStream is = response.getBody();
		JsonVo json = new ObjectMapper().readValue(is, JsonVo.class);
		log.info(json.toString());
//		BufferedReader br =  new BufferedReader(new InputStreamReader(is));
//		String str = "";
//		while((str = br.readLine())!=null) {
//			System.out.println(str);
//		}
//		byte[] bytes = new byte[1024];
//		is.read(bytes);
//		System.out.println(new String(bytes));
//		ObjectInputStream ob = new ObjectInputStream(response.getBody());
//		JsonVo jsonVo = (JsonVo) ob.readObject();
//		log.info(jsonVo.toString());
//		ObjectInputStream or = new ObjectInputStream(response.getBody());
		log.info(""+System.currentTimeMillis());
	}
}
