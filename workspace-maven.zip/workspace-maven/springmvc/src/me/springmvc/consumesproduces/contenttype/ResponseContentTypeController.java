package me.springmvc.consumesproduces.contenttype;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ResponseContentTypeController {

	@RequestMapping("response/ContentType")
	public void response1(HttpServletResponse response) throws IOException{
		//1，表示响应的内容区数据的媒体类型和html格式，并且编码为utf-8
		response.setContentType("text/html;charset=UTF-8");
		//2，写出响应体内容
		response.getWriter().write("<font style='color:red'>hello</font>");
	}
	
	@RequestMapping(value="response/ContentType",headers="Accept=application/json")
	public void response2(HttpServletResponse response) throws IOException{
		response.setContentType("application/json;charset=UTF-8");
		String jsonData = "{\"username\":\"zhang\",\"password\":\"123\"}";
		response.getWriter().write(jsonData);
	}
	
	@RequestMapping(value="response/ContentType",headers="Accept=application/xml")
	public void response3(HttpServletResponse response) throws IOException{
		response.setContentType("application/xml;charset=UTF-8");
		String xmlData ="<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
		xmlData += "<user><username>zhang</username><password>123</password></user>";
		response.getWriter().write(xmlData);
	}
}
