package com.example.demo.transaction;

import com.example.demo.datajpa.Person;

/**
 * 模拟事务，我们需要抽象一个 服务层出来
 * 
 * 使用的都是datajpa中的bean 和repository
 * @author 43994897
 *
 */
public interface TransactionService {
    //回滚了
    Person savePersonWithRollBack(Person person);
    //没有回滚
    Person savePersonWithoutRollBack(Person person);
}
