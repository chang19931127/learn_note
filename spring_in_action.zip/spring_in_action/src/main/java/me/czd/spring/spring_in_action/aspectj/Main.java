package me.czd.spring.spring_in_action.aspectj;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * 测试类
 * 
 * @author 43994897
 *
 */
public class Main {
    public static void main(String[] args) {
	//获取spring application上下文
	AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AopConfig.class);
	
	//获取使用到的bean 
	AnntationService annotationService =context.getBean(AnntationService.class);
	MethodService methodService = context.getBean(MethodService.class);
	
	//切面注入成功，调用方法感受，比如这里两个都是空方法，但是通过切面注入了方法体
	annotationService.add();
	methodService.add();
	
	//关闭上下文
	context.close();
    }
}
