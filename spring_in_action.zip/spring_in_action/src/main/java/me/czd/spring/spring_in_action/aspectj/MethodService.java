package me.czd.spring.spring_in_action.aspectj;

import org.springframework.stereotype.Service;

/**
 * 方法规则被拦截类
 * @author 43994897
 *
 */
@Service
public class MethodService {
    public void add() {
	System.out.println("方法本身");
	}
}
