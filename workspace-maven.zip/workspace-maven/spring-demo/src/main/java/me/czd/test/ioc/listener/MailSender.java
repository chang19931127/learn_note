package me.czd.test.ioc.listener;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

/*
 * 正儿八经的邮件发送类，如果叫一个类可以通知其他的监听器，必须实现ApplicationContextAware
 * 
 * ApplicationContextAware 这个类是 直接帮助你     获取到工厂实例
 * 也就是直接 就拥有了ApplicationContext---------------
 * 																								为什么提供这个接口，目的就是为了分离框架，
 * 																								通过实现接口，我们就得到了ApplicationContext
 */
public class MailSender implements ApplicationContextAware{

	private ApplicationContext ctx;
	
	//ApplicationContextAware 的接口方法，能够让容器启动时  注入容器实例
	@Override
	public void setApplicationContext(ApplicationContext applicationContext)
			throws BeansException {
		this.ctx=applicationContext;
	}
	
	//真正的邮件发送方法，这里面肯定要调用通知监听器的方法
	public void sendMail(String to){
			System.out.println("MailSender:模拟发送邮件。。。。");
			MailSendEvent mse = new MailSendEvent(ctx, to);
			System.out.println("事件构造完毕！！！！！！！！！！！！！！");
			ctx.publishEvent(mse);
			System.out.println("容器发布事件");
	}

}
