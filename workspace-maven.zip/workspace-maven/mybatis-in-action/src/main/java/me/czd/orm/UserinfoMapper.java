package me.czd.orm;

/*
 * 因为mybatis是面向接口的，我们的接口都是和UserinfoMapper.xml一一对应的
 */
public interface UserinfoMapper {
	Userinfo getUserinfoById(int id);
}
