package me.springmvc.annotation.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

/*
 * 这里面都是基于注解来使用的MVC
 * 首先我们来一个入门！
 * 要明白注解是被扫描注册，然后使用注解支持类，来进行实用，
 * 了解涉及的注解支持类
 * 
 * 这里我们用到的
 * @Controller									用于表示是处理器类
 * @RequestMapping					请求到功能处理器方法的影射规则               这个RequestMapping有很多的影射方式，像其他的影射一样若干匹配规则
 * 映射规则有很多
 */
//将一个POJO类声明成处理器
//这样子的请求地址就要加一个前缀http://localhost:8080/springmvc/app/anno/helloanno           窄化请求影射
@Controller
@RequestMapping(value= "anno")
public class AnnoHelloWorldController {
	@RequestMapping(value = "/helloanno")
	public ModelAndView helloWorld(){
		//1，收集参数
		//2，邦定参数到命令对象
		//3，调用业务对象
		//4，选择下一个页面
		ModelAndView  mv = new ModelAndView();
		mv.addObject("message","Hello World Annotation!");
		mv.setViewName("helloanno");
		return mv;
	}
}
