package me.reflect;

import java.lang.reflect.Field;

import org.junit.Test;

/*
 *  ���demo�������Է��������Ӱ��
 *  ������˵   ---����������ǽ��͵�
 */
public class Demo {
		public final int ADDTTIVE_VALUE=1;
		public final int MULTIPLIER_VALUE=1;

		//ֱ������
	public int accessSame(int loops){
		int m_value = 0;
		for(int index = 0; index< loops;index++){
			m_value = (m_value + ADDTTIVE_VALUE)*MULTIPLIER_VALUE;
		}
		return m_value;
	}
	//�������
	public int accessReference(int loops) {
		TimingClass timing = new TimingClass();
		for(int index = 0 ; index < loops;index++){
			timing.m_value = (timing.m_value + ADDTTIVE_VALUE)*MULTIPLIER_VALUE;
		}
		return timing.m_value;
	}
	//��������
	public int accessReflection(int loops) throws Exception{
		TimingClass timing = new TimingClass();
		try {
			Field field = TimingClass.class.getField("m_value");
			for(int index =0;index<loops;index++){
				int value=(field.getInt(timing) +ADDTTIVE_VALUE)*MULTIPLIER_VALUE;
				field.setInt(timing, value);
				}
			return timing.m_value;
		} catch (NoSuchFieldException | SecurityException e) {
			System.out.print("Error using reflection");
			throw e;
		}
	}
}
