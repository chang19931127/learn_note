package me.modedesign.structure.decorate.clothe;

public class TShirts extends Clothe {

	@Override
	public void show() {
		System.out.print("��T��\t");
		person.show();
	}

}
