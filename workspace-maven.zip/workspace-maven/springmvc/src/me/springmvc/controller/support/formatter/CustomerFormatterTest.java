package me.springmvc.controller.support.formatter;

import junit.framework.Assert;
import me.springmvc.annotation.model.PhoneNumberModel;

import org.junit.Test;
import org.springframework.format.support.DefaultFormattingConversionService;

/*
 * 这里是对我们自定义的 PhoneNumberFormatter 这个格式   进行 测试，使用
 */
public class CustomerFormatterTest {
	@Test
	public void test() {
		DefaultFormattingConversionService conversionService = new DefaultFormattingConversionService();
		// 给SPI 添加内容
		conversionService.addFormatter(new PhoneNumberFormatter());
		PhoneNumberModel phoneNumber = new PhoneNumberModel("010", "12345678");
		Assert.assertEquals("010-12345678",
				conversionService.convert(phoneNumber, String.class));
		Assert.assertEquals("010", (conversionService.convert("010-12345678",
				PhoneNumberModel.class)).getAreaCode());
	}
}
