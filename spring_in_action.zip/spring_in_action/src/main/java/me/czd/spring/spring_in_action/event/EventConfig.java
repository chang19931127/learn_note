package me.czd.spring.spring_in_action.event;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * 配置类
 * @author 43994897
 *
 */
@Configuration
@ComponentScan
public class EventConfig {

}
