package com.sys.util;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.TimeZone;
import org.apache.commons.lang3.StringEscapeUtils;
import lombok.extern.slf4j.Slf4j;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser.Feature;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.module.SimpleModule;

@Slf4j
public class JsonMapper extends ObjectMapper {

	private static final long serialVersionUID = 1L;
	
	public JsonMapper() {
		this(Include.NON_EMPTY);
	}
	
	public JsonMapper(Include include) {
		if(include!=null) {
			setSerializationInclusion(include);
		}
		//允许单引号
		configure(Feature.ALLOW_SINGLE_QUOTES, true);
		//允许不带引号的字段名称
		configure(Feature.ALLOW_UNQUOTED_FIELD_NAMES, true);
		disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
		getSerializerProvider().setNullValueSerializer(new JsonSerializer<Object>(){
			public void serialize(Object value, JsonGenerator gen,
					SerializerProvider serializers) throws IOException,
					JsonProcessingException {
				gen.writeString("");
			}
		});
		registerModule(new SimpleModule().addSerializer(String.class, new JsonSerializer<String>(){
			public void serialize(String value, JsonGenerator gen,
					SerializerProvider serializers) throws IOException,
					JsonProcessingException {
				gen.writeString(StringEscapeUtils.unescapeHtml3(value));
			}
		}));
		setTimeZone(TimeZone.getDefault());
	}
	
	private static class JsonMapperHolder {
		private final static JsonMapper mapper = new JsonMapper();
	}
	
	public String getJson(Object object) {
		try {
			return writeValueAsString(object);
		} catch (JsonProcessingException e) {
			log.info(e.getMessage());
			return null;
		}
	}
	
	public static String getJsonString(Object object) {
		return JsonMapperHolder.mapper.getJson(object);
	}
	
	public static Map<String, String> convertJsonToMap(String jsonString) {
		try {
			return JsonMapperHolder.mapper.readValue(jsonString, new TypeReference<Map<String, String>>(){});
		} catch (JsonParseException e) {
			log.info(e.getMessage());
		} catch (JsonMappingException e) {
			log.info(e.getMessage());
		} catch (IOException e) {
			log.info(e.getMessage());
		}
		return null;
	}
}
