package me.event;

import java.util.ArrayList;
import java.util.List;

/*
 * 事件发布者
 */
public class MethodExecutionEventPublisher {
	private List<MethodExecutionEventListener> listeners = new ArrayList<>();

	public void addMethodExecutionEventListener(
			MethodExecutionEventListener listener) {
		listeners.add(listener);
	}

	public void removeListener(MethodExecutionEventListener listener) {
		if (listeners.contains(listener))
			listeners.remove(listener);
	}

	public void removeAllListener() {
		listeners.clear();
	}

	public void methodToMonitor() {
		MethodExecutionEvent event2Publish = new MethodExecutionEvent(this,
				"methodToMonitor");
		publishEvent(MethodExecutionStatus.BEGIN, event2Publish);
		System.out.println("其他的操作");
		publishEvent(MethodExecutionStatus.END, event2Publish);
	}

	protected void publishEvent(MethodExecutionStatus status,
			MethodExecutionEvent event) {
		List<MethodExecutionEventListener> copyListeners = new ArrayList<>(
				listeners);
		for (MethodExecutionEventListener listener : copyListeners) {
			if (MethodExecutionStatus.BEGIN.equals(status)) {
				listener.onMethodBegin(event);
			} else {
				listener.onMethodEnd(event);
			}
		}
	}
}
