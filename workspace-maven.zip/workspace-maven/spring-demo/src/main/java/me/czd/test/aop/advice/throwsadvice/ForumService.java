package me.czd.test.aop.advice.throwsadvice;

import java.sql.SQLException;

/*
 * 这里就是模拟异常抛出
 * 说句实话，异常抛出最好的使用场景就是 --------------------------事务回滚、
 * Dao发生异常后，事务管理器必须回滚事务
 */
public class ForumService {
	public void removeForum(int forumId) {
		// do sth
		throw new RuntimeException("运行异常");
	}

	public void updateForum(int id) throws Exception {
		// do sth
		throw new SQLException("数据库更新操作异常。。。。");
	}
}
