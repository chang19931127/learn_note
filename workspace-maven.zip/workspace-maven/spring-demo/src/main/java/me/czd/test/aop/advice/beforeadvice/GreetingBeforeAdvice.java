package me.czd.test.aop.advice.beforeadvice;

import java.lang.reflect.Method;

import org.springframework.aop.MethodBeforeAdvice;

/*
 * 打招呼的服务员，我们打招呼都是先给称呼
 * 这里我们前置增强 使用的接口就是MethodBeforeAdvice
 */
public class GreetingBeforeAdvice 	implements MethodBeforeAdvice{

	@Override
	public void before(Method method, Object[] args, Object target)
			throws Throwable {
		String clientName = (String) args[0];
		System.out.println("How are you ! Mr."+clientName+".");
	}

}
