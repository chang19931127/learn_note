package me.springmvc.annotation.paramtype;

import java.util.Arrays;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;

/*
 * @RequestHeader -----邦定请求头数据
 * 									用于将请求的头信息区数据映射到功能处理方法的参数上
 * value -----参数名字
 * required -----是否必须
 * defaultValue -----默认值 ---可以使spEL表达式
 */
@Controller
@RequestMapping("/method/param/annotation")
public class RequestHeaderTypeController {
	@RequestMapping(value = "/header")
	public String test(@RequestHeader(value = "User-Agent") String userAgent,
			@RequestHeader(value = "Accept") String[] accepts,
			@RequestHeader Map<String, String> headers) {
		// 这里获取的数据都是来自！！请求头！！
		System.out.println(userAgent);
		System.out.println(Arrays.toString(accepts));
		System.out.println("header=================:" + headers);
		return "success";
	}
}
