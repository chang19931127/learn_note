package com.example.demo.cache;

import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Configuration;

/**
 * 开启缓存的配置类
 * 
 * 通过@EnableCacheing 来进行引入 缓存
 * 
 * @author 43994897
 *
 */
@Configuration
@EnableCaching
public class CacheConfig {

}
