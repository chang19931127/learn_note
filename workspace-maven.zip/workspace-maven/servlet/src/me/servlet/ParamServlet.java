package me.servlet;

import java.io.IOException;
import java.io.PrintStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ParamServlet
 * 	见明知意，我们想要获取Servlet的配置参数，常用的参数我们添加到Servlet启动的时候
 * 										通过ServletConfig类来获取初始化参数
 * 同样我们这里是通过注解来实现的
 * xml中是这样----------mapper别忘了
 * <servlet>
 * 			<servlet-name>timerServlet</servlet-name>
 * 			<servlet-class>me.servlet.ParamServlet</servlet-class>
 * 			<init-param>
 * 						<param-name>driver</param-name>
 * 						<param-value>org.apache.derby.jdbc.EmbeddedDriver</param-value>
 * 			</init-param>
 * 			<init-param>
 * 						<param-name>url</param-name>
 * 						<param-value>jdbc:derby:c:/users/43994897/mydb</param-value>
 * 			</init-param>
 *			类推
 *一定要掌握注解的用法     仔细看下注解的作用域，以及参数信息
 * </servlet>
 */
@WebServlet(urlPatterns={"/ParamServlet","/param"},initParams={
		@WebInitParam(name="driver",value="org.apache.derby.jdbc.EmbeddedDriver"),		
		@WebInitParam(name="url",value="jdbc:derby:c:/users/43994897/mydb")
})

public class ParamServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public ParamServlet() {
        super();
    }
    
	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
	}

	@Override
	public void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		//获取ServletConfig
		ServletConfig config = getServletConfig();
		String driver = config.getInitParameter("driver");
		String url = config.getInitParameter("url");
		String user = config.getInitParameter("user");
		String pass = config.getInitParameter("pass");
		PrintStream out = new PrintStream(response.getOutputStream());
		out.println("<HTML>");
		out.println("<HEAD>");
		out.println("<TITLE>Servlet启动参数</TITLE>");
		out.println("</HEAD>");
		out.println("<BODY>");
		out.println(driver);
		out.println("<hr>");
		out.println(url);
		out.println("</BODY>");
		out.println("</HTML>");
	}
}
