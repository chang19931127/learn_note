package me.springmvc.annotation.paramtype;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import me.springmvc.annotation.model.DataBinderTestModel;
import me.springmvc.annotation.model.UserModel;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

/*
 * @ModelAttribute -----邦定请求参数到命令对象。
 * 
 * SpringMVC的执行过程
 * 				当根据映射进入一个Controller的时候，先去执行非功能方法，再去根据映射执行功能方法！
 * 		也就是说@ModelAttribute修饰的非功能方法先执行，然后邦定
 * 
 * 	@ModelAttribute3个作用
 * 							1，邦定请求参数到命令对象：放在功能处理方法的入参上时，用于将多个请求参数邦定到一个命令对象，从而简化邦定流程，而且自动暴露为模型数据用于试图页面展示时使用。
 * 							2，暴露表单引用对象的模型数据：放在处理器的一般方法(非功能处理方法)上时，是为表单准备要展示的表单引用对象，如注册时需要选择的所有城市等。
 * 				而在执行功能处理方法(@RequestMapping注解的方法)之前，自动添加到模型对象中，用于试图页面展示时使用。
 * 							3，暴露@RequestMapping方法返回值为模型数据：放在功能方法的返回值上，是暴露功能处理方法的返回值为模型数据，用于试图页面展示使用。
 * 			上面我们可以得到 @ModelAttribute 可以出现在三个地方1，请求参数！2，非功能处理方法！3，方法返回值！
 * 
 * 间接性的将@ModelAttribute修饰的参数，存储在(((((ModelMap)))))中！！！！！！
 * 
 * 为什么@ModelAttribute修饰非功能方法，当作默认值处理，是因为Controller为了保证线程安全，不要出现属性变量
 */
@Controller
@RequestMapping("/method/param/annotation")
public class ModelAttributeTypeController {
	//这个cityList 页面上就可以直接取到，视图Model中，就包含这个数据-------------一句话就是为表单准备要展示的数据
	@ModelAttribute("cityList")
	// 非功能方法，其实这里就可以当作默认值处理
	public List<String> cityList() {
		//只要访问Controller 就会执行非功能方法
		System.out.println("cityList已经绑定");
		return Arrays.asList("北京", "上海", "深圳");
	}

	//同样，没有别的数据的话，user也可以被访问
	@ModelAttribute("user")
	// 非功能方法
	public UserModel getUser(
			@RequestParam(value = "username", defaultValue = "") String username ,ModelMap map) {
		// 这里就是去数据库查找对象，我们这里是模拟的 
		System.out.println("@ModelAttribute对象存储到ModelMap中---------------"+(List<?>)map.get("cityList")); //这里可以证明，@ModelAttribute里面的数据存储到了ModelMap中
		UserModel user = new UserModel();
		user.setRealname("Zhang");
		System.out.println("user对象已经查找到，并且邦定到Model中");
		return user;
	}
	
	//model1?username=zhang&password=123&workInfo.city=bj               就将我们请求的数据封装成了对象UserModel
	@RequestMapping(value = "/model1")
	// 请求参数
	public String test1(@ModelAttribute("user") UserModel user, Model model) {
		System.out.println(model.containsAttribute("cityList"));//true
		System.out.println(user);
		return "success";
	}

	//model2/zhang        也就只为DataBindTestModel对象封装了一个username     可以在后面追加参数 ?bool=yes&specialty=computer&map[key1]=value1
	@RequestMapping(value = "/model2/{username}")
	// 请求参数
	public String test2(@ModelAttribute("model") DataBinderTestModel model) {
		System.out.println(model);
		return "success";
	}

	@RequestMapping(value = "/model3")
	// 请求参数,暴露出返回值，走到了     */method/param/annotation/model3.jsp      这里是通过RequestToViewNameTranslator     直接全路径.jsp文件
	public @ModelAttribute("user2")UserModel test3(@ModelAttribute("user2") UserModel user) {
		UserModel user2 = new UserModel();
		user2.setUsername("zhang");
		return user2;//这里返回的user2会覆盖传入的user2，然后，暴露给显示页面user2
	}

	@RequestMapping(value = "/model4")
	// 请求参数
	public String test4(@ModelAttribute UserModel user, Model model) {
		
		//匿名邦定匿名参数，这里SpringMVC会根据 简单类名，第一个字母小写，暴露给模型数据，这里就是UserModel暴露userModel
		System.out.println(model.containsAttribute("userModel"));//true
		return "success";
	}

	@RequestMapping(value = "/model5")
	public String test5(UserModel user, Model model) {
		//同上，没有命令对象提供的模型，同样是暴露，UserModel暴露userModel
		System.out.println(model.containsAttribute("userModel"));//true
		return "success";
	}

	//对于集合类型(Collection接口的实现者们，包括数组，声称的模型对象属性名都是-------简单类名 + ‘List’) 例如List<String>---->stringList   
	//其他情况就是简单类名暴露 例如Map<String,UserModelList>------>map
	//返回值这里声明@ModelAttribute就是暴露给页面显示的，也就是给其他地方提供数据 的
	@RequestMapping(value = "/model6")
	// 返回值
	public @ModelAttribute
	List<String> test6() {
		return Arrays.asList("北京", "上海", "西安");
	}

	@RequestMapping(value = "/model7")
	// 返回值
	public @ModelAttribute
	List<UserModel> test7() {
		return Arrays.asList(new UserModel(), new UserModel());
	}

	@RequestMapping(value = "/model8")
	// 返回值
	public @ModelAttribute
	Map<String, UserModel> test8() {
		return new HashMap<String, UserModel>();
	}
}
