package me.czd.spring.spring_in_action.taskschedule;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = TaskSchedulerConfig.class)
public class TaskScheduleTest {
    
    
    @Test
    public void test(){
	
    }

}
