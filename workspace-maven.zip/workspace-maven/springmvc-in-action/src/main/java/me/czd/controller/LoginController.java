package me.czd.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * 
 * @author 43994897 登陆Controller
 */
@Controller
//为了防止多个Controller中的 mapper 相同，来一个前缀,千万要注意路径
@RequestMapping(value="/cd")
public class LoginController {
	//影射关系，限制请求方法
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String loginGet(@RequestParam("username1") String username,
			@RequestParam("password1") String password, Model model) {
		if ("username".equals(username)) {
			System.out.println("GET");
			model.addAttribute("username", username);
			System.out.println("username"+username);
			System.out.println(password);
			return "cd/ok";
		} else {
			System.out.println("GET");
			System.out.println(username);
			System.out.println(password);
			return "cd/no";
		}
	}
	
	//POST 提交
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String loginPost(@RequestParam("username1") String username,
			@RequestParam("password1") String password, Model model) {
		if ("username".equals(username)) {
			model.addAttribute("username", username);
			System.out.println("POST");
			System.out.println("username"+username);
			System.out.println(password);
			return "cd/ok";
		} else {
			System.out.println("POST");
			System.out.println(username);
			System.out.println(password);
			return "cd/no";
		}
	}
}
