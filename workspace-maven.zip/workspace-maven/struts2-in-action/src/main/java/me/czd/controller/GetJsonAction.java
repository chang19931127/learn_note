package me.czd.controller;

import java.io.BufferedReader;

import org.apache.struts2.ServletActionContext;

import net.sf.json.JSONObject;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

/**
 * 
 * @author 43994897
 *	这里模拟我们对前台json 数据的接受
 *	还有处理乱麻问题，我们可以直接在  set方法中来进行
 */
public class GetJsonAction extends ActionSupport{

	private static final long serialVersionUID = -423469398373652709L;

	private String jsonString;
	
	private long timestamp;
	

	public long getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(long timestamp) {
		this.timestamp = timestamp;
	}

	public String getJsonString() {
		return jsonString;
	}

	public void setJsonString(String jsonString) {
		this.jsonString = jsonString;
	}
	
	public String execute() throws Exception{
		System.out.println("------"+jsonString);
		//如果  post 提交方式不是application/x-www-form-urlencoded，tomcat就不会帮助我们自动 去获取值
		//tomcat 的源码中，通过判断  application 然后再去采取不同的策略去获取值
		//我们只能通过下面的方式通过  request来获取，不过，mvc框架中提供了获取的方式，同样可以获取到string 然后交给JSonO 去解析
/*		StringBuffer jsonString = new StringBuffer();
		BufferedReader reader = ServletActionContext.getRequest().getReader();
		String line;
		while(( line = reader.readLine()) != null){
			jsonString.append(line);
		}
		System.out.println(jsonString.toString());*/
		//Json解析字符串，然后形成JsonObject
		JSONObject json = JSONObject.fromObject(jsonString);
		//JSONArray 数组，
		System.out.println("username="+json.get("username"));
		System.out.println("password="+json.get("password"));
		System.out.println("age="+json.get("age"));
		System.out.println("BigText="+json.get("BigText"));
		return null;
	}
}
