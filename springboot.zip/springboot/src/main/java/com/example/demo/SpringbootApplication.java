package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * springboot 的启动方式 1，SB中嵌入了tomcat，因此直接启动，就可以开启服务 2，通过@SpringBootApplication
 * 组合注解，来进行自动配置，默认扫包，注册@Configuration
 * 
 * spring的自动配置是通过 @Conditional注解来进行自动配置，条件注解 加入debug 可以查看自动配置
 * 
 * spring 自动加载application.properties文件，当前目录，classpath目录，两者下的config子目录
 * ，有一个优先级，覆盖关系
 * 
 * 直接main方法，启动，通过SpringApplication.run()方法
 * 
 * 由于我们将很多内容组合到一个工程中，有很多的配置，有的时候需要忽略，我们可以通过这里的扫包来进行忽略 我们的功能都按照包名来区分
 * 
 * 很多内容都被自动配置了，在spring-boot-autoconfigure.jar
 * 
 * 我们使用的前台页面都是    打成jar 的静态文件
 * 
 * spring 中默认了h2database 因此只要加入对应的jar包到路径下就好
 * 
 * @author 43994897
 *
 */
// MVC Controller 组件
@RestController
// 组合注解------如果不想使用某个自动配置，就使用如下方式，exclude  这个自动配置数据源的
//@SpringBootApplication(exclude = { DataSourceAutoConfiguration.class })
@SpringBootApplication()
public class SpringbootApplication {

    @RequestMapping("/")
    String index() {
	return "Hello Spring Boot";
    }

    public static void main(String[] args) {

	//开发模式自启动 引入开发模式的依赖，默认为true
	System.setProperty("spring.devtools.restart.enabled", "true");
	// 一个静态方法，方便启动
	SpringApplication.run(SpringbootApplication.class, args);

	// SpringApplication sb = new
	// SpringApplication(SpringbootApplication.class);
	// sb.setBannerMode(Banner.Mode.OFF);//关闭banner
	// sb.run(args);
    }
}
