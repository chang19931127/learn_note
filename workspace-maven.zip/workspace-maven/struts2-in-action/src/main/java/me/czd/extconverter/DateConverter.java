package me.czd.extconverter;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import javax.xml.bind.TypeConstraintException;

import org.apache.struts2.util.StrutsTypeConverter;

/**
 * 
 * @author 43994897
 *	全局范围的  时间转换器，这里的properties就有意思了
 */
public class DateConverter extends StrutsTypeConverter{

	private static SimpleDateFormat[] formateArray = {
			new SimpleDateFormat("yyyy-MM-dd"),
			new SimpleDateFormat("yyyy年MM月dd日"),
			new SimpleDateFormat("yyyy/MM/dd")
	};
	
	@Override
	public Object convertFromString(Map context, String[] values, Class toClass) {
		System.out.println("执行了Date日期格式转换");
		String dateString = values[0];
		for (int i = 0; i < formateArray.length; i++) {
			try {
				return formateArray[i].parse(dateString);
			} catch (ParseException e) {
				e.printStackTrace();
				continue;
			}
		}
		throw new TypeConstraintException("日期转换异常");
	}

	@Override
	public String convertToString(Map context, Object o) {
		System.out.println("dateConverter converToString");
		
		return "在IE中输出："+new SimpleDateFormat("yyyy-MM-dd").format((Date)o);
	}

}
