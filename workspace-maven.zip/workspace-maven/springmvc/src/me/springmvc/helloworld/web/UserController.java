package me.springmvc.helloworld.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

/*
 * 一个关于User的MultiAction多功能的Controller
 * 为了学习这里使用，最新的spring已经不使用这个了，都是注解
 * 自己看看这个源码，传入了一个Method方法，通过返回值类型，参数，等等去选择执行的内容
 */
@SuppressWarnings("deprecation")
public class UserController extends MultiActionController{
	//逻辑视图名
	private String createView;
	private String updateView;;
	private String deleteView;
	private String ListView;
	private String redirectToListView;
	public String getCreateView() {
		return createView;
	}
	public void setCreateView(String createView) {
		this.createView = createView;
	}
	public String getUpdateView() {
		return updateView;
	}
	public void setUpdateView(String updateView) {
		this.updateView = updateView;
	}
	public String getDeleteView() {
		return deleteView;
	}
	public void setDeleteView(String deleteView) {
		this.deleteView = deleteView;
	}
	public String getListView() {
		return ListView;
	}
	public void setListView(String listView) {
		ListView = listView;
	}
	public String getRedirectToListView() {
		return redirectToListView;
	}
	public void setRedirectToListView(String redirectToListView) {
		this.redirectToListView = redirectToListView;
	}
	
	/*
	 多重请求方法
	 public ModelAndView toAdd(HttpServletRequest request,HttpServletResponse response){} 											表示到新增页面
	 public ModelAndView date(HttpServletRequest request,HttpServletResponse response，UserModel user){}			表示新增表单提交，最后可以带着命令对象
	 public Map list(HttpServletRequest request,HttpServletResponse response){}																		列表，但只返回模型数据，视图名会通过RequestToViewNameTranslator实现来计算
	 public void fileDownload(HttpServletRequest request,HttpServletResponse response){}													文件下载，返回值为void，直接该功能响应
	 public ModelAndView sessionWith(HttpServletRequest request,HttpServletResponse response，HttpSession session){}			第三个参数可以是session，邦定session
	 public ModelAndView sessionAndCommandWith(HttpServletRequest request,HttpServletResponse response,HttpSession session,UserModel user){}			如果第三个参数是session，那么第四个可以是命令对象
	 public ModelAndView anyMeaningfullName(HttpServletRequest request,HttpServletResponse response,ExceptionClass exception){}			MultiActionController会使用最接近的异常类型来匹配对应的异常处理方法
	 */
	public ModelAndView toAdd(HttpServletRequest request,HttpServletResponse response){
		return null;
	}
	
}
