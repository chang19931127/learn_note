package me.czd.test.bean.i18n;

import java.text.MessageFormat;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.ResourceBundle;

import org.junit.Test;

//使用JDK 中提供的国际化来，来进行国际化的处理
public class JDKTest {
	@Test
	public void i18nTest(){
		ResourceBundle rb1 = ResourceBundle.getBundle("i18n/fmt_resource", Locale.US);
		ResourceBundle rb2 = ResourceBundle.getBundle("i18n/fmt_resource", Locale.CHINA);
		
		Object[] params = {"john",new GregorianCalendar().getTime()};
		
		String str1 = new MessageFormat(rb1.getString("greeting.common")).format(params);
		String str2 = new MessageFormat(rb2.getString("greeting.morning")).format(params);
		String str3 = new MessageFormat(rb1.getString("greeting.afternoon")).format(params);
		
		System.out.println(str1);
		System.out.println(str2);
		System.out.println(str3);
	}
}
