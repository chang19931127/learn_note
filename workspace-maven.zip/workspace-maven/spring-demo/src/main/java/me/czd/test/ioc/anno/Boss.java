package me.czd.test.ioc.anno;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import me.czd.test.bean.Car;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

/*
 * 一个 完全基于注解的 Bean ，
 * 我们只需要在配制文件中，加入扫包就好
 */
@Component
public class Boss {
	
	//不是必须被注入,直接写在这里的话，就不需要 set方法      在set方法上面写，是一样的
	@Autowired(required = false)
	@Qualifier(value="car")//指定bean注入
	private Car car ;
	
	public Car getCar() {
		return car;
	}

	private Boss() {
		System.out.println("construct---------------Boss");
	}
	
	//javax 提供的注解
	@PostConstruct
	private void init1(){
		System.out.println("init1");
	}
	
	//javax  提供的注解
	@PreDestroy
	private void destory(){
		System.out.println("destory");
	}
	
}
