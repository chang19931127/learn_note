package me.czd.webservice;

import java.util.List;
import java.util.Map;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import me.czd.webservice.adapter.MapAdapter;
import me.czd.webservice.entity.Role;
import me.czd.webservice.entity.User;

@WebService
public interface HelloWorld {

	@WebMethod
	public String say( String str);
	
	public List<Role> getRoleByUser(User user);
	
	@XmlJavaTypeAdapter(MapAdapter.class)
	public Map<String, List<Role> > getRoles();
}
