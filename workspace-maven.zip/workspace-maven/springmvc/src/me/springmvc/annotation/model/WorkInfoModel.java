package me.springmvc.annotation.model;

//工作信息领域模型
public class WorkInfoModel {
	private String city;// 城市
	private String job;// 职位
	private String year;// 年限

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	@Override
	public String toString() {
		return "WorkInfoModel[city=" + city + ",job=" + job + ",year=" + year
				+ "]";
	}

}
