package me.event;

public enum MethodExecutionStatus {
	 BEGIN,END;
}
