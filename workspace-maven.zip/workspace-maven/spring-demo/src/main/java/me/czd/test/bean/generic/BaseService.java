package me.czd.test.bean.generic;

public interface BaseService<T> {

	T get();

}
