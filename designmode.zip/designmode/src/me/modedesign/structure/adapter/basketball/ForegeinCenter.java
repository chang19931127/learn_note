package me.modedesign.structure.adapter.basketball;

public class ForegeinCenter  {
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public void gongji(){
		System.out.println("�⼮�з�" + name + "����");
	}
	
	public void fangshou(){
		System.out.println("�⼮�з�" + name + "����");
	}
}
