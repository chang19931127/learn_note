package me.czd.spring.spring_in_action.springaware;

import java.io.IOException;

import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.context.ResourceLoaderAware;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;

/**
 * Spring 提供的直接获取某些特殊类，缺点就是和spring 耦合
 * 这些东西在spring 中实现了Aware接口，然后由一个set方法，这个可以值得去借鉴
 * @author 43994897
 *
 */
@Service
public class AwareService implements BeanNameAware,ResourceLoaderAware {

    private String beanName;
    private ResourceLoader loader;
    
    //通过set方法来进行 注入
    @Override
    public void setResourceLoader(ResourceLoader resourceLoader) {
	this.loader = resourceLoader;
    }

    @Override
    public void setBeanName(String name) {
	this.beanName = name;
    }
    
    public void outputResult(){
	System.out.println("Bean 的名称为："+beanName);
	Resource resource = loader.getResource("classpath:me/czd/spring/spring_in_action/springaware/test.txt");
	try {
	    System.out.println("Resource加载的文件内容为:"+IOUtils.toString(resource.getInputStream()));
	} catch (IOException e) {
	    e.printStackTrace();
	}
    }

}
