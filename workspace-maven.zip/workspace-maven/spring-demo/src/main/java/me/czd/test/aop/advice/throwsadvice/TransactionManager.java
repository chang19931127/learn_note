package me.czd.test.aop.advice.throwsadvice;

import java.lang.reflect.Method;
import java.sql.SQLException;

import org.springframework.aop.ThrowsAdvice;

/*
 * 这是异常抛出通知
 * 异常抛出通知需要实现一个 ThrowsAdvice
 * 虽说这个接口是一个标记接口
 */
public class TransactionManager implements ThrowsAdvice{
	//我们自己定义增强逻辑
	//针对异常 增强，需要方法，参数，对象，异常，用那个就传那个参数，前三个参数同时存在，要么同时不存在
	
	
	//虽说这里接口 ThrowsAdvice   没有 方法
	//但是这里我们的命名必须是afterThrowing  否则就会 报错
	public void afterThrowing(Method method , Object[] args , Object target , Throwable ex) throws Throwable{
		System.out.println("------------------------");
		System.out.println("method:"+method);
		System.out.println("异常抛出:"+ex.getMessage());
		System.out.println("成功会滚事务。");
	}
	public void afterThrowing(RuntimeException ex){
		System.out.println("RuntimeException，这里通过TransactionManager来捕获");
	}
	public void afterThrowing(SQLException ex){
		System.out.println("SQLException");
	}
	
	/*
	 * 这里通过AOP 然后可以统一管理异常，哈哈 说不定spring 就是通过这种方式来管理异常的     
	 * springmvc 中有一个 就是统一管理异常的注解
	 */

}
