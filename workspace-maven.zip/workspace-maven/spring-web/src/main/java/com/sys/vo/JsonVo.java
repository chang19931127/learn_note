package com.sys.vo;

import java.io.Serializable;
import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonView;

import lombok.Data;

@Data
@XmlRootElement
public class JsonVo implements Serializable {
	
	private static final long serialVersionUID = 9181193786786413533L;
	private long id;
	private String name;
	private String mobile;
	@JsonFormat(pattern="yyyy-MM-dd")
	private Date birthday;
}
