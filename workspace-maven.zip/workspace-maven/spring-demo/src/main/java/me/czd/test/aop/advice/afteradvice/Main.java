package me.czd.test.aop.advice.afteradvice;

import me.czd.test.aop.advice.beforeadvice.Waiter;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/*
 * 我们这里测试后置通知
 * 仅仅通过   spring 配置文件来进行配置
 */
public class Main {
	@Test
	public void test2(){
		String configLocation = "beanfactory/beans_after.xml";
		ApplicationContext ctx = new ClassPathXmlApplicationContext(configLocation);
		//这里就是我们之前的    FactoryBean        -----------就是可以直接 得到bean
		//--------------------ProxyFactoryBean
		Waiter waiter = (Waiter) ctx.getBean("waiter");
		waiter.greetTo("John");
	}
}
