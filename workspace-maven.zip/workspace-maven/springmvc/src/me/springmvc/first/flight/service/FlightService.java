package me.springmvc.first.flight.service;

import java.util.List;

import me.springmvc.first.flight.domain.Flight;
import me.springmvc.first.flight.domain.SearchFlights;
import me.springmvc.first.flight.domain.SpecialDeal;

//航班	服务的接口
public interface FlightService {
	List<SpecialDeal> getSpecialDeals();//获得特价航班
	List<Flight> findFlights(SearchFlights search);//获取航班
}
