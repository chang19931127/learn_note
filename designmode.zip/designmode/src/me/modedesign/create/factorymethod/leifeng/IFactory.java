package me.modedesign.create.factorymethod.leifeng;

//�����ӿ�
public interface IFactory {
	LeiFeng createLeiFeng();
}
