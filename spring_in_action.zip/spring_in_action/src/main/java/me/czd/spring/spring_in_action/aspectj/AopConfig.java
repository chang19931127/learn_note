package me.czd.spring.spring_in_action.aspectj;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

/**
 * 配置类
 * @author 43994897
 *
 */
@Configurable
@ComponentScan("me.czd.spring.spring_in_action.aspectj")
@EnableAspectJAutoProxy //开启自动代理
public class AopConfig {

}
