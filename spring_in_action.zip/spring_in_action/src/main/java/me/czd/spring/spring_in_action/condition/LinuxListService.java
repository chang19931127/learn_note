package me.czd.spring.spring_in_action.condition;

/**
 * Linux条件下的Service
 * @author 43994897
 *
 */
public class LinuxListService implements ListService {

    @Override
    public String showListCmd() {
	return "ls";
    }

}
