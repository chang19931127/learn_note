package me.czd.test.aop.pointcut.controlflow;

import me.czd.test.aop.pointcut.staticmethod.Waiter;

/*
 * 代理类
 * 我们希望 通过这个代理类调用的   方法，才被增强！！！
 */
public class WaiterDelegate {
	private Waiter waiter;

	public void setWaiter(Waiter waiter) {
		this.waiter = waiter;
	}

	/*
	 * Waiter的方法，通过该方法发起调用，也算是一个flow。。。。流程把
	 */
	public void service(String clientName) {
		waiter.greetTo(clientName);
		waiter.serveTo(clientName);
	}
}
