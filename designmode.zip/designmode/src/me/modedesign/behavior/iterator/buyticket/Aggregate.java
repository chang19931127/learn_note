package me.modedesign.behavior.iterator.buyticket;

public abstract class Aggregate {
	public abstract Iterator creatIterator();
}
