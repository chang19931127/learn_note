package me.tag;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.TagSupport;

/*
 * 这个标签处理类，为了配合BodyTag，双肩合璧，构成带有标签体的标签
 * 这个就是内部标签。。。。。。。。。。。
 */
public class WritorTag extends TagSupport	{
	//属性
	private String item ;

	public String getItem() {
		return item;
	}

	public void setItem(String item) {
		this.item = item;
	}

	@Override
	public int doStartTag() throws JspException {
		try {
			pageContext.getOut().write((String)pageContext.getAttribute(item));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return EVAL_PAGE;
	}
	
	
}
