package me.czd.orm;


/*
 * 就是我们的实体bean 
 */
public class Userinfo {
	private Long id;
	private String username;
	private String password;
	private Long age;
	private String insertDate;
	
	
	
	public Userinfo() {
		super();
	}
	public Userinfo(Long id, String username, String password, Long age,
			String insertDate) {
		super();
		this.id = id;
		this.username = username;
		this.password = password;
		this.age = age;
		this.insertDate = insertDate;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Long getAge() {
		return age;
	}
	public void setAge(Long age) {
		this.age = age;
	}
	public String getInsertDate() {
		return insertDate;
	}
	public void setInsertDate(String insertDate) {
		this.insertDate = insertDate;
	}
	
	
}
