package me.modedesign.create.factorysimple.demo1.clacluate;

public class DelOperation extends Operation {
	
	
	public double getResult () {
		return getNum1() - getNum2();
	}

}
