package me.springmvc.first.flight.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import me.springmvc.first.flight.domain.Airport;
import me.springmvc.first.flight.domain.Flight;
import me.springmvc.first.flight.domain.SearchFlights;
import me.springmvc.first.flight.domain.SpecialDeal;

//这里我们提供了一个  假数据，实际情况中这里就是业务了
//什么Dao，什么操作后的
public class DummyFlightService implements FlightService {

	@Override
	public List<SpecialDeal> getSpecialDeals() {
		Airport newYork = new Airport("NewYork", "100");
		Airport china = new Airport("China", "101");
		List<SpecialDeal> specials = new ArrayList<SpecialDeal>();
		specials.add(new SpecialDeal(newYork, china, new BigDecimal(50.0), new Date(), new Date()));
		return specials;
	}

	@Override
	public List<Flight> findFlights(SearchFlights search) {
		return null;
	}
}
