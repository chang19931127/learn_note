package me.czd.controller;

import java.util.Date;

import org.apache.struts2.util.StrutsTypeConverter;

import me.czd.entity.Point;

import com.opensymphony.xwork2.ActionSupport;

/**
 * 
 * @author 43994897
 *	注册bean ，这里我们想让struts帮助我们转换参数
 */
public class RegisterAction extends ActionSupport{

	private static final long serialVersionUID = -8947561732730745690L;
	private String username;
	private int age;
	private Date insertDate;
	private Point point;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public Date getInsertDate() {
		return insertDate;
	}
	public void setInsertDate(Date insertDate) {
		this.insertDate = insertDate;
	}
	public Point getPoint() {
		return point;
	}
	public void setPoint(Point point) {
		this.point = point;
	}
	
	public String execute(){
		System.out.println(username);
		System.out.println(age+1);
		System.out.println(insertDate);
		System.out.println(point);
		StrutsTypeConverter converter;
		return "toIndexJSP";
	}
}

 
