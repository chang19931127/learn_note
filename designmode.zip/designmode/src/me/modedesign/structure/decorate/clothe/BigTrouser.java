package me.modedesign.structure.decorate.clothe;

public class BigTrouser extends Clothe {

	@Override
	public void show() {
		System.out.print("���\t");
		person.show();
	}

}
