package me.czd.test.aop.pointcut.composable;

import me.czd.test.aop.pointcut.controlflow.WaiterDelegate;

import org.springframework.aop.Pointcut;
import org.springframework.aop.support.ComposablePointcut;
import org.springframework.aop.support.ControlFlowPointcut;
import org.springframework.aop.support.NameMatchMethodPointcut;

/*
 * 复合切面
 * 			为什么要存在符合切面？
 * 就是单独的切面不能满足我们的需求！，我们需要复杂的切面需求！
 * 
 * 
 * 我们这里的需求，就是，，，首先Flow流程切点
 * 					然后流程切点中，符合greetTo的方法，才被记录为切点，并增强，形成切面
 */
public class GreetingComposablePointcut {
	public Pointcut getIntersectionPointcut(){
		//创建一个复合切点。。。。。。。。。
		ComposablePointcut cp = new ComposablePointcut();
		
		//创建一个流程切点
		Pointcut pt1 = new ControlFlowPointcut(WaiterDelegate.class, "service");
		
		//创建一个方法名切点
		NameMatchMethodPointcut pt2 = new NameMatchMethodPointcut();
		
		pt2.addMethodName("greetTo");
		
		//复合切点里面有很多的  切点之间的逻辑，抽象到了一些方法中
		//这里就是两个切点进行交集操作！！！！！！
		//这里pt2需要强转，因为Pointcut MatchName  都具有这个接口
		return cp.intersection(pt1).intersection((Pointcut)pt2);
	}
}
