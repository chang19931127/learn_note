package me.modedesign.behavior.mediator.unitednation;

/**
 * 
 * @author 43994897
 *	���Ϲ�����
 */
public abstract class UniteNations {
	public abstract void declare(String message,Country colleague);
}
