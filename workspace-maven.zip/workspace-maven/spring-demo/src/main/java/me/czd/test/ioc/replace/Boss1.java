package me.czd.test.ioc.replace;

import me.czd.test.bean.Car;

public class Boss1 {
	public Car getCar(){
		Car car = new Car();
		car.setBrand("宝马Z4");
		return car;
	}
}
