package me.czd.test.aspectj.declareparents;

/*
 * 接口，用来一回被引介增强调用的
 */
public interface Seller {
	void sell(String string ,String string1);
}
