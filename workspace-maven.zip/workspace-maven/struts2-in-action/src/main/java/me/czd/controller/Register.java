package me.czd.controller;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;

/**
 * 
 * @author 43994897 这里是用来管理文件上传的
 */
public class Register extends ActionSupport {

	private static final long serialVersionUID = 8007703983424409702L;
	private String username;
	private File uploadFile;
	private String uploadFileFileName;
	//这里会存在一个错误，我们需要提供这个参数，错误才会失效
	//这里就是告诉我们，struts 会自动帮助我们 获取参数，我们的类中如果没有这个对应的接受参数就会报错
	//uploadFileContentType

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public File getUploadFile() {
		return uploadFile;
	}

	public void setUploadFile(File uploadFile) {
		this.uploadFile = uploadFile;
	}

	public String getUploadFileFileName() {
		return uploadFileFileName;
	}

	public void setUploadFileFileName(String uploadFileFileName) {
		this.uploadFileFileName = uploadFileFileName;
	}

	@Override
	public void validate() {

	}

	public String execute() throws IOException {
		System.out.println("username" + username);
		String targetDirectory = ServletActionContext.getServletContext()
				.getRealPath("/upload");
		File target = new File(targetDirectory);
		FileUtils.copyFile(uploadFile, target);
		return "upload";
	}
}
