package com.sys.vo;

import java.util.Date;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

@Data
@XmlRootElement
public class XmlVo {

	private long id;
	private String name;
	private String mobile;
	@JsonFormat(pattern="yyyy-MM-dd")
	private Date birthday;
}
