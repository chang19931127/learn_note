package me.czd.test.aop.advice.throwsadvice;

import org.junit.Test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	@Test
	public void test2() throws Exception {
		String configLocation = "beanfactory/beans_throw.xml";
		ApplicationContext ctx = new ClassPathXmlApplicationContext(
				configLocation);
		// 这里就是我们之前的 FactoryBean -----------就是可以直接 得到bean
		// --------------------ProxyFactoryBean
		ForumService forumService = (ForumService) ctx.getBean("forumService");
		forumService.removeForum(100);
		forumService.updateForum(200);		
	}
}
