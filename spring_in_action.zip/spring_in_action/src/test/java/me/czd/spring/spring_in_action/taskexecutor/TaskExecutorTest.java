package me.czd.spring.spring_in_action.taskexecutor;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * 异步，并发任务，多线程并发执行
 * 
 * @author 43994897
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = TaskExecutorConfig.class)
public class TaskExecutorTest {

    @Autowired
    private AsyncTaskService asyncTaskService;

    @Test
    public void test() {
	//这里的i不能超过 线程最大的数量
	for (int i = 0; i < 10; i++) {
	    asyncTaskService.executeAsyncTask(i);
	    asyncTaskService.executeAsyncTaskPlus(i);
	}
    }

}
