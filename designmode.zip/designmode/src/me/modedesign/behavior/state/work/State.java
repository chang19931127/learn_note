package me.modedesign.behavior.state.work;

/*
 * ״̬�Ľӿ�
 */
public interface State {
	void writeProgram(Work work);
}
