package me.czd.entity;

import lombok.Data;

/**
 * 
 * @author 43994897
 *	用户信息 实体类
 */
@Data
public class Userinfo {
	
	
	public Userinfo() {
		super();
	}
	public Userinfo(String username, String password) {
		super();
		this.username = username;
		this.password = password;
	}
	private String username;
	private String password;
}
