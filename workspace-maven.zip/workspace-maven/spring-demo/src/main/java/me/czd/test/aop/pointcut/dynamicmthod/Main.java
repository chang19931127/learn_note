package me.czd.test.aop.pointcut.dynamicmthod;


import me.czd.test.aop.pointcut.staticmethod.Waiter;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/*
 * 这个动态匹配使用了DefaultPointcutAdvisor和DynamicMethodMatcherPointcut
 * 
 * 什么是动态检查，就是可能我们的连接点，在变化，例如这个例子中，我们的动态检查
 * 就是检查，name是否被包含在集合中，而静态检查就很检查，只需要判断方法是否是greetTo()       
 * 
 * 我们可以发现spring会在创建代理织入切面时，对目标类的所有方法！！！！！进行静态切点检查
 * 													在生成织入切面的代理对象后，第一次调用代理类的每一个方法都会进行一次静态检查，
 * 				如果本次检查就能从候选者列表中将该方法派出，以后对该方法的调用就不再执行静态切点检查；
 * 				对于那些在静态检查时匹配的方法，在后续调用该方法时，将执行动态切点检查的操作
 * 
 * 
 * 我们匹配的准则，
 * 					匹配的三个标准，我们分别进行检查的
 * 					必须是Waiter或其子类，方法名士greetTo，动态入参clientName必须是特殊名单中的客户
 * 								ClassFilter																																				Waiter类或者子类
 * 								matches(Method method, Class<?> targetClass)静态检查													方法名士greetTo
 * 								matches(Method method, Class<?> targetClass, Object... args)动态检查							动态入参clientName必须是特殊名单中的客户
 * 
 * 		
 */
public class Main {
	public static void main(String[] args) {
		String configLocation = "beanfactory/beans_static.xml";
		ApplicationContext ctx = new ClassPathXmlApplicationContext(
				configLocation);
		Waiter waiter = (Waiter) ctx.getBean("waiter2");
		//John 和Tom是特权用户
		waiter.greetTo("John");
		waiter.serveTo("John");
		
		waiter.greetTo("Tom");
		waiter.serveTo("Peter");
	}
}
