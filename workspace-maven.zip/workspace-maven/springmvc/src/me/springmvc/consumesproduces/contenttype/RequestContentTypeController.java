package me.springmvc.consumesproduces.contenttype;

import java.io.IOException;
import java.io.InputStream;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/*
 * Content-Type:
 * 				请求头的内容类型，即请求或者响应的内容区域数据的媒体类型
 * 				是请求头中实体头的内容
 * Accept:
 * 				请求头的内容类型，即，需要什么媒体类型
 * request中设置"Content-Type:application/x-www-urlencoded"表示请求的数据为key/value数据
 * 
 * 这里我们学到一个概念，就是可以将请求方当作是消费者，而响应方就是生产者
 * 
 * 这里要学会 使用java程序进行模拟http访问连接
 */
@Controller
public class RequestContentTypeController {
	
	@RequestMapping(value="/request/ContentType" ,method=RequestMethod.POST)
	public String showForm(){
		//form表单，使用application/x-www-form-urlencoded编码方式提交表单
		return "consumesproduces/Content-Type";
	}
	
	@RequestMapping(value="/request/ContentType",method=RequestMethod.POST,headers="Content-Type=application/x-www-form-urlencoded")
	public String request1(HttpServletRequest request){
		//1，得到请求的内容区数据的类型
		String contentType = request.getContentType();
		System.out.println("===========ContentType:"+contentType);
		//2，得到请求区内容区数据的编码方式，如果没有则返回为NULL
		//这里有一个问题，就是编码只能设置一次，如果请求设置了的话，那么过滤器就不会再进行
		String characterEncoding = request.getCharacterEncoding();
		System.out.println("===========CharacterEncoding:"+characterEncoding);
		//3，表示请求的内容区数据为form表单提交的参数，可以通过request获得参数
		System.out.println(request.getParameter("realname"));
		System.out.println(request.getParameter("username"));
		return "success";
	}

	@RequestMapping(value="/request/ContentType",method=RequestMethod.POST,headers="Content-Type=application/json")
	public String request2(HttpServletRequest request) throws IOException{
		//表示请求的内容区数据为json数据
		InputStream is = request.getInputStream();
		byte[] bytes = new byte[request.getContentLength()];
		is.read(bytes);
		//得到请求中的内容区数据
		String jsonStr = new String(bytes,request.getCharacterEncoding());
		System.out.println("json data:"+jsonStr);
		return "success";
	}
}
