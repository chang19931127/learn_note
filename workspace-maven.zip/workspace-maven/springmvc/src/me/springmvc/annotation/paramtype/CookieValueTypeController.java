package me.springmvc.annotation.paramtype;

import javax.servlet.http.Cookie;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.RequestMapping;

/*
 * @CookieValue -----邦定Cookie数据值
 * 								用于将请求的Cookie数据映射到功能处理器的参数上
 * @CookieValue 常用参数
 * value : Cookie的名称
 * defaultValue：该参数的默认值
 */
@Controller
@RequestMapping("/method/param/annotation")
public class CookieValueTypeController {
	@RequestMapping(value="/cookie")
	public String test(@CookieValue(value="JSESSIONID",defaultValue="")String sessionId){
		System.out.println(sessionId);
		//获取的cookie中的sessionId:D9123433D35837293000B9B50141A255
		return "success";
	}
	@RequestMapping(value="/cookie2")
	public String test2(@CookieValue(value="JSESSIONID",defaultValue="")Cookie sessionId){
		//获得的就是CookieValue
		System.out.println(sessionId.getName());
		return "success";
	}
}
