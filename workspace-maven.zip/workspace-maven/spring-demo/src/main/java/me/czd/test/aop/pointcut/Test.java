package me.czd.test.aop.pointcut;


public class Test {
	/*
	 * 	增强提供了连接点方位信息：如织入到方法前面，后面等，而切点进一步描述织入到那些类的那些方法上！
	 * 
	 * 
	 * 			为什么要有切点，切面，因为我们的增强有的时候不仅仅是针对一个方法，或者一个类，我们针对的是一系列方法
	 * 因此我们需要创建切面来进行切面的整体增强！
	 * 
	 * 	Spring提供了几个接口来描述切点
	 * 				静态方法切点；StaticMethodMatcherPointcut
	 * 				动态方法切点：DynamicMethodMatcherPointcut
	 * 				注解切点：AnnotationMatchingPointcut
	 * 				表达式切点：ExpressionPointcut
	 * 				流程切点：ControlFlowPointcut
	 * 				复合切点：ComposablePointcut
	 * 切面类型
	 * 				Advicer：代表一般切面
	 * 				PointcutAdvicer：代表具有切点的切面
	 * 				IntroductionAdvicer：代表引介切面
	 * 
	 * 
	 * 
	 * 
	 * 
	 * !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!自动生成代理，不需要我们再去手动    ProxyFactoryBean
	 * 这里还有问题了，当我们每一次切面弄完之后，都要使用代理进行代理，是不是太过于麻烦了
	 * 					这里要使用spring  提供的BeanPostProcessor
	 * 					当与这个接口有关的类，就在bean中  bean的初始化之前，和初始化之后，
	 * 			spring提供了三个类来帮助我们自动创建代理
	 * 							BeanNameAutoProxyCreator;
	 * 												这个类通过beanNames   来帮我们进行自动创建代理
	 * 							<bean class="org.springframework.aop.framework.autoproxy.BeanNameAutoProxyCreator"
	 * 									p:beanNames="*er"         匹配bean   name   然后代理
	 * 									p:interceptorNames="greetAdvice"
	 * 									p:optimize="true"
	 * 							/>
	 * 							DefaultAdvisorAutoProxyCreator;
	 * 												这个类是通过Adivsot，就是切面，自动帮助我们创建代理
	 * 							<bean class="org.springframework.aop.framework.autoproxy.DefaultAdvisorAutoProxyCreator"/>
	 * 
	 * 
	 * 							AnnotationAwareAspectJAutoProxyCreator
	 * 												这个类是基于Bean中AspjectJ注解标签的自动代理创建器
	 * 			
	 */
}
