package me.modedesign.create.factorysimple.demo1.clacluate;

public class MulOperation extends Operation {

	public double getResult() {
		return getNum1() * getNum2();
	}

}
