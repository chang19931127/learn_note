package me.test.task;

import java.text.DateFormat;
import java.util.Date;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/*
 * spring 计时器
 */
@Component()
public class TestTask {
	@Scheduled(cron = "*/5 * * * * ?")
	public void print(){
		//(cron = "*/5 * * * * ?")表面表示的每五秒执行一次
		//(cron = "5 * * * * ?")每次秒数到5的时候执行一次
		String time = DateFormat.getTimeInstance().format(new Date());
		System.out.println("定时器触发打印"+time);
		/**
		 * 这里有个概念
		 * spring 集成的东西一定要用  springframework 来进行扫包
		 * 不要用   WebApplicationContext来进行扫包，mvc扫进来可能没有用！！！！！！！！！
		 * 
		 */
	}
}
