package me.czd.test.bean.generic;

import java.lang.reflect.ParameterizedType;

public class BaseServiceImpl<T> implements BaseService<T> {

	private Class clazz = null;
	
	protected BaseServiceImpl(){
		ParameterizedType type =  (ParameterizedType) this.getClass().getGenericSuperclass();
		clazz =  (Class) type.getActualTypeArguments()[0];
		System.out.println(clazz);
	}
	
	@Override
	public T get() {
		return null;
	}

}
