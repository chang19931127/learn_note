package me.czd.test.ioc.listener;

import org.springframework.context.ApplicationContext;
import org.springframework.context.event.ApplicationContextEvent;

/*
 * 模拟邮件发送事件，spring 提供了一个ApplicationContextEvent ，直接标记成事件
 * 
 * ApplicationEvent 就是封装了 JDK的EventObject------------内部只有一个属性就是事件源，
 * 																							但是这个事件源已经被ApplicationContext占据	  也就是(最初发生事件的的对象)
 * 
 * 因为 到时候会source会有一个方法，就是用来注册监听器的
 */
public class MailSendEvent extends ApplicationContextEvent{

	private static final long serialVersionUID = 1840263401205738689L;
	
	private String to;//信息发送给谁
	
	//由于是继承过来的，因此必须要有一个事件源，而我们的spring 事件源就是ApplicationContext
	public MailSendEvent(ApplicationContext source ,String to) {
		super(source);
		this.to = to;
	}
	
	public String getTo(){
		return this.to;
	}

}
