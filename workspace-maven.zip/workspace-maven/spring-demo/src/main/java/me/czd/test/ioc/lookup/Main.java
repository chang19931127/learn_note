package me.czd.test.ioc.lookup;

import me.czd.test.bean.Car;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;




/*
 * 我们 在 工厂中注册了  
 * Boss     					 	-----------singleton             	Boos.getCar 是同一个对象
 * MagicBoss              	-----------singleton         		MagicBoos.getCar 是不同的对象  	
 * Car                            	-----------prototype
 * 
 * 对应的配制文件beans_lookup.xml
 * 
 * 这种方式也有 对应的注解实现
 */

public class Main {
	//这里就是用来测试的
	public static void main(String[] args) {
		ApplicationContext ac = new  ClassPathXmlApplicationContext("beanfactory/beans_lookup.xml");
		Boss boss1 =  ac.getBean("boss", Boss.class);
		Boss boss2 =  ac.getBean("boss", Boss.class);
		System.out.println("boss1 == boss2:"+(boss1 == boss2));//true
		Car car1 = boss1.getCar();
		Car car2 = boss2.getCar();
		System.out.println("car1 == car2:"+(car1 == car2));//true
		System.out.println(car1);
		//得到的结论就是我们 单例bean中 想要获取  prototype类型的bean  实际得到的还是同一个值，第一次注入的值
		
		//因此我们通过使用lookup方式来解决这种问题      而且还是面向接口的编程
		//这里主要用到了   CGLIB 来实现代理
		MagicBoss mb1 = ac.getBean(MagicBoss.class);
		MagicBoss mb2 = ac.getBean( MagicBoss.class);
		System.out.println("mb1 == mb2:"+(mb1 == mb2));//true
		//这里虽说   spring 帮我们动态实现了 MagicBoos，但是同样他还是一个单例类，
		Car car3 = mb1.getCar();
		System.out.println("car3==========="+car3);
		Car car4 = mb2.getCar();
		System.out.println("car4==========="+car4);
		System.out.println("car3 == car4:"+(car3 == car4));//false
		//可以看到结果，我们通过lookup方法 注入，获得了prototype的Car
		
	}
}
