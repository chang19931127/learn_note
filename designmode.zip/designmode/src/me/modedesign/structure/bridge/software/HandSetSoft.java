package me.modedesign.structure.bridge.software;

/*
 * �ֻ�����
 */
public abstract class HandSetSoft {
	public abstract void run();
}
