package me.czd.webservice;

import javax.xml.ws.Endpoint;

import org.apache.cxf.jaxws.JaxWsServerFactoryBean;

/*
 * 运行我们的这个Server服务类，就可以发布服务出去让别人调用
 * 这里是基于soap-----wsdl 的   一个xml  可以通过访问
 * http://localhost/helloWorld?wsdl   来获取
 * 
 * 
 * 
 * 客户端使用  wsdl2java工具重新生成代码
 * 
 * CXF不识别Map等复杂类型，遇到复杂类型，需要适配器，XmlAdapter   和@XmlJavaTypeAdapter 注解
 */
public class Server {
	public static void main(String[] args) {
		cxfws();
		//jaxws();
	}

	private static void cxfws() {
		System.out.println("cxf webService start");
		HelloWorld implement = new HelloWorldImpl();
		String address = "http://localhost/helloWorld";
		JaxWsServerFactoryBean factoryBean = new JaxWsServerFactoryBean();
		factoryBean.setAddress(address);
		factoryBean.setServiceClass(HelloWorld.class);
		factoryBean.setServiceBean(implement);
		factoryBean.create();
		System.out.println("cxf webService started");
	}

	private static void jaxws() {
		System.out.println(" web service start");
		HelloWorld hello = new HelloWorldImpl();
		String address = "http://localhost/helloWorld";
		Endpoint.publish(address, hello);
		System.out.println("web service started");
	}
}
