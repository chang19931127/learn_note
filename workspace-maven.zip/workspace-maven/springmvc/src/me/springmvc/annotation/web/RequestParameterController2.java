package me.springmvc.annotation.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/*
 * @RequestMapping来实现SimpleFormController
 * method   	是一些请求方式
 * params		是一些有请求参数的   例如下面的showForm     springmvc/app/parameter2?submitFlag=create    请求中有这个参数才Mapping
 * 常见的使用情况就是，CRUD的时候使用请求参数名，进行映射！
 * 例;
 * 					create请求参数名 且 GET请求方法   新增页面展示
 * 					create请求参数名 且 POST请求方法 新增提交
 */
@Controller
@RequestMapping("/parameter2")
// 1，处理器的通用影射前缀
public class RequestParameterController2 {
	@RequestMapping(params = "submitFlag=create", method = RequestMethod.GET)
	// 2，类级别的Mapping窄化
	public String showForm() {
		System.out.println("======================showForm");
		return "parameter/create";
	}

	@RequestMapping(params = "submitFlag=create", method = RequestMethod.POST)
	//3，类级别的Mapping窄化
	public String submit() {
		System.out.println("====================submit");
		return "redirect:/success";
	}
	
	@RequestMapping(params = "submitFlag!=create", method = RequestMethod.GET)
	// 请求参数名中submitFlag  ！=create的时候                app/parameter2?submitFlag!=create              app/parameter2?submitFlag=crea 也可以
	public String showForm1() {
		System.out.println("======================submit 不等于 create");
		return "parameter/create";
	}
}
