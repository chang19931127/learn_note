package me.czd.test.aop.proxy.cglib;

import java.lang.reflect.Method;

import me.czd.test.aop.proxy.ordinary.PerformanceMonitor;
import net.sf.cglib.proxy.Enhancer;
import net.sf.cglib.proxy.MethodInterceptor;
import net.sf.cglib.proxy.MethodProxy;

/*
 * Cglib来实现动态代理
 * 				Cglib是通过非常底层的字节码技术，来为一个类去创建子类！！！！！！
 * 然后我们这个子类就拥有了     监控
 * 
 * 
 * 通过下面的getProxy为一个类创建动态代理对象，该代理对象通过扩展clazz创建代理对象
 */
public class CglibProxy implements MethodInterceptor{

	//动态生成子类的 封装类
	private Enhancer enhancer = new Enhancer();
	
	public Object getProxy(Class clazz){
		//设置需要创建子类的类
		enhancer.setSuperclass(clazz);
		enhancer.setCallback(this);
		//通过字节码技术动态创建子类实例
		return enhancer.create();
	}
	
	//拦截父类所有方法的调用
	/**
	 * @param obj   表示目标类的实例
	 * @param proxy 表示代理类实例
	 */
	@Override
	public Object intercept(Object obj, Method method, Object[] args,
			MethodProxy proxy) throws Throwable {
		
		PerformanceMonitor.begin(obj.getClass().getName()+"."+method.getName());
		
		//执行父类方法
		Object result = proxy.invokeSuper(obj, args);
		
		
		PerformanceMonitor.end();
		return result;
	}

}
