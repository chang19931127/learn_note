package me.czd.webservice;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.jws.WebService;

import me.czd.webservice.entity.Role;
import me.czd.webservice.entity.User;

@WebService
public class HelloWorldImpl implements HelloWorld {

	@Override
	public String say(String str) {

		return "Hello " + str;
	}

	@Override
	public List<Role> getRoleByUser(User user) {
		List<Role> roleList = new ArrayList<>();
		if (user != null) {
			if (user.getUserName().equals("chang")
					&& user.getPassword().equals("123456")) {
				roleList.add(new Role(1, "技术总监"));
				roleList.add(new Role(2, "架构师"));
			} else if (user.getUserName().equals("jack")
					&& user.getPassword().equals("123456")) {
				roleList.add(new Role(3, "程序员"));
			}
			return roleList;
		} else {
			return null;
		}
	}

	//这里是我们cxf 一般不能解决的问题，因为，可能我们的cxf 不支持该类型，可以通过适配器来解决
	@Override
	public Map<String, List<Role>> getRoles() {
		Map<String, List<Role>> map = new HashMap<>();
		List<Role> roleList = new ArrayList<>();
		roleList.add(new Role(1, "技术总监"));
		roleList.add(new Role(2	, "架构师"));
		map.put("chang", roleList);
		List<Role> roleList2 = new ArrayList<>();
		map.put("jack", 	roleList2);
		return map;
	}

}
