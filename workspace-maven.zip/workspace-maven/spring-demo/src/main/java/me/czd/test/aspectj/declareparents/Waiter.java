package me.czd.test.aspectj.declareparents;

/*
 * 接口
 */
public interface Waiter {
	void greetTo(String name);
	void serveTo(String name);
}
