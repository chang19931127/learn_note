package me.czd.test.aspectj.simple;

/*
 * 这里是通过  schemal 来进行配置的，通过配置文件，不使用注解来搞定。
 */
public class AdviceMethods {
	public void preGreeting(){
		System.out.println("----------------schemal: How are you !!!!!schemal--------------");
	}
}
