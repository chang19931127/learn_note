package me.test;

public class Demo4 {
	public static void main(String[] args) {
		char a = 'Y';
		System.out.println((int)a);
	}
}
