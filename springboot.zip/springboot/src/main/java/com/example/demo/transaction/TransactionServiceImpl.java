package com.example.demo.transaction;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.datajpa.Person;
import com.example.demo.datajpa.PersonRepository;

/**
 * 服务层的实现
 * 
 * 会滚得数据没有修改
 * 不回滚的数据被修改了
 * 
 * 很简单的方式就是用了aop
 * 
 * @author 43994897
 *
 */
@Service
public class TransactionServiceImpl implements TransactionService {

    @Autowired
    private PersonRepository personRepository;

    @Override
    @Transactional(rollbackFor = { IllegalArgumentException.class })
    public Person savePersonWithRollBack(Person person) {
	Person p = personRepository.save(person);
	if (person.getName().equals("常振东")) {
	    throw new IllegalArgumentException("常振东已经存在，数据将会回滚");
	}
	return p;
    }

    @Override
    @Transactional(noRollbackFor = { IllegalArgumentException.class })
    public Person savePersonWithoutRollBack(Person person) {
	Person p = personRepository.save(person);
	if(person.getName().equals("常振东")){
	    throw new IllegalArgumentException("常振东已经存在，数据将不会回滚");
	}
	return p;
    }

}
