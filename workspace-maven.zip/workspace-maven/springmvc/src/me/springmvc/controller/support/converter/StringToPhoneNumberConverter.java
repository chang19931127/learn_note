package me.springmvc.controller.support.converter;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import me.springmvc.annotation.model.PhoneNumberModel;

import org.springframework.core.convert.converter.Converter;
import org.springframework.util.StringUtils;

/*
 * Spring 中数据转换经过了很长时间的 考虑，最终决堤能了使用  Converter这个接口，来进行数据转化-
 * 这里数据的转化是单方向的！！！！
 * 
 * 其次这里可以转换了，那么我们如何将这些东西 在我们的SpringMVC中使用尼？
 * 那就需要我们注册bean了
 * 							1，首先我们需要注册ConversionService实现和自定义的类型转换器
 * 																MVC中有一个类专门管理这个的FormattingConversionServiceFactoryBean
 * 							2，通过ConfigurableWebBindingInitializer注册ConversionService
 * 							3,，注册ConfigurableWebBindingInitializer到RequestMappingHandlerAdapter
 * 								相信信息请参阅mvc的配置xml
 */
public class StringToPhoneNumberConverter implements Converter<String, PhoneNumberModel> {

	Pattern pattern = Pattern.compile("^(\\d{3,4})-(\\d{7,8})$");
	@Override
	public PhoneNumberModel convert(String source) {
		if(!StringUtils.hasLength(source)){
			return null;
		}
		Matcher matcher = pattern.matcher(source);
		if(matcher.matches()){
			PhoneNumberModel phoneNumber = new PhoneNumberModel();
			phoneNumber.setAreaCode(matcher.group(1));
			phoneNumber.setPhoneNumber(matcher.group(2));
			return phoneNumber;
		}else{
			throw new IllegalArgumentException(String.format("类型转换失败,需要格式[010-12345678，但格式是[%s]]", source));
		}
	}

}
