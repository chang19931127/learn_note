package me.springmvc.first.flight.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import me.springmvc.first.flight.service.FlightService;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

/*
 * 这里就是控制器
 * 用来处理应用程序的动态主页
 * Controller配置，也有自己的xml文件    在spring-servlet.xml中配置
 * 
 * 我们通过Controller   将数据放入到ModelAndView中，然后这个视图被InternalResourcVIewResolver转化成jsp文件
 * 通过追加前后缀(prefix,suffix)来确定完整的路径，
 * 剩下的就是web容器
 * 
 * spring基于注解之后，几个常用的注解
 * @Controller:						表示处理器类
 * @RequestMapping:		请求道处理器功能方法的映射规则
 * @requestParam:				请求参数到处理器功能处理方法的方法参数上的邦定
 * @ModelAttribute:			请求参数到命令对象的邦定
 * @SessionAttributes:		用于声明session级别存储的属性，放置在处理器上，通常列出ModelAttribute对应
 * @InitBinder:						自定义数据邦定注册支持，用于将请求参数转换到命令对象属性的对应类型
 * 
 */
public class HomeController extends AbstractController {
	
	private static final int FIVE_MIMUTES = 5*60;
	private FlightService flightService;
	public HomeController() {
		//这里是调用的父类的方法
		//设置为仅相应HttpGet请求，一般GET适用于读
		setSupportedMethods(new String[] {METHOD_GET});
		//设置首部信息
		setCacheSeconds(FIVE_MIMUTES);
	}

	public void setFlightService(FlightService flightService) {
		this.flightService = flightService;
	}



	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest arg0,
			HttpServletResponse arg1) throws Exception {
		//创建了一个ModelAndView 对象，这个视图名叫做home
		ModelAndView mav = new ModelAndView("home");
		mav.addObject("specials",flightService.getSpecialDeals() );
		return mav;
	}
	
}
