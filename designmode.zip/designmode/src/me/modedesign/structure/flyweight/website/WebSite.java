package me.modedesign.structure.flyweight.website;

/**
 * 
 * @author 43994897
 *	���� ��վ
 */
public abstract class WebSite {
	public abstract void use();
}
