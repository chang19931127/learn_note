package me.czd.test.ioc.lookup;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.AutowiredAnnotationBeanPostProcessor;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.beans.factory.support.RootBeanDefinition;

import me.czd.test.bean.Car;

/*
 * 这里是针对我们 inject method 中的lookup  方法 注解形式的解决方案
 * lookup注解，记住，注解一定要对应注解的处理类
 */
public class LookupTest {
	
	private DefaultListableBeanFactory beanFactory;
	
	@Before
	public void setUp(){
		//我们这里模拟的   xml  其实xml 最终被解析，也是这样的结果，若干个RootBeanDefinition   和一些Be按PostProcessor
		beanFactory  = new DefaultListableBeanFactory();
		AutowiredAnnotationBeanPostProcessor aabpp = new AutowiredAnnotationBeanPostProcessor();
		aabpp.setBeanFactory(beanFactory);
		//添加bean的执行过程
		beanFactory.addBeanPostProcessor(aabpp);
		beanFactory.registerBeanDefinition("abstractBean", new RootBeanDefinition(AbstractBean.class));
		beanFactory.registerBeanDefinition("beanCustomer", new RootBeanDefinition(BeanConsumer.class));
		RootBeanDefinition tbd = new RootBeanDefinition(Car.class);
		//这里面 Car 是原形
		tbd.setScope(RootBeanDefinition.SCOPE_PROTOTYPE);
		beanFactory.registerBeanDefinition("car", tbd);
	}
	
	@Test
	public void test(){
		AbstractBean bean = (AbstractBean) beanFactory.getBean("abstractBean");
		Object expect = bean.get();
		System.out.println(Car.class == expect.getClass());
		System.out.println(bean.get() == bean.get());
		System.out.println(bean == beanFactory.getBean(BeanConsumer.class).abstractBean);
	}
	
	public static abstract class AbstractBean{
		@Lookup
		public abstract Car get();
	}
	public static class BeanConsumer{
		@Autowired
		AbstractBean abstractBean;
	}
}
