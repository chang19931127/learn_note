package me.test;

public class Demo5 {
	public static void main(String[] args) {
		String s = "abcdef";
		String sub = s.substring(2, 4);
		System.out.println("sub======" + sub);
		String sbu = s.substring(2, 4);
		System.out.println(sub == sbu);
	}
}
