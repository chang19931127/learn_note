package me.czd.spring.spring_in_action.aspectj;

import java.lang.reflect.Method;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;

/**
 * 我们编写的切面
 * @author 43994897
 *
 */
@Aspect
@Component
public class LogAspect {
    //这里有两种不同的方式来进行切面注入
    //第一种就是通过注解来进行
    @Pointcut("@annotation(me.czd.spring.spring_in_action.aspectj.Action)")
    public void annotationPointCut(){};
    
    @After("annotationPointCut()")
    public void after(JoinPoint joinPoint){
	MethodSignature signature = (MethodSignature) joinPoint.getSignature();
	Method method = signature.getMethod();
	Action action  = method.getAnnotation(Action.class);
	System.out.println("注解式拦截成功-----------------"+action.name());
    }
    
    //第二种就是直接通过 aspectj表达式来进行
    @Before("execution(* me.czd.spring.spring_in_action.aspectj.MethodService.*(..))")
    public void before(JoinPoint joinPoint){
	MethodSignature signature = (MethodSignature) joinPoint.getSignature();
	Method method = signature.getMethod();
	System.out.println("方法规则式拦截成功--------------"+method.getName());
    }
}
