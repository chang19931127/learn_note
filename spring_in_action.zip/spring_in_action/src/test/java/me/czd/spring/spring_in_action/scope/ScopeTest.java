package me.czd.spring.spring_in_action.scope;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import lombok.extern.slf4j.Slf4j;


/**
 * 测试类
 * @author 43994897
 *
 */
@Slf4j
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = ScopeConfig.class)
public class ScopeTest {
    //原形不同注入
    @Autowired
    private PrototypeService prototypeService1;
    @Autowired
    private PrototypeService prototypeService2;
    
    //单例始终注入一个
    @Autowired
    private SingletonService singletonService1;
    @Autowired
    private SingletonService singletonService2;
    
    @Test
    public void check(){
	//false
	log.info("prototypeService产生的两个对象是否相同--------"+prototypeService1.equals(prototypeService2));
	//true
	log.info("singletonService产生的两个对象是否相同--------"+singletonService1.equals(singletonService2));
    }
}
