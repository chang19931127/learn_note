package me.czd.test.bean;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

/**
 * 
 * @author 43994897 spring bean spring
 *         是一个管理bean的容器，因此也会管理bean的生命周期！，这里我们制作一个bean， 并且我们对bean的生命周期进行窥探，了解
 *         这里我们还要弄一下就是Bean的生命周期，有几个比较特殊的类
 */
//1，管理Bean生命周期的接口
/*
 * BeanFactoryAware  
 * BeanNameAware
 * InitializingBean
 * DisposableBean
 * 基本上这四个接口仅供学习使用
 */
public class Car implements BeanFactoryAware, BeanNameAware, InitializingBean,
		DisposableBean {
	private String brand;
	private String color;
	private int maxSpeed;

	public Car() {
		System.out.println("调用Car()构造函数。");
	}

	private BeanFactory beanFactory;
	private String beanName;

	public void setBrand(String brand) {
		System.out.println("调用setBrand()设置属性。");
		this.brand = brand;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public void setMaxSpeed(int maxSpeed) {
		this.maxSpeed = maxSpeed;
	}

	public String getBrand() {
		return brand;
	}

	public String getColor() {
		return color;
	}

	public int getMaxSpeed() {
		return maxSpeed;
	}

	
	
	public BeanFactory getBeanFactory() {
		return beanFactory;
	}

	public String getBeanName() {
		return beanName;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "brand[" + brand + "]---color[" + color + "]---maxSpeed["
				+ maxSpeed + "]";
	}

	// DisposableBean接口方法
	@Override
	public void destroy() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("调用DisposableBean.destory()");
	}

	// InitializingBean接口方法
	@Override
	public void afterPropertiesSet() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("调用InitializingBean.afterPropertiesSet().");
	}

	// BeanNameAware接口方法
	@Override
	public void setBeanName(String name) {
		// TODO Auto-generated method stub
		System.out.println("调用BeanNameAware.SetBeanName().");
		this.beanName = name;
	}

	// BeanFactoryAware接口方法
	@Override
	public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
		// TODO Auto-generated method stub
		System.out.println("调用BeanFactoryAware.setBeanFactory()");
		this.beanFactory = beanFactory;
	}
	
	//通过<bean>的inti-method属性指定初始化方法
	//这个 配置  替代了InitializingBean
	public void myInit(){
		System.out.println("调用init-method所指定的myInit()。将maxSpeed设置成260");
		this.maxSpeed=260;
	}
	
	//通过<bean>的destory-method属性指定销毁方法
	//这个 配置  替代了DisposableBean
	public void myDestory(){
		System.out.println("调用destory-method所指定的myDestory().");
	}

}
