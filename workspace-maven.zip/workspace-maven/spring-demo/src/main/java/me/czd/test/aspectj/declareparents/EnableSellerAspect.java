package me.czd.test.aspectj.declareparents;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.DeclareParents;

/*
 * 引介增强----------注解实现---------这里是一个切面
 */
@Aspect
public class EnableSellerAspect {

	//引介增强，为NaiveWaiter 添加接口Seller的实现
	@DeclareParents(value = "me.czd.test.aspectj.declareparents.NaiveWaiter", defaultImpl = SmartSeller.class)
	public Seller seller;
}
