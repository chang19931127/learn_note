package me.czd.spring.spring_in_action.scope;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.annotation.ComponentScan;

/**
 * 原形管理类
 * @author 43994897
 *
 */
@Configurable
@ComponentScan //默认的是当前包
public class ScopeConfig {
   
}
