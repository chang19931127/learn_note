package me.servlet;

import java.io.IOException;
import java.io.PrintStream;
import java.nio.charset.Charset;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class FirstServlet
 * 针对    web3.0时代  注解全部植入程序的时代，我们这里也是通过@WebServlet() 来替代了在web.xml中的配置
 * 毕竟tomcat7 中内置的这些jar包都比较新
 * 
 * 我们可以考虑Servlet的事情了，Servlet中有一个主要方法 service()方法，也就是说有请求都要经过的方法
 * 						doGet:用于响应客户端的get请求
 * 						doPost:用于响应客户端的post请求
 * 						doPut:用于响应客户端的put请求
 * 						doDelete:用于响应客户端的delete请求              这里千万别以为web只有get和post   因为Servlet是全面的
 * Servlet 还有
 * 						init(ServletConfig config):创建Servlet实例时，调用的初始化方法
 * 						destory():销毁Servlet实例时，自动调用的资源回收方法。
 * 											这两个方法也是很有用的，一个在资源初始化的时候使用，一个在资源回收的时候使用
 * 由于jsp的出现，因此我们的Servlet仅用来充当控制器来使用。。。。
 * 
 * 注意浏览器默认显示的编码！！！！！！否则就会出现乱码
 * 
 * 
 * 乱码解决三个要素
 * request.setCharacterEncoding("UTF-8");
 * response.setCharacterEncoding("UTF-8");
 * response.setContentType("text/html; charset=UTF-8");
 * 
 * Servlet的生命周期
 * 1，创建Servlet实例
 * 2，Web容器调用Servlet的init方法，对Servlet进行初始化。
 * 3，Servlet初始化后，将一直存在容器中，用于响应客户端请求，可以统一使用service方法来处理响应用户的请求
 * 
 * 我们基于注解
 * xml配置这么搞
 * <servlet>
 * 			<servlet-name>timerServlet</servlet-name>
 * 			<servlet-class>me.servlet.FirstServlet</servlet-class>
 * </servlet>
 * <servlet-mapping>
 * 			<servlet-name>timerServlet</servlet-name>
 * 			<url-pattern>/FirstServlet</url-pattern>
 * </servlet-mapping>
 */
@WebServlet("/FirstServlet")
public class FirstServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public FirstServlet() {
        super();
    }
//	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		response.getWriter().print("hello Servlet");
//	}
//
//	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		this.doGet(request, response);
//	}
	//其实不需要 get post put delete 我们统一交给service方法来处理
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//设置请求编码方式
		request.setCharacterEncoding("UTF-8");
		//获取name的请求参数值
		String name  = request.getParameter("name");
		System.out.println(name);
		String gender = request.getParameter("gender");
		String[] color = request.getParameterValues("color");
		String national = request.getParameter("country");
		response.setCharacterEncoding("UTF-8");
		//这个编码是通知浏览器以UTF-8来解析数据
		response.setContentType("text/html; charset=UTF-8");
		//获取页面输出流
		PrintStream out = new PrintStream (response.getOutputStream());
		String urls = new String("你好".getBytes(),"UTF-8");
		//接下来就是我们不提倡的环节
		out.println("<HTML>");
		out.println("<HEAD>");
		out.println("<TITLE>Servlet测试</TITLE>");
		out.println("</HEAD>");
		out.println("<BODY>");
		out.println("111："+name + "<hr>");
		out.println("您的姓别："+gender+"<hr>");
		out.println("您喜欢的颜色：");
//		for (String c : color) {
//			out.println(c);
//		}
		out.println("<hr>");
		out.println("您来自的国家："+national+"<hr>");
		out.println("</BODY>");
		out.println("</HTML>");
	}
}
