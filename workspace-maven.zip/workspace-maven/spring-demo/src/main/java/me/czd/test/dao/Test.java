package me.czd.test.dao;


public class Test {
	/*
	 * spring 对Dao 的支持，很好
	 * 		近些时间段，技术领域突飞猛进，很多框架都冒了出来，spring队很多持久化技术提供了继承的支持，
	 * 包括Hibernate，myBatis，JDO，JPA，此外还通过spring JDBC框架对JDBC API进行简化，Spring面向Dao
	 * 制定了通用的异常体系，屏蔽具体持久化技术的异常，是业务层和具体的持久化技术达到解耦
	 * 
	 * 
	 * 
	 * Spring DAO 异常体系
	 * 					在很多正统API或框架中，检查型异常被过多的使用，以致在使用API时，代码里充斥着大量的try/catch
	 * 
	 * Spring 数据访问模板
	 * 					在JDBC访问中很多代码都是经常重复的，因此我们需要进行经常数据连接，数据关闭，等等，因此我们需要
	 * 使用模板来进行数据访问模板访问
	 * 
	 * 
	 * 
	 * spring对Dao层的支持是很棒de ！！！！！！！！！！！！各种简化，
	 * 数据源配置
	 * xml中配置
	 * 						jdbc.properties
	 * 						jdbc.driverClassName
	 * 
	 * 						<context:property-placeholder location="/WEB-INF/jdbc.properties" />
	 * 						获取到properties，就可以在xml中直接取出来数据了
	 * 													p:driverClassName="${jdbc.driverClassName}"
	 * 					
	 * 
	 * 
	 * 
	 * 
	 */
}
