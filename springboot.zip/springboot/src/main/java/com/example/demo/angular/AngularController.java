package com.example.demo.angular;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 为angular 实例提供后台的支持
 * 
 * 涉及到angular 实例的是 view/action.html 以及被追加的文件
 * 
 * @author 43994897
 *
 */
@RestController
public class AngularController {

    @RequestMapping(value = "/search", produces = { MediaType.APPLICATION_JSON_VALUE })
    public Person search(String personName) {
	return "user".equals(personName) ? (new Person(personName, 32, " 西安市")) : null;
    }
}
