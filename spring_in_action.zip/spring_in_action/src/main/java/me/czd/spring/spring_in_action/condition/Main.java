package me.czd.spring.spring_in_action.condition;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * 测试类
 * @author 43994897
 *
 */
public class Main {
    public static void main(String[] args) {
	AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(ConditionConfig.class);
	
	System.out.println(context.getEnvironment().getProperty("os.name"));
	//这里就是先启动一个spring 容器，然后，通过这个容器来，找到环境变量
    }
}
