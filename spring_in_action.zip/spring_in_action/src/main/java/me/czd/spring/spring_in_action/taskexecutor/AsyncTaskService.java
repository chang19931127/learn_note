package me.czd.spring.spring_in_action.taskexecutor;

import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

/**
 * Service类
 * 
 * 开启注解支持 @EnableAsync
 * 
 * 这些方法就可以并发执行，而不是顺序执行
 * 
 * @author 43994897
 *
 */
@Service
public class AsyncTaskService {

    @Async
    public void executeAsyncTask(Integer i) {
	System.out.println(Thread.currentThread()+"执行异步任务：" + i);
    }

    @Async
    public void executeAsyncTaskPlus(Integer i) {
	System.out.println(Thread.currentThread()+"执行异步任务+1:" + (i + 1));
    }
}
