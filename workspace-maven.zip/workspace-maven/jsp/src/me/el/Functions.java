package me.el;

/*
 * jsp通过标签库来使用方法       jsp2.0出现的
 * 					el函数使用流程
 * 									1，创建函数的处理方法
 * 									2，创建相关的tld文件，库中追加这些方法
 * 									3，jsp中使用，加库，引入 在el中进行使用
 */
public class Functions {
	//字符串反转
	public static String reverse(String string){
		return new StringBuffer(string).reverse().toString();
	}
	//统计字符个数
	public static int countChar(String string){
		return string.length();
	}
}
