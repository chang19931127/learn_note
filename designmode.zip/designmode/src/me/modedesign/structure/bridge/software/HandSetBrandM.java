package me.modedesign.structure.bridge.software;

/*
 * ������ֻ�Ʒ��M
 */
public class HandSetBrandM extends HandSetBrand {

	@Override
	public void run() {
		soft.run();
	}
	
}
