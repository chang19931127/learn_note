package com.sys.service;

import com.spring.test.UserVo;

public interface IUserService {

	boolean add(UserVo vo);
}
