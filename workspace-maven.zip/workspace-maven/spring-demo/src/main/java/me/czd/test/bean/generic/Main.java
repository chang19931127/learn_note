package me.czd.test.bean.generic;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	public static void main(String[] args) {
		ApplicationContext beans = new ClassPathXmlApplicationContext("beanfactory/beans*.xml");
		AccountServiceImpl accountService =  (AccountServiceImpl) beans.getBean("accountServiceImpl");
		System.out.println(accountService);
		System.out.print(accountService.get().getName());
		AccountServiceImpl service = new AccountServiceImpl();
	}
}
