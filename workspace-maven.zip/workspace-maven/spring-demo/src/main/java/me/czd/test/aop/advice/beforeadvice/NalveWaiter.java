package me.czd.test.aop.advice.beforeadvice;

//服务员实例
public class NalveWaiter implements Waiter{

	@Override
	public void greetTo(String name) {
		System.out.println("greet to"+name + ".....................");
	}

	@Override
	public void serveTo(String name) {
		System.out.println("serving"+name+"...................");
	}

}
