package me.czd.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * 
 * @author 43994897 通过路径，来传递一些参数
 *         http://localhost:8080/springmvc-in-action/test/user/1/age/2.spring
 */
@Controller
public class URLMatchController {
	// http://localhost:8080/springmvc-in-action/test/user/1/age/2.spring
	@RequestMapping(value = "test/user/{user}/age/{age}")
	public String test(@PathVariable(name = "user") String userId,
			@PathVariable(name = "age") int ageValue) {
		System.out.println("userId======" + userId);
		System.out.println("ageValue======" + ageValue);
		return "index";
	}

	//使用通配符来添加功能，通配符就是我们需要的参数
	//springmvc-in-action/findUserinfo_2.spring
	@RequestMapping(value = "findUserinfo_*")
	public String findUserinfo(HttpServletRequest request) {
		String URI = request.getRequestURI();
		System.out.println("URI = " + URI);
		int beginIndex = URI.lastIndexOf("_");
		int endIndex = URI.lastIndexOf(".");
		String param = URI.substring(beginIndex + 1, endIndex);
		System.out.println("id=" + param);
		return "index";
	}
}
