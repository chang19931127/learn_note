package me.modedesign.behavior.template.exam;

public class TestPaperB extends TestPaper {

	@Override
	protected void answer1() {
		System.out.println("�𰸣�B");
	}

	@Override
	protected void answer2() {
		System.out.println("�𰸣�B");		
	}

}
