package me.springmvc.annotation.paramtype;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/*
 * @Value 邦定SpEl表达式
 * 		@Value用于将一个SpEL表达式结果映射到功能处理方法的参数上
 * 
 * 因此SpEL表达式也挺有用                            SpEL可以在运行时，查询和操作对象图
 */
@Controller
@RequestMapping("/method/param/annotation")
public class SpELValueTypeController {
	
	@RequestMapping("/value")
	public String test(@Value("#{systemProperties['java.vm.version']}") String jvmVersion){
		System.out.println(jvmVersion);
		return "success";
	}
	public static void main(String[] args) {
		System.out.println(System.getProperty("java.vm.version"));
	}
}
