package com.example.demo.transaction;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.datajpa.Person;

/**
 * 关于一个事务测试的Controller
 * 
 * @author 43994897
 *
 */
@RestController
@RequestMapping("/transaction")
public class TransactionController {

    @Autowired
    private TransactionService transactionService;

    @RequestMapping("/rollback")
    public Person rollback(Person person) {
	return transactionService.savePersonWithRollBack(person);
    }

    @RequestMapping("/norollback")
    public Person norollback(Person person) {
	return transactionService.savePersonWithoutRollBack(person);
    }
}
