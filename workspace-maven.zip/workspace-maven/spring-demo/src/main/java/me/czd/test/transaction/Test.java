package me.czd.test.transaction;

import java.util.Arrays;


public class Test {
	/*
	 * Spring声明式事务管理是Spring中的亮点，也是被使用最多的功能之一。Spring使用声明式事务平民化，
	 * 现在我们可以在Spring轻量级容器中享受这项曾经只能在臃肿，厚重的EJB应用服务器才拥有的功能
	 * 
	 * Spring事务管理是SpringAop技术的精彩应用的案例，事务管理作为一个切面植入到目标业务方法的周围，
	 * 业务方法完全从事务代码中解脱出来，代码的复杂度大大降低。被植入的事务代码基于Spring事务同步管理进行
	 * 工作，事务通过管理器维护者业务类对象线程相关的资源。DAO类需要利用资源获取工具访问底层数据连接，
	 * 或者直接建立在相应持久化模板类的基础上，要了解它们内部的机制，就必须先了解ThreadLocal工作机制
	 * 
	 * Spring的事务配置相对来说比较简单，这些配置主要提供两方面的信息，其一，切点信息，勇于定位实施事务切面
	 * 的业务类方法：其二，控制事务行为的事务属性，这些属性包括事务隔离级别，事务传播行为，超时时间，会滚规则
	 * 理解事务属性配置值的实际意义非常关键的。
	 * 
	 * Spring通过新的aop/tx Schema命名空间和@Transactional注解技术，大大简化了声明式事务配置的强度。但是，对于了解
	 * TransactionProxyFactoryBean代理类定义声明式事务的工作机制有助于理解事务增强的内部过程
	 * 
	 */
	
	public static void main(String[] args) {
		int[] a = new int[10];
		int[] b = {1,2,'a'};
		System.out.println(b[2]);
		System.out.println(Arrays.toString(b));
	}
}
