package me.czd.controller;

import sun.org.mozilla.javascript.internal.json.JsonParser;

import com.opensymphony.xwork2.ActionSupport;

import me.czd.service.UserinfoService;

/*
 * login controller
 * s使用struts2 的时候，要尽可能的去解耦
 */
public class Login extends ActionSupport {

	private static final long serialVersionUID = -7489276319273453925L;
	private String username;
	private String password;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String execute() {
		// 这里可以体现 spring 的好处
		UserinfoService userinfoService = new UserinfoService();
		if (userinfoService.login(username, password))
			return "toOKJSP";
		return "toNOJSP";
	}
	
	public void validate(){
		super.validate();
		if("".equals(this.getUsername())){
			this.addFieldError("username", "对不起用户名不可以为空");
		}
		if("".equals(this.getPassword())){
			this.addFieldError("password", "对不起密码不能为空");
			
		}
	}
}
