package me.czd.test.aop.advice.introducted;

//性能监视的控制接口
public interface Monitorable {
	void setMonitorActive(boolean active);
}
