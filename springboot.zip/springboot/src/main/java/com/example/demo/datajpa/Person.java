package com.example.demo.datajpa;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 * 我们这里使用的是正向工程 是通过实体bean 来生成表
 * 
 * @Entity 实体类
 * @Id 影射为数据库的主键
 * 
 * 
 *     这里都是使用的jpa注解
 * @author 43994897
 *
 */
@Entity
public class Person {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    private String name;

    private Integer age;

    private String address;

    public Person() {
	super();
    }

    public Person(String name, Integer age, String address) {
	super();
	this.name = name;
	this.age = age;
	this.address = address;
    }

    public Long getId() {
	return id;
    }

    public void setId(Long id) {
	this.id = id;
    }

    public String getName() {
	return name;
    }

    public void setName(String name) {
	this.name = name;
    }

    public Integer getAge() {
	return age;
    }

    public void setAge(Integer age) {
	this.age = age;
    }

    public String getAddress() {
	return address;
    }

    public void setAddress(String address) {
	this.address = address;
    }

    @Override
    public String toString() {
	return String.format("Person[id=%d,name='%s',age=%d,address='%s']", id, name, age, address);
    }

}
