package me.czd.spring.spring_in_action.event;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * 另可参见测试类
 * @author 43994897
 *
 */
public class Main {
    public static void main(String[] args) {
	AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(EventConfig.class);
	DemoPublisher demoPublisher = context.getBean(DemoPublisher.class);
	demoPublisher.publish("hello application event");
	context.close();
    }
}
