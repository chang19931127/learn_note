package me.filter;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;

/**
 * Servlet Filter implementation class LogFilter
 * Filter介绍：
 * 					Filter并不是一个标准的Servlet，它不能处理用户的请求，也不能对客户端生成相应，主要用于
 * HttpServletRequest进行预处理，也可以对HttpServletResponse进行后处理。
 * 					用途：	拦截HttpServletRequest
 * 									检查HttpServletRequst，修改Request头和数据
 * 									在HttpServletResponse到达客户端之前，拦截HttpServletResponse
 * 									检查HttpServletResponse，修改Response头和数据
 * 	常用功能：
 * 								用户授权Filter，过滤非法用户
 * 								日志Filter，详细记录某些特殊的用户请求
 * 								负责解码的Filter，包括对非标准编码的请求解码，解决乱码
 * 								能改变xml内容，内容的XSLT Filter等
 * 一个Filter可以负责拦截多个请求和响应。
 * 过程，创建Filter类，实现Filter接口                     传统的话需要进行xml配置
 * 	<filter>
 *		<filter-name>log</filter-name>
 *		<filter-class>me.filter.LogFilter</filter-class>
 *	</filter>
 *	<filter-mapping>
 *		<filter-name>log</filter-name>
 *		<url-pattern>*</url-pattern>
 *	</filter-mapping>
 * 							init(FilterConfig config)
 * 							destroy()
 * 							doFilter-----链式
 *	基于注解的情况下，更方便
 */
//@WebFilter( "*")
public class LogFilter implements Filter {
	//FilterConfig 可用于访问Filter的配置信息
	private FilterConfig config;
    public LogFilter() {
    }
    //销毁变量
	public void destroy() {
		System.out.println("消亡FilterConfig---------------------------------------------");
		config=null;
	}
	//这是真正处理的方法------是一个链式的
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		//首先观看传入的参数，可以了解到，需要进行转化成Http
		HttpServletRequest  hrequest = (HttpServletRequest) request;
		//时间
		long before = System.currentTimeMillis();
		System.out.println("开始过滤------------------------------");
		//记录日志
		ServletContext context = this.config.getServletContext();
		context.log("Filter 已经截获到用户的请求地址："+ hrequest.getServletPath());
		try {
			chain.doFilter(request, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		long after = System.currentTimeMillis();
		//记录日志
		context.log("过滤结束");
		context.log("请求被定位到"+hrequest.getRequestURL()+"所花的时间为：" +(after - before));
	}
	//初始化，传入参数
	public void init(FilterConfig fConfig) throws ServletException {
		System.out.println("加载FilterConfig---------------------------------------------");
		this.config = fConfig;
	}

}
