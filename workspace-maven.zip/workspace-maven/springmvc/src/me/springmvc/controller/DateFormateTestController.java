package me.springmvc.controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import me.springmvc.annotation.model.PhoneNumberModel;
import me.springmvc.controller.model.FormatterModel;
import me.springmvc.controller.support.editor.PhoneNumberModelEditor;
import me.springmvc.controller.support.formatter.PhoneNumber;

import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

/*
 * 因此我们的springMVC已经十分的简单了，当我们的数据如何进行转化，首先我们通过@Initbind注解来进行元素类型注入！
 * 													使得我们的后台能够得到这些数据而不是爆出 400的错误！，当我们需要在页面上显示的时候再考虑格式问题了
 */
@Controller
public class DateFormateTestController {

	//format1?totalCount=100000&discount=0.51&sumMoney=100000.128&phoneNumber=010-12345678
	//由于这里需要格式化PhoneNumber数据类型，因此我们需要将PhoneNumber注解的 那个工厂类注册
	@RequestMapping("/format1")
	public String test1(@ModelAttribute("model") FormatterModel formatModel){
		System.out.println(formatModel);
		//通过这里我们可以了解到----------格式的是用于显示的时候格式化
		return "format/success";
	}
	
	//format2?phoneNumber=010-12345678&date=2012-05-01
	@RequestMapping("/format2")
	//这里必须要追加 @RequestParam这个注解来定义参数的请求名字，负责参数就会默认传递给PhoneNumberModel中的getPhoneNumber方法了
	public String test2(@PhoneNumber@RequestParam("phoneNumber")PhoneNumberModel phoneNumber,Date date){
		System.out.println(phoneNumber);
		System.out.println(date);
		//日期也可以捕获 OhYear
		return "format/success2";
	}
	
	//为什么有这个，是因为首先你得数据一定要能够被转化
	@InitBinder
	public void intiBinder(ServletRequestDataBinder binder){
		//其实spring 需要的是    注册PropertyEditor 子类
		//注册自定义的属性编辑器
		//1,日期
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		CustomDateEditor dateEditor = new CustomDateEditor(df, true);
		//表示如果命令对象有Date类型的属性，将使用该属性编辑器进行类型替换
		binder.registerCustomEditor(Date.class, dateEditor);
		binder.registerCustomEditor(PhoneNumberModel.class, new PhoneNumberModelEditor());
	}
}
