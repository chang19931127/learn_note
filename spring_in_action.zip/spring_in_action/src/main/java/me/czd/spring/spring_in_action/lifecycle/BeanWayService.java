package me.czd.spring.spring_in_action.lifecycle;

/**
 * Bean形式的 bean生命周期
 * @author 43994897
 *
 */
public class BeanWayService {

    public void init(){
	System.out.println("@Bena init method");
    }
    
    public BeanWayService(){
	super();
	System.out.println("通过构造函数来初始化对象+BeanWayService");
    }
    
    public void destory(){
	System.out.println("@Bean destory method");
    }
}
