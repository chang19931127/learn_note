package me.czd.test.aspectj.simple;


import me.czd.test.aspectj.declareparents.Waiter;

import org.junit.Test;
import org.springframework.aop.aspectj.annotation.AspectJProxyFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/*
 * 测试类
 * 
 * 这里很明显，测试成功，
 * 
 * 
 * 
 * 测试很有意思     两个增强，一个是PreGreetingAspect  中通过java注解进行的增强
 * 																一个是通过schemal配置   使用的增强，
 * 											但是增强的切点都是相同的，因此你会看到这样的结果，哈哈哈 都了解一下吧
 */
public class Main {
	
	/*
	 * 这里是通过编程式方式获得代理，通过AspectJProxyFactory
	 */
	@Test
	public void test1(){
		Waiter target = new NaiveWaiter();
		AspectJProxyFactory factory = new AspectJProxyFactory();
		
		//设置目标对象
		factory.setTarget(target);
		
		//添加切面类
		factory.addAspect(PreGreetingAspect.class);
		
		//生成织入切面的代理对象
		Waiter proxy = factory.getProxy();
		
		proxy.greetTo("John");
		proxy.serveTo("John");
	}
	
	/*
	 * 这里我们通过 配置方式加载的，我们并且通过aop 空间下的自动生成代理，十分好用
	 * AspectJ会自动  发现 注解标示的  切面，然后去通过  切面来 代理，添加增强
	 * 
	 * <aop:aspectj-autoproxy/> 注掉的话，依旧可以运行，但是并没有被增强
	 * 
	 * 
	 * 我们这里是通过@Pointcut  定义接入点，然后再别的@Aspect 切点中，进行调用，最好使用全限定名   
	 */
	@Test
	public void test2(){
		String configLocation = "beanfactory/beans_aspectj.xml";
		ApplicationContext ctx = new ClassPathXmlApplicationContext(configLocation);
		
		Waiter target = (Waiter) ctx.getBean("waiter");
		
		target.greetTo("John");
		target.serveTo("John");
	}
	
}
