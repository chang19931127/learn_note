package me.czd.test.aop.pointcut.regexpmethod;

import me.czd.test.aop.pointcut.staticmethod.Waiter;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/*
 * 测试正则表达式方法匹配切面
 * 
 * 我们这里直接使用的就是spring提供给我们的类，我们可以直接使用，然后我们注入匹配规则值就好了
 * 
 * 	RegexpMethodPointcutAdvisor  切面
 * 可以提供多个正则表达式的值，导致我们可以  更灵活的匹配连接点！！！
 * 
 * 
 * 详细配置请参看  beans_static.xml
 */
public class Main {
	public static void main(String[] args) {
		String configLocation = "beanfactory/beans_static.xml";
		ApplicationContext ctx =  new ClassPathXmlApplicationContext(configLocation);
		Waiter waiter = (Waiter) ctx.getBean("waiter1");
		waiter.greetTo("John");
		waiter.serveTo("John");
		
		/*
		 * 这里我们的切面规则是，必须是Waiter的类或者子类，必须是greetTo方法
		 * 
		 * 这里就可以了解到
		 * 增强！Advice
		 * 切点！pointcut
		 * 切面！Advisor
		 * 以及切点如果匹配，如果管理
		 */
	}
}
