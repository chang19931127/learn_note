package me.modedesign.structure.proxy.gift;

/*
 * Ů������
 */
public class SchoolGirl {
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
