package me.czd.spring.spring_in_action.taskschedule;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

/**
 * Service
 * @author 43994897
 *
 */
@Service
public class ScheduledTaskService {
    
    //因为这里SimpleDateFormate 是线程不安全的，因此我们需要用final 来修饰确保以下
    private final SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
    
    @Scheduled(fixedRate = 5000)
    public void reportCurrentTime(){
	System.out.println("没隔五秒执行一次"+dateFormat.format(new Date()));
    }
    
    //这里使用了cron表达式
    @Scheduled(cron = "0 28 11 ? * *")
    public void fixTimeExecution(){
	System.out.println("在指定时间"+dateFormat.format(new Date())+"执行");
    }
}
