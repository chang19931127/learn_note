package me.springmvc.annotation.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/*
 * @RequestMapping来实现SimpleFormController
 * value       		是一些影射内容
 * method   		是一些请求方式
 * headers  		是请求头中必须有这个元素    != 就是没有       或者参数名=值---------------就是请求头中的数据
 * consumes		消费者参数，指明能消费得类型，通过请求头Content-Type来判断	application/xml
 * produces		生产者参数，指明生产的类型，根据请求头Accept进行匹配				application/json
 */
@Controller
@RequestMapping("/customers/**")
// 1，处理器的通用影射前缀
public class RequestMethodController {
	@RequestMapping(value = "/create", method = RequestMethod.GET)
	// 2，类级别的Mapping窄化
	public String showForm() {
		System.out.println("======================GET");
		return "customer/create";
	}

	@RequestMapping(value = "/create", method = RequestMethod.POST)
	//3，类级别的Mapping窄化
	public String submit() {
		System.out.println("====================POST");
		return "redirect:/success";
	}
	
	//可以get post同时拥有
	@RequestMapping(value = "/create|", method = {RequestMethod.GET,RequestMethod.POST})
	public String showForm1() {
		System.out.println("======================GET");
		System.out.println("====================POST");
		return "customer/create";
	}
}
