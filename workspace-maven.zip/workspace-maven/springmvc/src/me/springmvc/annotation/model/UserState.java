package me.springmvc.annotation.model;

//用户状态 领域模型
//这里是一个枚举，如果有构造方法，一定要声明构造方法
public enum UserState {
	normal("正常状态"),blocked("锁定");
	
	private String desc;
	private UserState (String desc){
		this.desc = desc;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	
	
}
