package me.czd.spring.spring_in_action.condition;

import org.springframework.context.annotation.Condition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.core.type.AnnotatedTypeMetadata;

/**
 * 了解下@Condition注解 首先需要条件，就是实现Condition接口
 * 
 * 一定要注意，spring 封装了 environment
 * 
 * @author 43994897
 *
 */
public class WindowsCondition implements Condition {

    @Override
    public boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata) {
	return context.getEnvironment().getProperty("os.name").contains("Windows 7");
    }

}
