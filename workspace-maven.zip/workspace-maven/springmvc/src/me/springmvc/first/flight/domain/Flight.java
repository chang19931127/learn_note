package me.springmvc.first.flight.domain;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.springframework.util.Assert;

/*
 * 航班类，封装了中转站类FlightLeg，一个航班经过几个中转站
 */
public class Flight {
	private List<FlightLeg> legs;//航班，包含的中转站，集合
	private BigDecimal totalCost;//总花费
	public Flight(List<FlightLeg> legs, BigDecimal totalCost) {
		Assert.notNull(legs);
		Assert.isTrue(legs.size() >=1,"Flights must have at least one leg");
		this.legs = legs;
		this.totalCost = totalCost;
	}
	//get 方法
	public BigDecimal getTotalCost() {
		return totalCost;
	}
	//判断是否不停，直飞
	public boolean isNonStop(){
		return (legs.size() == 1);
	}
	//获取第一个中转站
	public FlightLeg getFirstLeg(){
		return legs.get(0);
	}
	//获取最后一个中转站
	public FlightLeg getLastLeg(){
		return legs.get(legs.size() - 1);
	}
	//获得航班的起始飞机场
	public Airport getDepartFrom(){
		return getFirstLeg().getDepartFrom();
	}
	//获得航班的降落机场
	public Airport getArrivalAt(){
		return getLastLeg().getArriveAt();
	}
	//获取中途的中转站个数
	public int getNumberOfLegs(){
		return legs.size();
	}
	//总共的飞行时间
	public long getTotalTravelTime(){
		Date start = getFirstLeg().getDepartOn();
		Date end = getLastLeg().getArriveOn();
		Assert.isTrue(end.compareTo(start) > 0, "Start date must be before end date");
		return (end.getTime() -start.getTime());
	}
}
