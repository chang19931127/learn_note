package me.czd.test.bean.lifeCycle;

import me.czd.test.bean.Car;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;

/**
 * 
 * @author 43994897 
 * BeanPostProcessor实现类，对Bean进行管理的
 * BeanPostProcessor这个类就很巧妙，就像是插件一样，可以轻松植入bean，只需要addBeanPostProcessor()方法即可
 * 
 */
public class MyBeanPostProcessor implements BeanPostProcessor {

	@Override
	public Object postProcessBeforeInitialization(Object bean, String beanName)
			throws BeansException {
		// TODO Auto-generated method stub
		if (beanName.equals("car")) {
			Car car = (Car) bean;
			if (car.getColor() == null) {
				System.out
						.println("调用BeanPostProcessor.postProcess BeforeInitialization(),color为空,设置为默认红色。");
				car.setColor("红色");
			}
		}
		return bean;
	}

	@Override
	public Object postProcessAfterInitialization(Object bean, String beanName)
			throws BeansException {
		// TODO Auto-generated method stub
		if (beanName.equals("car")) {
			Car car = (Car) bean;
			if (car.getMaxSpeed() >= 200) {
				System.out
						.println("调用BeanPostProcessor.postProcessAfterInitialization(),将maxSpeed调整为200。");
				car.setMaxSpeed(200);
			}
		}
		return bean;
	}

}
