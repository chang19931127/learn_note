package me.czd.test.aspectj.simple;

import org.aspectj.lang.annotation.Pointcut;

/*
 * 
 * 之前我们 直接在@AspectJ中   使用哪些注解，其实都用得是匿名切点
 * 我们在这个类中声明     @Pointcut 来 创建为命名切点！！！！！！！
 * 
 * 因为命名切点在别的   增强中可以直接调用
 */
public class TestNamePointcut {
	//这里定义了一个命名切点，但由于是pirvate，因此别的地方不能使用
	@Pointcut("within(com.baobaobao.*)")
	private void inPackage() {
	}

	//这里定义了一个命名切点，
	@Pointcut("execution(* greetTo(..))")
	public void greetTo() {
		//注意，这里的方法体并不执行*
		System.out.println("我是 TestNamePointcut中的命名切点，被TestPointAspect 切面引用了");
	}

	//这里定义了命名切点，但是这个切点引用了别的 切点
	@Pointcut("inPackage() and greetTo()")
	protected void inPkgGreetTo() {
	}
}
