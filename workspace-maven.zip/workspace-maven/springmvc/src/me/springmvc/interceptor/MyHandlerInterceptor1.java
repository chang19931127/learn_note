package me.springmvc.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

/*
 * 自定义拦截器！
 * 总 接口 HandlerInterceptor，三个方法，一般我们继承默认适配HandlerInterceptorAdapter  
 * 	默认适配类，然后我们想实现那个方法，就去实现就好
 * preHandle()							预处理回调方法，第三个参数为响应的处理器
 * postHandle()						后处理回调方法，实现处理器的后处理，但是在视图渲染之前
 * afterCompletion()				整个请求的处理完毕回调方法，就是说视图渲染完毕之后
 * 
 * 
 * 如果想要实现过滤器的作用，最好去实现过滤器Filter，这个类是最通用的
 */

/*
=============================HandlerInterceptor1 preHandler
=============================HandlerInterceptor2 preHandler
==============================TestController
=============================HandlerInterceptor2 postHandler
=============================HandlerInterceptor1 postHandler
===================test.jsp
=============================HandlerInterceptor2 afterCompletion
=============================HandlerInterceptor1 afterCompletion
感受下拦截器的魔力，和方法的回调时机
 */
public class MyHandlerInterceptor1 extends HandlerInterceptorAdapter {

	@Override
	public boolean preHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler) throws Exception {
		System.out
				.println("=============================HandlerInterceptor1 preHandler");
		return true;
	}
	
	@Override
	public void postHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		System.out
				.println("=============================HandlerInterceptor1 postHandler");
	}

	@Override
	public void afterCompletion(HttpServletRequest request,
			HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		System.out
				.println("=============================HandlerInterceptor1 afterCompletion");
	}

}
