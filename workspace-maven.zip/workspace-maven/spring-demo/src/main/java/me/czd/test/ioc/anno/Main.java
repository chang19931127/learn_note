package me.czd.test.ioc.anno;

import me.czd.test.bean.Car;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;




/*
 * 全部是通过注解的,了解那些个常用的注解-----------
 * 					注册Bean
 * @Component
 * @Repostiory
 * @Service
 * @Controller
 * 					注入的
 * @Autowired
 * @Qualitier
 * @Value
 * @Required
 * @Lookup
 * 
 * 
 */

public class Main {
	//这里就是用来测试的
	public static void main(String[] args) {
		ApplicationContext ac = new  ClassPathXmlApplicationContext("beanfactory/beans_anno.xml");
		Boss boss = ac.getBean("boss", Boss.class);
		Car car1 = boss.getCar();
		System.out.println(car1);
		((ClassPathXmlApplicationContext)ac).destroy();
	}
}
