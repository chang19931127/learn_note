package me.springmvc.first.flight.web;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import me.springmvc.first.flight.service.FlightService;

import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.bind.annotation.InitBinder;

@Controller
public class SertchFlightsController {
	private FlightService flights;

	public void setFlights(FlightService flights) {
		this.flights = flights;
	}
	
	

	@InitBinder
	protected void dataBinder(HttpServletRequest req,
			ServletRequestDataBinder binder) throws Exception {
		binder.registerCustomEditor(Date.class, new CustomDateEditor(
				new SimpleDateFormat("yyyy-MM-dd HH"), true));
	}
	
}
