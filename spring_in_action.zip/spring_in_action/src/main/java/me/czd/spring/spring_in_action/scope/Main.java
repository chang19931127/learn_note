package me.czd.spring.spring_in_action.scope;


/**
 * 测试类     请看测试类
 * @author 43994897
 *
 */
public class Main {

}
