package me.czd.test.aop.proxy.jdk;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

import me.czd.test.aop.proxy.ordinary.PerformanceMonitor;

/*
 * 这里JDK中一个接口的实现类，我们在使用JDK代理类中要用到 
 */
public class PerformeanceHandler implements InvocationHandler {

	private Object target;
		
	public PerformeanceHandler(Object target) {
		super();
		this.target = target;
	}

	/**
	 * @param object 表示代理类实例
	 */
	@Override
	public Object invoke(Object object, Method method, Object[] args)
			throws Throwable {
		PerformanceMonitor.begin(target.getClass().getName()+"."+method.getName());
		
		
		Object obj = method.invoke(target, args);//执行原有的类方法
		
		PerformanceMonitor.end();
		return obj;
	}

}
