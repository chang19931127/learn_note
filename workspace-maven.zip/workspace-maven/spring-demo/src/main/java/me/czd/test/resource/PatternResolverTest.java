package me.czd.test.resource;

import java.io.IOException;

import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.core.io.support.ResourcePatternResolver;

/**
 * 
 * @author 43994897
 *	Spring 定义了一套资源加载的接口 
 *											ResourceLoader            仅仅提供了一个方法getResource(String location)
 *											相应的扩展          	ResourcePatternResolver  ......
 *																				PathMatchingResourcePatternResolver
 */
public class PatternResolverTest {
	public static void main(String[] args) {
		try {
		ResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
		//1，加载所有类包下的    xml为后缀的资源              匹配出来了资源
		//这里刚好 也可以通过路径了解下 Maven 资源的关系，src/main/resource里面的内容都回 到类路径下面
		//    **是  多路径匹配
		//classpath*:和classpath:的区别就是  带*号的是可以匹配所有路径。例如jar中的，而不带的只获取到匹配的
			Resource resources[] = resolver.getResources("classpath*:conf/**/*.xml");
			for (Resource resource : resources) {
				System.out.println(resource.getDescription());
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
