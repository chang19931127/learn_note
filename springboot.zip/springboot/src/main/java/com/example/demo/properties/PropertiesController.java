package com.example.demo.properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * springboot 通过spring 环境，来注入属性值到代码中 sb默认的是application.properties文件中
 * 
 * ${} 是站位符 #{} 是spel 表达式
 * 
 * @author 43994897
 *
 */

@RestController
@RequestMapping("properties")
public class PropertiesController {

    //直接从application.properties文件中注入
    @Value("${host}")
    private String host;

    @Autowired
    private Book book;

    @RequestMapping("/")
    public String index() {
	return "Book name is :[" + book.getName() + "]  and book author is :[" + book.getAuthor() + "]\n\t this book is "
		+ host + "!!!";
    }
}
