package me.czd.spring.spring_in_action.autoconfig;

import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

/**
 * 接口实现类并注为spring component
 * 
 * @author 43994897
 *
 */
@Slf4j
@Component
public class SgtPeppers implements CompactDisc {

    private String title = "稻香";
    private String artist = "周杰伦";

    @Override
    public void play() {
	log.info("Playing" + title + "artist" + artist);
    }

}
