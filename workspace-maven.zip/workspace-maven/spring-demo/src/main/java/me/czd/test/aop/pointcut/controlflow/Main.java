package me.czd.test.aop.pointcut.controlflow;

import me.czd.test.aop.pointcut.staticmethod.Waiter;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/*
 * 
 * 什么是流程切面，意思就是
 * 				当某些方法不被增强的时候，我们通过另外一个对象的某个方法来调用这个方法，我们并且增强，那么这写个连接点就是
 * 流程切面
 * 
 * 
 * 例如我们这个例子，我们并没有增强  serveTo()和greetTo()方法
 * 										我们仅仅通过ControlFlowPointcut 选择了某些类的某些方法，进行flow增强，
 * 										然后在DefaultPointcutAdvisor 中 注入流程切点，形成切面，然后被我们的代理工厂代理
 */
public class Main {
	public static void main(String[] args) {
		String configLocation = "beanfactory/beans_static.xml";
		ApplicationContext ctx = new ClassPathXmlApplicationContext(
				configLocation);
		Waiter waiter = (Waiter) ctx.getBean("waiter3");
		WaiterDelegate wd = new WaiterDelegate();
		wd.setWaiter(waiter);
		waiter.serveTo("Peter");
		waiter.greetTo("Petter");

		System.out.println("\n 方法单独调用不被增强，但是被某个对象调用才会增强");
		wd.service("Peter");
	}
}
