package me.czd.spring.spring_in_action.condition;

/**
 * Windows环境下的 Service
 * @author 43994897
 *
 */
public class WindowsListService implements ListService {

    @Override
    public String showListCmd() {
	return "dir";
    }

}
