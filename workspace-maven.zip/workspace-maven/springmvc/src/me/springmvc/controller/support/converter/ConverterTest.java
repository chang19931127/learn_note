package me.springmvc.controller.support.converter;

import java.util.List;

import junit.framework.Assert;
import me.springmvc.annotation.model.PhoneNumberModel;

import org.junit.Test;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.converter.ConverterRegistry;
import org.springframework.core.convert.support.DefaultConversionService;


/*
 * 数据转化的一个测试
 * 首先数据转化需要一个Service！！！！！
 * 											DefaultConversionService   继续寻找会发现这个类  实际 实现了ConversionService, ConverterRegistry这两个接口
 * 
 * 
 * ---------------------																		原数据---------------------------------------------------->目标数据
 * 																					获得到原数据的类型											获取到目标数据的类型
 */
public class ConverterTest {
	@Test
	public void testStringToPhoneNumberConvert() {
		DefaultConversionService conversionService = new DefaultConversionService();
		conversionService.addConverter(new StringToPhoneNumberConverter());
		conversionService.addConverter(new PhoneNumberToStringConverter());

		String phoneNumberStr = "010-12345678";
		PhoneNumberModel phoneNumber = conversionService.convert(
				phoneNumberStr, PhoneNumberModel.class);
		Assert.assertEquals("010", phoneNumber.getAreaCode());
		
		String number = conversionService.convert(phoneNumber, String.class);
		Assert.assertEquals("010-12345678", number);
	}

	@Test
	public void testOtherConvert() {
		//这里是一些 spring自己带的转换，因此如果是一些复杂的转换，我们才需要自己处理
		DefaultConversionService conversionService = new DefaultConversionService();
		//1 -------->true
		Assert.assertEquals(Boolean.valueOf(true), conversionService.convert("1", Boolean.class));
		//1,2,3,4------------>List
		Assert.assertEquals(4, conversionService.convert("1,2,3,4",List.class).size());
	}
}
