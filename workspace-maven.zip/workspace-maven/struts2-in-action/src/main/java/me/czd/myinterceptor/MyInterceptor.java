package me.czd.myinterceptor;

import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.AbstractInterceptor;

/**
 * 
 * @author 43994897
 *	我们自己定义的拦截器
 */
public class MyInterceptor extends AbstractInterceptor {

	private static final long serialVersionUID = 3601580684334285434L;

	@Override
	public String intercept(ActionInvocation invocation) throws Exception {
			System.out.println("start");
			String resultValue= invocation.invoke();
			System.out.println("end");
			//这里 return什么值都不影响
		return resultValue;
	}

}
