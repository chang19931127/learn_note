package me.springmvc.helloworld.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

//最简单的Controller，返回逻辑试图，并拼凑出试图的路径
public class HelloWorldController extends AbstractController {

	// 这里实现的是HandlerRequestInternal方法，在抽象父类中被HandlerRequest方法调用
	//Controller中尽量不要包含属性字段，否则可能引发线程不安全！！！
	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		// 1，收集参数
		// 2，邦定参数到命令对象
		// 3，调用业务对象
		// 4，选择下一个页面
		ModelAndView mv = new ModelAndView();
		//添加模型数据，可以使任意的pojo
		mv.addObject("message", "Hello World !!!");
		//设置逻辑试图名，视图解析器会根据名字解析到具体的视图页面
		mv.setViewName("hello");
		return mv;
	}

}
