package me.springmvc.helloworld.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

//没有返回值的Controller，直接response
public class HelloWorldWithoutReturnController extends AbstractController {

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		//直接response
		response.getWriter().write("Hello World!!!!WithoutReturn!!"+"来个中文");
		//应该可以猜出来 中文乱码
		return null;
	}

}
