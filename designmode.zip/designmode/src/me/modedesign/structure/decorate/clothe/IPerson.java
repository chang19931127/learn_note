package me.modedesign.structure.decorate.clothe;

public interface IPerson {
	void show();
}
