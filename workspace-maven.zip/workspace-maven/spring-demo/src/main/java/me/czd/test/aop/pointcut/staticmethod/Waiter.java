package me.czd.test.aop.pointcut.staticmethod;

/*
 * 想要被增强的类
 * 也可以认为是切面上的         类
 */
public class Waiter {
	public void greetTo(String name) {
		System.out.println("waiter greet to " + name + "..........");
	}
	
	public void serveTo(String name){
		System.out.println("waiter serving " + name + "..........");
	}
}
