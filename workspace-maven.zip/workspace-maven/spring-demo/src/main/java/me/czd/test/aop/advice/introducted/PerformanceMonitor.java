package me.czd.test.aop.advice.introducted;

/*
 * 性能监视的具体类
 */
public class PerformanceMonitor {
	//你要知道ThreadLocal 用于将数据邦定到线程上，因此，这个类是用来保证线程安全的方案
	private static ThreadLocal<MethodPerformance> performanceRecord = new ThreadLocal<MethodPerformance>(); 
	
	public static void begin(String method){
		System.out.println("begin    monitor");
		MethodPerformance mp = new MethodPerformance(method);
		performanceRecord.set(mp);
	}
	
	public static void end(){
		System.out.println("end     monitor");
		//通过ThreadLocal 来保存类变量，保证线程安全
		MethodPerformance mp = performanceRecord.get();
		
		//打印
		mp.printPerformance();
	}
}
