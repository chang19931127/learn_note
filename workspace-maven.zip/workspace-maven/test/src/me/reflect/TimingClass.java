package me.reflect;

public class TimingClass {
	public int m_value=0 ;
}
