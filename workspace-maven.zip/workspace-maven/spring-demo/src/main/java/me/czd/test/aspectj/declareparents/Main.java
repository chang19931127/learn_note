package me.czd.test.aspectj.declareparents;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/*
 * 引介增强，首先声明切面
 * 							@AspectJ
 * 					其次追加增强，可以基于属性   public Seller seller        @DeclareParents(目标类，接口默认实现)
 * 					最后开启注解自动代理，
 * 									直接从bean工厂取出目标类，就可以获得代理后的对象，可以强转到Seller接口下
 * 
 */
public class Main {
	public static void main(String[] args) {
		String configLocation = "beanfactory/beans_aspectj.xml";
		ApplicationContext ctx = new ClassPathXmlApplicationContext(configLocation);
		
		//已经是代理后的类
		Waiter target = (Waiter) ctx.getBean("waiter1");
		
		target.greetTo("John");
		Seller seller = (Seller) target;
		//执行接口方法
		seller.sell("Beer", "John");
	}
}
