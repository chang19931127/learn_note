package me.czd.dbutils;

import java.io.InputStream;
import java.util.Properties;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

/*
 * 由于 mybatis SqlSessionFactory是通过 SqlSessionFactoryBuilder，来进行构造的
 * 所以一般情况下，仅仅通过SqlSessionFactoryBuilder来获取SqlSessionFactory 之后就可以被回收了
 * 同样一般情况下，我们的SqlSessionFactory 整个 操作中就只有一个，因此我们把他做成单例
 */
public class MybatisUtils {
	
	private static SqlSessionFactory sqlSessionFactory;

	// sqlSession 线程不安全，因此需要，邦定ThreadLocal
	private static ThreadLocal<SqlSession> tl = new ThreadLocal<>();

	private MybatisUtils() {
	}

	//同步代码获得sqlSessionFactory   这里用到的单例
	//这里我们通过Properties文件导入了  db 这样子程序扩展性更高
	public static synchronized SqlSessionFactory getSqlSessionFactory() {
		try {
			if (sqlSessionFactory == null) {
				String propResource = "config/db.properties";
				InputStream propFile = Resources.getResourceAsStream(propResource);
				Properties prop = new Properties();
				prop.load(propFile);
				String resource = "config/mybatis-config.xml";
				// 其实这里的Resource.getResourceAsStream() 就是封装了我们 classloader 加载资源
				InputStream input = Resources.getResourceAsStream(resource);
				sqlSessionFactory = new SqlSessionFactoryBuilder().build(input,prop);
			} else {

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return sqlSessionFactory;
	}

	//获取sqlSession
	public static SqlSession getSqlSession() {
		SqlSession sqlSession = tl.get();
		if (sqlSession == null) {
			sqlSession = getSqlSessionFactory().openSession();
			tl.set(sqlSession);
		} else {

		}
		System.out.println("获取的sqlSession对象的hashCode" + sqlSession.hashCode());
		return sqlSession;
	}

	public static void commit() {
		if (tl.get() != null) {
			tl.get().commit();
			tl.get().close();
			tl.set(null);
			System.out.println(" 事务提交了");
		}
	}

	public static void rollback() {
		if (tl.get() != null) {
			tl.get().rollback();
			tl.get().close();
			tl.set(null);
			System.out.println("事务进行回滚了");
		}
	}
}
