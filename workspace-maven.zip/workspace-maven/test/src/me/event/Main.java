package me.event;

/*
 * 这里借用了  JDK  提供的  EventObject   和EventListener
 * 一个EventObject 就是一个事件，我们这个事件可以被EventListener监听
 * 于是我们需要引入一个事件发布类，这个类可以针对这个事件来增加或者删除一些监听的人，
 * 然后通过某些方法来间接调用EventListener中的方法
 * 
 * 
 * 这就是一个重要的模式，观察者模式！！！！！
 * 那么如何通知Listener 那就是publisher的事情了，因此publish就必须要有一个Listener的集合
 * 
 * 
 */
public class Main {
	public static void main(String[] args) {
		MethodExecutionEventPublisher eventPublish = new MethodExecutionEventPublisher();
		eventPublish.addMethodExecutionEventListener(new SimpleMethodExecutionEventListener());
		//不同的监听者针对事件有不同的方法，但是方法名称被接口所统一
		eventPublish.addMethodExecutionEventListener(new SimpleMethodExecutionEventListener());
		eventPublish.methodToMonitor();
	}
}
