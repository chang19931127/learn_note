package me.czd.test.aop.pointcut.staticmethod;

/*
 * 想要被增强的类 
 * 或者是切面包含的类
 */
public class Seller {
	public void greetTo(String name){
		System.out.println("seller greet to "+ name +".............");
	}
}
