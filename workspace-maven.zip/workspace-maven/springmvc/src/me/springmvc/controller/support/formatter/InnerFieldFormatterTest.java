package me.springmvc.controller.support.formatter;

import java.util.Date;
import java.util.Locale;

import junit.framework.Assert;

import me.springmvc.controller.model.FormatterModel;

import org.junit.Test;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.core.convert.TypeDescriptor;
import org.springframework.format.support.DefaultFormattingConversionService;

/*
 * 这里是用来测试 spring提供的  用于修饰字段 转换的格式测试类
 */
public class InnerFieldFormatterTest {
	@Test
	public void test() throws NoSuchFieldException, SecurityException{
		//	默认自动注册@NumberFormat 和@DateTimeFormat
		DefaultFormattingConversionService conversionService = new DefaultFormattingConversionService();
		
		//准备测试模型对象
		FormatterModel model = new FormatterModel();
		model.setTotalCount(10000);
		model.setDiscount(0.51);
		model.setSumMoney(10000.13);
		model.setRegisterDate(new Date(2012-1900,4,1));
		model.setOrderDate(new Date(2012-1900,4,1,20,18,18));
		
		//TypeDescriptor:拥有类型信息的上下文，用于Spring3类型转换系统获取类型信息(可以包含类，字段，方法，参数，属性信息)
		//意思就是我们通过TypeDescripter就可以获取到详细信息！，例如下面获取字段----------------------------------也就是封装了反射中的好多信息
		TypeDescriptor descriptor = new TypeDescriptor(FormatterModel.class.getDeclaredField("totalCount"));
		TypeDescriptor stringDescriptor = TypeDescriptor.valueOf(String.class);
		Assert.assertEquals("10,000", conversionService.convert(model.getTotalCount(), descriptor, stringDescriptor));
		Assert.assertEquals(model.getTotalCount(), conversionService.convert("10,000", stringDescriptor, descriptor));
		
		descriptor = new TypeDescriptor(FormatterModel.class.getDeclaredField("discount"));
		Assert.assertEquals("51%", conversionService.convert(model.getDiscount(), descriptor,stringDescriptor));
		Assert.assertEquals(model.getDiscount(), conversionService.convert("51%", stringDescriptor, descriptor));
		
		LocaleContextHolder.setLocale(Locale.CHINA);
		descriptor = new TypeDescriptor(FormatterModel.class.getDeclaredField("sumMoney"));
		Assert.assertEquals("￥10,000.13", conversionService.convert(model.getSumMoney(), descriptor, stringDescriptor));
		Assert.assertEquals(model.getSumMoney(), conversionService.convert("￥10,000.13", stringDescriptor, descriptor));
		LocaleContextHolder.setLocale(null);
		
		descriptor = new TypeDescriptor(FormatterModel.class.getDeclaredField("registerDate"));
		System.out.println(conversionService.convert(model.getRegisterDate(), descriptor, stringDescriptor));
		System.out.println(model.getRegisterDate());
		System.out.println(conversionService.convert("2012-04-30", stringDescriptor, descriptor));
		//这里 时间出了一点问题
		Assert.assertEquals("2012-04-30", conversionService.convert(model.getRegisterDate(), descriptor, stringDescriptor));
		Assert.assertEquals(model.getRegisterDate(), conversionService.convert("2012-04-30", stringDescriptor, descriptor));
		
		descriptor = new TypeDescriptor(FormatterModel.class.getDeclaredField("orderDate"));
		Assert.assertEquals("2012-05-01 20:18:18", conversionService.convert(model.getOrderDate(), descriptor, stringDescriptor));
		Assert.assertEquals(model.getOrderDate(), conversionService.convert("2012-05-01 20:18:18", stringDescriptor, descriptor));
		
	}
}
