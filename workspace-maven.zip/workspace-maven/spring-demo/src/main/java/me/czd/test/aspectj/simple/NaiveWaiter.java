package me.czd.test.aspectj.simple;

import me.czd.test.aspectj.declareparents.Waiter;



/*
 * 提供连接点的类
 */
public class NaiveWaiter implements Waiter {

	@Override
	public void greetTo(String name) {
		System.out.println("NaiveWaiter: greet to " + name + "...........");
	}

	@Override
	public void serveTo(String name) {
		System.out.println("NaiveWaiter: serve to " + name + "...........");		
	}

}
