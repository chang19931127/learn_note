package me.czd.test.aop.proxy.jdk;

import me.czd.test.aop.proxy.ordinary.ForumService;

/*
 * 这里是基于JDK   中动态代理 实现   aop 
 * 这里面就没有   直接将监控代码加入     业务代码中
 */
public class ForumServiceImpl implements ForumService {

	@SuppressWarnings("static-access")
	@Override
	public void removeTopic(int topicId) {
		//监控代码开始  移出
		System.out.println("模拟删除Topic 记录：" + topicId);
		try {
			Thread.currentThread().sleep(20);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		//监控代码结束 移出
	}

	@SuppressWarnings("static-access")
	@Override
	public void removeForum(int forumId) {
		//监控代码开始  移出
		System.out.println("模拟删除Forum 记录：" + forumId);
		try {
			Thread.currentThread().sleep(20);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		//监控代码结束 移出
	}
}
