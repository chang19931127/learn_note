package com.example.demo.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

/**
 * 类型安全的 properties文件注入
 * 
 * 通过spring 提供的 @PropertySource 来指定prop 文件的位置
 * 通过@ConfigurationProperties 来将properties 注入到 java代码中
 * 
 * @author 43994897
 *
 */
@Component
@PropertySource("classpath:text/book.properties")
@ConfigurationProperties(prefix = "book")
public class Book {
    private String name;
    private String author;

    public String getName() {
	return name;
    }

    public void setName(String name) {
	this.name = name;
    }

    public String getAuthor() {
	return author;
    }

    public void setAuthor(String author) {
	this.author = author;
    }

}
