package me.czd.test.bean.lifeCycle;

import me.czd.test.bean.Car;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

/*
 * 测试bean的生命周期
 * 
 * 	BeanPostProcessor 这个是针对我们的bean 进行及时构造
 * 
 * 还有BeanFactoryPostProcessor
 * 	这个就更加强大了，直接针对我们的bean 容器，进行重新构造
 * 
 */
public class BeanLifeCycleTest {
	public static void main(String[] args) {
		LifeCycleBeanFactory();
	}
	
	private static void LifeCycleBeanFactory(){
		Resource res = new ClassPathResource("beanfactory/beans.xml");
		System.out.println(res);
		BeanFactory bf = new XmlBeanFactory(res);
		
		//bean 实例
		((ConfigurableBeanFactory)bf).addBeanPostProcessor(new MyInstantiationAwareBeanPostProcessor());
		//bean
		((ConfigurableBeanFactory)bf).addBeanPostProcessor(new MyBeanPostProcessor());
		System.out.println("这里要从工厂中得到bean ");
		Car car = bf.getBean("car",Car.class);
		System.out.println("---------getBean-----------"+car);
		car.setColor("红色");
		System.out.println(car);
		
		Car car2 = bf.getBean("car", Car.class);
		
		//可以得知scope是单例
		System.out.println("car1 == car2 :----"+(car == car2));
		
		((XmlBeanFactory)bf).destroySingletons();
		
		
	}
}
