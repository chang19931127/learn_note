package me.czd.spring.spring_in_action.aspectj;

import org.springframework.stereotype.Service;

/**
 * 被注解拦截的类
 * @author 43994897
 *
 */
@Service //声明一个bean
public class AnntationService {
    @Action(name = "注解式 切面，拦截add操作")
    public void add(){
	System.out.println("方法本身");
    }
}
