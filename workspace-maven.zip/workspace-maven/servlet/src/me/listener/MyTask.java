package me.listener;

import java.util.Date;
import java.util.TimerTask;

/*
 * 一个任务，用于指定时间后使用
 */
public class MyTask extends TimerTask {

	private static boolean isRunning = false;

	@Override
	public void run() {
		if (!isRunning) {
			isRunning = true;
			System.out.println(new Date() + "       任务开始");
			for (int i = 0; i < 100; i++) {
				System.out.println(new Date() + "   任务完成" + i + "/" + 100);
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			isRunning = false;
			System.out.println(new Date() + "        任务退出！！");
		}
	}

}
