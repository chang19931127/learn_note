package com.example.demo.thymeleaf;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * thymeleaf相关的Controller
 * thymeleaf的页面配置 都被springboot自动配置了
 * 
 * 自动追加 .html
 * 
 * 默认规则模板页面在src/main/resources/templates目录下
 * 
 * thymeleaf ，静态转化成动态页面  的相关规则，请看文档
 * @author 43994897
 *
 */
@Controller
@RequestMapping("thymeleaf")
public class ThymeleafController {

    @RequestMapping("/")
    public String index(Model model){
	Person single= new Person("richard", 11);
	
	List<Person> persons = new ArrayList<Person>();
	persons.add(new Person("xx", 11));
	persons.add(new Person("yy", 22));
	persons.add(new Person("zz", 33));
	
	model.addAttribute("singlePerson", single);
	model.addAttribute("persons", persons);
	return "index";
    }
}
