package me.czd.entity;

import java.util.List;

import lombok.Data;

/**
 * 
 * @author 43994897 实体类
 */
@Data
public class Userinfo {
	private String username;
	private String password;
	private List<String> studyList;

	public Userinfo() {
		super();
	}

	public Userinfo(String username, String password) {
		super();
		this.username = username;
		this.password = password;
	}

}
