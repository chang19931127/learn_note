package me.czd.test.bean.beanfactory;

import me.czd.test.bean.Car;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.core.io.support.ResourcePatternResolver;

/**
 * 
 * @author 43994897
 *	配置Spring 容器，通过BeanFactory工厂的类，来读取xml进行 IOC容器启动
 *	当然Spring是默认有日志结构的，因此我们需要提供Log 框架，否则会有警告
 *
 *	BeanFactory其实是针对spring 框架自己的工厂，一般我们开发人员不会接触到，开发人员直接与ApplicationContext接触
 *
 *	可以知道BeanFactory的过程
 *										1，现有配置文件
 *										2，读取配置文件，装载
 *										3，就可以从配置文件中getBean
 *						之后Spring会慢慢简化这个过程
 */
public class BeanFactoryTest {
	@SuppressWarnings("deprecation")
	public static void main(String[] args) {
		ResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
		Resource res = resolver.getResource("classpath:beanfactory/beans.xml");
		//这个XmlBeanFactory已经过时
		BeanFactory bf = new XmlBeanFactory(res); 
		System.out.println("init BeanFactory");
		Car car = bf.getBean("car", Car.class);
		System.out.println("car bean is ready for usel");
		System.out.println( "car:"+car);
	}
}
