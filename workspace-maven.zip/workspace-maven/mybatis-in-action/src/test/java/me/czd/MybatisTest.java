package me.czd;

import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.Properties;

import me.czd.orm.Userinfo;
import me.czd.orm.UserinfoMapper;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

/*
 * 这里测试的就是一个最简单的配置然后，可以跑出结果的，我们的正式程序中有很多优化，什么的等等
 */
public class MybatisTest {
	private static SqlSession sqlSession;

	@BeforeClass
	public static void begin() {
		System.out.println("加载配置文件，获取sqlSession");
		String xmlResource = "prop/mybatis-config.xml";
		try {
			// 读取配置文件
			InputStream xmlFile = Resources.getResourceAsStream(xmlResource);
			// 通过SqlSessionFactoryBuilder.build()来获取SqlSessionFactory
			// -----一般sqlSessionFactory 设置为单例
			SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder()
					.build(xmlFile);
			System.out.println(sqlSessionFactory);
			sqlSession = sqlSessionFactory.openSession();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// 基于配置文件进行的操作
	@Test
	public void test() {
		Userinfo userinfo = sqlSession.selectOne(
				"me.czd.orm.UserinfoMapper.getUserinfoById", 2);
		System.out.println(userinfo.getUsername());
	}

	/*
	 * 基于配置文件之上的接口，但是接口中的方法，一定要在配置文件中id声明， 这样子就直接可以获取接口事例，去调用相关的方法
	 */
	@Test
	public void test2() {
		UserinfoMapper userinfo = sqlSession.getMapper(UserinfoMapper.class);
		System.out.println(userinfo.getUserinfoById(2).getUsername());
	}

	@Test
	public void insert() {
		Userinfo user = new Userinfo(3L, "wufei", "wufei", 18L, "2012-10-10");
		sqlSession.insert("me.czd.orm.UserinfoMapper.insertUserinfo", user);
	}

	@AfterClass
	public static void end() {
		System.out.println("提交事务，并且关闭sqlSession");
		sqlSession.commit();
		sqlSession.close();
	}
}
