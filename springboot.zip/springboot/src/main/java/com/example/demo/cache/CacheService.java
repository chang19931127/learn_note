package com.example.demo.cache;

import com.example.demo.datajpa.Person;

/**
 * 
 * 业务接口， 这里是用来帮助 测试缓存的
 * 
 * 使用的都是jpa 的一套
 * 
 * @author 43994897
 *
 */
public interface CacheService {

    Person save(Person person);

    void remove(Long id);

    Person findOne(Person person);

}
