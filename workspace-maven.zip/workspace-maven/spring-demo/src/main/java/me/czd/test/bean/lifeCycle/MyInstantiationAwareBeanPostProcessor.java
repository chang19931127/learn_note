package me.czd.test.bean.lifeCycle;

import java.beans.PropertyDescriptor;

import org.springframework.beans.BeansException;
import org.springframework.beans.PropertyValues;
import org.springframework.beans.factory.config.InstantiationAwareBeanPostProcessorAdapter;

/**
 * 
 * @author 43994897
 *	自定义processor 类，用来通过bean的行为改变，来调用一些方法
 *	实际还是BeanPostProcessor
 *	类似于回调吧            BeanPostProcessor
 */
public class MyInstantiationAwareBeanPostProcessor extends InstantiationAwareBeanPostProcessorAdapter {

	//实例化bean后调用
	@Override
	public boolean postProcessAfterInstantiation(Object bean, String beanName)
			throws BeansException {
		// TODO Auto-generated method stub
			System.out.println("InstantiationAwareBeanPostProcessor.postProcessAfterInstantiation");

		return true;
	}

	//bean 属性发生改变后调用
	@Override
	public PropertyValues postProcessPropertyValues(PropertyValues pvs,
			PropertyDescriptor[] pds, Object bean, String beanName)
			throws BeansException {

			System.out.println("InstantiationAwareBeanPostProcessor.postProcessPropertyValues");

		return pvs;
	}

	//实例化bean前调用
	@Override
	public Object postProcessBeforeInitialization(Object bean, String beanName)
			throws BeansException {
			System.out.println("InstantiationAware BeanPostProcessor.postProcessBeforeInstantiation");
		return bean;
	}
	
}
