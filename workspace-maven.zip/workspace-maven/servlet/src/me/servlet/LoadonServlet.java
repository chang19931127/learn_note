package me.servlet;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.Timer;

/**
 * Servlet implementation class TimerServlet
 * Servlet实例化的时候有两个时机，用户请求之时，或者应用自启动的时候
 * 			当Web应用启动时，可以使用load-on-startup 元素完成Servlet的初始化
 * 				load-on-startup 元素只接受一个整形值，这个整形值越小，Servlet就越优先初始化！！！
 * 这个TimerServlet的功能仅仅是一个定时器功能，每隔1000ms打印一次       这里就是自动启动。。。
 * 同样我们是使用得注解
 * 
 * 其实xml配置就是这样的
 * <servlet>
 * 			<servlet-name>timerServlet</servlet-name>
 * 			<servlet-class>me.servlet.LoadonServlet</servlet-class>
 * 			<load-on-startup>1</load-on-startup>
 * </servlet>
 */
@WebServlet(urlPatterns="/LoadonServlet",loadOnStartup=1)
public class LoadonServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public LoadonServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}
	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		Timer t = new Timer(1000, new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) {
				System.out.println("LoadonServlet"+new Date());
			}
		});
		t.start();
	}
}
