package com.example.demo.datarest;


/**
 * 
 * 这里介绍下spring data rest
 * spring data jpa 是基于 spring data repository之上的，可以将repository 自动输出为REST资源
 * 
 * spring data rest 支持很多格式
 * 
 * 在mvc 中 可以使用 extends RepositoryRestMvcConfiguration 来进行配置
 * 
 * spring boot 的话 就是引入 spring-boot-starter-data-rest 使得spring data jpa 自动输出rest
 * 
 * 可以通过properties 文件来进行某些配置
 * 
 * 会生成一些默认配置 
 * 例如我们这里 是person 资源         会默认成persons 资源但是 理论是 people 因此我们需要修改
 * @RepositoryRestResource(path="people") 通过这里修改默认路径
 * 
 * 请看我们jpa中的方法配置
 * 
 * @RestResource 注解使得我们的方法暴露rest
 * 
 * http://localhost:8080/dev/api/people/ 通过修改成people来访问
 * 
 * 暴露出的 rest 
 * get post put delete  都是符合rest 规范
 * 由一般的  crud 
 * 然后有page 分页 /?page=1&size=2
 * 有sort 排序 /?sort=age,desc
 * 
 * @author 43994897
 *
 */
public class DataRestConfig {

}
