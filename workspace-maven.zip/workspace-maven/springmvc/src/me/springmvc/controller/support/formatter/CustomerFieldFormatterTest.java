package me.springmvc.controller.support.formatter;

import junit.framework.Assert;
import me.springmvc.annotation.model.PhoneNumberModel;
import me.springmvc.controller.model.FormatterModel;

import org.junit.Test;
import org.springframework.core.convert.TypeDescriptor;
import org.springframework.format.support.DefaultFormattingConversionService;

/*
 * 这里是我们自定义格式化类，然后自定义注解去解决的测试
 */
public class CustomerFieldFormatterTest {
	
	@Test
	public void test() throws NoSuchFieldException, SecurityException{
		DefaultFormattingConversionService conversionService = new DefaultFormattingConversionService();
		//这里就要向SPI  提供注解的工厂
		conversionService.addFormatterForFieldAnnotation(new PhoneNumberFormatAnnotationFormatterFactory());
		FormatterModel model = new FormatterModel();
		TypeDescriptor descriptor = new TypeDescriptor(FormatterModel.class.getDeclaredField("phoneNumber"));
		TypeDescriptor stringDescriptor = TypeDescriptor.valueOf(String.class);
		//这一步是将 String 转化成 PhoneNumberModel对象。
		PhoneNumberModel value = (PhoneNumberModel) conversionService.convert("010-12345678", stringDescriptor, descriptor); 
		System.out.println(value);
		model.setPhoneNumber(value);
		
		Assert.assertEquals("010-12345678", conversionService.convert(model.getPhoneNumber(), descriptor,  stringDescriptor));
	}
}
