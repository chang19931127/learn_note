package com.spring.test;

import org.junit.Test;

public class TestCase {

	@Test
	public void test() {
		UserVo vo = new UserVo();
		vo.setId(1);
		vo.setName("Z");
		ServiceImpl impl = new ServiceImpl();
		impl.add(vo);
	}
	
}
