package me.czd.controller;

import java.util.ArrayList;

import org.apache.struts2.ServletActionContext;

import net.sf.json.JSONArray;

public class PrintJsonAction {
	private ArrayList<String> arrayList = new ArrayList();

	public ArrayList<String> getArrayList() {
		return arrayList;
	}

	public void setArrayList(ArrayList<String> arrayList) {
		this.arrayList = arrayList;
	}
	
	//这里，我们是提供出去
	public String execute() throws Exception{
		arrayList.add("String1");
		arrayList.add("String2");
		arrayList.add("String3");
		arrayList.add("String4");
		arrayList.add("String5");
		arrayList.add("String6");
		JSONArray jsonArray = JSONArray.fromObject(arrayList);
		ServletActionContext.getResponse().setContentType("text/html");
		ServletActionContext.getRequest().setCharacterEncoding("UTF-8");
		ServletActionContext.getResponse().getWriter().print(jsonArray);
		ServletActionContext.getResponse().getWriter().flush();
		ServletActionContext.getResponse().getWriter().close();
		return null;
	}
}
