package me.springmvc.controller.support.formatter;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/*
 * 自己定义的注解
 * 当我们自定义注解后，我们还要定义一个AnnotationFormatterFactory----这个来，来对我们的注解进行处理       
 * 实现这个类AnnotationFormatterFactory
 */
@Target({ElementType.METHOD,ElementType.FIELD,ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
public @interface PhoneNumber {
}
