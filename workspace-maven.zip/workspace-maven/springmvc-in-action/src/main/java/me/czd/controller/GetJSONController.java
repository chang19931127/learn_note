package me.czd.controller;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import me.czd.entity.Userinfo;
import net.sf.json.JSONObject;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.annotation.AnnotationMethodHandlerAdapter;
import org.springframework.web.servlet.mvc.annotation.DefaultAnnotationHandlerMapping;

import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * 
 * @author 43994897 请求获取Json
 */
@Controller
public class GetJSONController {

	// 其实这里只是获得了一个 string 符合json结构，就被解析，容易理解
	//返回json 字符串
	@RequestMapping(value = "/getJSONString",method=RequestMethod.POST,produces="text/html;charset=UTF-8")
	@ResponseBody
	public String getJSONString(String jsonString) throws IOException {
		JSONObject jsonObject = JSONObject.fromObject(jsonString);
		System.out.println(jsonObject.get("username"));
		System.out.println(jsonObject.get("password"));
		String json = jsonObject.toString();
		System.out.println(json);
		//直接过去，默认的是get请求，会乱码，因此我们需要配置
		return json;
	}

	// 需要jackson 的jar包,
	// 都需要用RequestBody
	//返回 json 对象
	@RequestMapping(value = "/getJSONObject", method = RequestMethod.POST,consumes="application/json",produces="application/json")
	@ResponseBody
	public Userinfo getJSONObject(@RequestBody Userinfo userinfoParam) {
		System.out.println("username value = " + userinfoParam.getUsername());
		System.out.println("password value = " + userinfoParam.getPassword());
		Userinfo userinfo = new Userinfo();
		userinfo.setUsername("常振东中文");
		userinfo.setPassword("密码中文");
		userinfo.setStudyList(new ArrayList<String>());
		userinfo.getStudyList().add("java");
		userinfo.getStudyList().add("delph");
		userinfo.getStudyList().add("html");
		userinfo.getStudyList().add("jQuery+JavaScript");
		return userinfo;
	}

	// 接受js数组
	@RequestMapping(value = "/getJSONArray", method = RequestMethod.POST)
	public String getJSONArray(@RequestBody ArrayList<String> list) {
		System.out.println(list.size());
		for (String string : list) {
			System.out.println(string);
		}
		return "index.jsp";
	}

	// 接收JS数组对象
	@RequestMapping(value = "/getJSONArrayObject", method = RequestMethod.POST)
	public String getJSONArrayObject(@RequestBody List<Map<String, String>> list) {

		// 这里Map可以换成Userinfo 也可以接受，这里就是换一句话说，万物都可以被Map所存储，无敌！！！！！
		// for (Userinfo userinfo : list) {
		// System.out.println(userinfo.getUsername()+":"+userinfo.getPassword());
		// }
		for (Map<String, String> map : list) {
			System.out.println(map.get("username") + ":" + map.get("password"));
		}
		return "index.jsp";
	}

	// 接受复杂对象
	//直接通过Map 就可以接受复杂对象，然后就可以去通过逐级解开，然后拿到我们需要的数据
	@RequestMapping(value = "/getJSONMulObject", method = RequestMethod.POST)
	public String getJSONMulObject(@RequestBody Map<String, ?> map) {
		System.out.println(map.get("username"));
		List<Map<String, String>> workList = (List<Map<String, String>>) map.get("work"); 
		for (Map<String, String> map2 : workList) {
			System.out.println("address="+map2.get("address"));
		}
		Map<String, String> schoolMap = (Map) map.get("school");
		System.out.println(schoolMap.get("name"));
		System.out.println(schoolMap.get("address"));
		return "index.jsp";
	}
	
}
