package me.springmvc.controller.model;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat.ISO;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.NumberFormat;
import org.springframework.format.annotation.NumberFormat.Style;

import me.springmvc.annotation.model.PhoneNumberModel;
import me.springmvc.controller.support.formatter.PhoneNumber;

/*
 * 包含Spring字段级别的解析/格式化的两个内置注解        比较常用
 * 						NumberFormat
 * 												属性：
 * 															style:      指定样式类型-------三种，通用样式，货币样式，百分数样式，默认通用
 * 															pattern:	自定义样式
 * 						DateTimeFormat
 * 												属性：
 * 															pattern:	制定解析/格式化的模板
 * 															iso:			制定解析/格式化数据的ISO模式，包括 四个     IOS.NULL
 * 															style:		指定用于格式化的样式模式，默认"ss"，具体参考Joda-Time类库
 * 													优先级：pattern      >        ISO         > style
 */
public class FormatterModel {
	@NumberFormat(style = Style.NUMBER, pattern = "#,###")
	private int totalCount;

	@NumberFormat(style = Style.PERCENT)
	private double discount;

	@NumberFormat(style = Style.CURRENCY)
	private double sumMoney;

	/*
	 * iso=ISO.DATE ----------> yyyy-MM-dd iso=ISO.TIME ---------->hh:mm:ss:SSSZ
	 * iso=ISO.DATE_TIME -------------->yyyy-MM-dd hh:mm:ss:SSSZ pattern="自定义格式"
	 * ------------->yyyy年-mm月-dd号
	 */
	@DateTimeFormat(iso = ISO.DATE)
	private Date registerDate;

	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date orderDate;

	/*
	 * 首先这个注解是我们自己定义的 ---------------- 1，按照上面的标准首先定义个注解
	 * 2，实现AnnotationFormatterFactory注解格式工厂 3，就可以使用我们的注解了
	 */
	@PhoneNumber
	private PhoneNumberModel phoneNumber;

	public int getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}

	public double getDiscount() {
		return discount;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}

	public double getSumMoney() {
		return sumMoney;
	}

	public void setSumMoney(double sumMoney) {
		this.sumMoney = sumMoney;
	}

	public Date getRegisterDate() {
		return registerDate;
	}

	public void setRegisterDate(Date registerDate) {
		this.registerDate = registerDate;
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	public PhoneNumberModel getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(PhoneNumberModel phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	@Override
	public String toString() {
		return " totalCount:" + totalCount + "\n discount:" + discount
				+ "\n sumMoney:" + sumMoney + "\n registerDate:" + registerDate
				+ "\n orderDate:" + orderDate + "\n phoneNumber:" + phoneNumber;
	}
}
