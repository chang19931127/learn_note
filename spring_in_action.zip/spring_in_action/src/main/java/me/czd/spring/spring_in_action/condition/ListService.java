package me.czd.spring.spring_in_action.condition;

/**
 * 不同系统下的Bean 类
 * @author 43994897
 *
 */
public interface ListService {
    String showListCmd();
}
