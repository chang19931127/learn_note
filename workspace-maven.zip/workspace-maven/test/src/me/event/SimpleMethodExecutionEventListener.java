package me.event;

public class SimpleMethodExecutionEventListener implements MethodExecutionEventListener {

	@Override
	public void onMethodBegin(MethodExecutionEvent evt) {
		String methodName = evt.getMethodName();
		System.out.println("start to evecute the method" + methodName);
	}

	@Override
	public void onMethodEnd(MethodExecutionEvent evt) {
		String methodName = evt.getMethodName();
		System.out.println("end to execute the method" + methodName);
	}

}
