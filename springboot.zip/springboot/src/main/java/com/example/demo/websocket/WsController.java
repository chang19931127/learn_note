package com.example.demo.websocket;

import java.security.Principal;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * WebSocket Controller 广播式 对应 ws topic 点对点式 对应 chat chat
 * 
 * @author 43994897
 *
 */
@Controller
@RequestMapping("/websocket")
public class WsController {

    // message模板
    @Autowired
    private SimpMessagingTemplate messageTemplate;

    // 这里的@MessageMapping 是为了stompClient.send 来访问的，因此和@RequestMapping没有什么关系
    @MessageMapping("/welcome")
    @SendTo("/topic/getResponse")
    public WiselyResponse say(WiselyMessage message) throws Exception {
	TimeUnit.SECONDS.sleep(1);
	return new WiselyResponse("welcome," + message.getName() + "这是广播式传输的数据");
    }

    // 点对点，就是你要知道别人是谁，需要认证
    //模拟，这里硬编码，两个人wisely 和 wfy 进行通讯
    @MessageMapping("/chat")
    public void handleChat(Principal principal, String msg) {
	if ("wyf".equals(principal.getName())) {
	    messageTemplate.convertAndSendToUser("wtf", "/queue/notifications",
		    principal.getName() + "-send:" + msg);
	} else {
	    messageTemplate.convertAndSendToUser("wyf", "/queue/notifications", principal.getName() + "-send:" + msg);
	}
    }

    @RequestMapping("/ws")
    public String ws() {
	// ws.html
	return "ws";
    }

    @RequestMapping("/chats")
    public String chat() {
	return "chat";
    }
}
