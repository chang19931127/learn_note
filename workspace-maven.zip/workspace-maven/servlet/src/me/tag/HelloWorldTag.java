package me.tag;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.tagext.TagSupport;

/*
 * 自定义标签库！
 * 				步骤：
 * 						1，开发自定义标签处理类。
 * 						2，建立一个*.tld文件，每一个文件对应一个标签库，每个标签库对应多个标签。
 * 						(可以省略了)3，在web.xml中增加自定义标签的定义(web2.5时代)        3.0时代就不需要再在xml文件中声明了
 * 						4，在jsp文件中使用自定义标签。
 * 下面我们就要开发自定义标签类了，继承父类TagSupport
 * 
 * 												几个标签返回值的意思
 * 			SKIP_BODY							：不处理标签体，直接调用doEndTag()方法
 * 			SKIP_PAGE								：忽略标签后面的jsp页面
 * 			EVAL_PAGE							：处理标签结束，直接处理页面内容
 * 			EVAL_BODY_BUFFERED	：处理标签体
 * 			EVAL_BODY_INCLUDE	：处理标签体，但忽略setBodyContent()和doInitBody()
 * 			EVAL_BODY_AGAIN			：处理标签体，循环
 */
public class HelloWorldTag extends TagSupport{

	//标签结束生成页面内容
	@Override
	public int doEndTag() throws JspException {
		try {
			//拥有pageContext 页面上下文对象
			pageContext.getOut().write("Hello World");
		} catch (IOException e) {
			e.printStackTrace();
			throw new JspTagException("错误");
		}
		return EVAL_PAGE;
	}
		
}
