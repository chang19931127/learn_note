package me.springmvc.consumesproduces;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Arrays;

import org.junit.Test;
import org.springframework.http.HttpMethod;
import org.springframework.http.client.ClientHttpRequest;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.http.client.SimpleClientHttpRequestFactory;

/*
 * 这里我们进行模拟客户端发送Json数据！！！！！！！！通过spring提供的，一般情况下我们可以使用HttpClient
 * 伴随着HttpClient的过时，我们主要开始使用HttpURLConnection jdk中就有
 */
public class ConsumesClient  {
	public static void main(String[] args) throws IOException, URISyntaxException {
		//请求的地址
		String url = "http://localhost:8080/springmvc/app/consumes";
		//1，创建Http Reqeust（内部使用HttpURLConnection）
		ClientHttpRequest request = new SimpleClientHttpRequestFactory().createRequest(new URI(url), HttpMethod.POST);
		//2，设置请求头的内容类型头和内容编码
		request.getHeaders().set("Content-Type", "application/json;charset=UTF-8");
		//3，以UTF-8的编码写出响应内容
		String jsonData="{\"username\":\"zhang\",\"password\":\"123\"}";
		request.getBody().write(jsonData.getBytes("UTF-8"));
		//上面请求的数据，被服务器端消费！！！！！！！！！！！！！！！！！！
		//4，发送请求并得到响应
		ClientHttpResponse response = request.execute();
		System.out.println(response.getStatusCode());
	}
	
	/*
	 * 这样的话，就是一个输入流，一个输出流，我们就可以没有一点问题的得到http的相应内容，
	 * 如果我们想对响应的内容去解析的话，我们就要想办法去解决HTML格式的数据，java中有一个很方便的包，就是jsoup
	 * 可以通过jsuop来进行数据解析，这样就是一个类似java爬虫的程序思路就出来了
	 */
	@Test
	public void method() throws IOException, URISyntaxException{
		String url = "http://a156e7dzzmew544.cn.hsbc/iclarity/apps/attendance/";
		ClientHttpRequest request = new SimpleClientHttpRequestFactory().createRequest(new URI(url), HttpMethod.GET);
		ClientHttpResponse response = request.execute();
		InputStream input =  response.getBody();
		byte[] buffer = new byte[1024];
		int len = 0;
		while((len =input.read(buffer)) != -1){
			System.out.println(new String(buffer,0,len));
		}
		//为什么不用这种方法尼，那是因为这个读取的话，会多读数组 后面的内容
/*		while(input.read(buffer) != -1){
			System.out.println(new String(buffer));
		}*/
	}
}
