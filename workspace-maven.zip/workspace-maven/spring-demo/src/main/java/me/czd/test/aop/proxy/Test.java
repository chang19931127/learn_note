package me.czd.test.aop.proxy;

public class Test {
	/*
	 * Spring AOP的底层就是通过JDK动态代理或CGLib动态代理技术为目标Bean
	 * 植入横切逻辑，
	 * CGLib所创建的动态代理对象的性能比JDK创建的代理对象的性能高
	 * JDK创建创建动态代理对象的时间比CGlib创建的代理对象的时间要低
	 * 因此
	 * 				针对singleton的代理对象，或者具有实例池的代理，因为无需频繁创建代理对象，适合用CGLib，
	 * 	反之使用JDK
	 * 
	 * 
	 * 
	 * 				由于CGLib采用动态创建子类的方式生成代理对象，所以不能对目标类中的final，private等方法进行代理
	 */
}
