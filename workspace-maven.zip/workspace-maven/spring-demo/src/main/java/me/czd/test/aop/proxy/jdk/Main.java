package me.czd.test.aop.proxy.jdk;

import java.lang.reflect.Proxy;

import me.czd.test.aop.proxy.ordinary.ForumService;

/*
 * 测试，我们通过JDK 提供的代理类，配合我们自己创造的InvocationHandler
 * 
 * 
 * 我们之前也学习过 JDK   的动态代理，主要就是两个    Proxy    InvocationHandler
 * 其次，我们 JDK提供的是  面向接口的 代理，也就存在代理   范围了，只能代理接口，不能代理类
 */
public class Main {
	public static void main(String[] args) {
		// 被代理对象
		ForumService target = new ForumServiceImpl();

		// 被代理对象的处理
		PerformeanceHandler handler = new PerformeanceHandler(target);

		// 生成代理
		ForumService proxy = (ForumService) Proxy.newProxyInstance(target
				.getClass().getClassLoader(),
				target.getClass().getInterfaces(), handler);

		// 下来就是 用于 监控功能的类了
		proxy.removeForum(10);
		System.out
				.println("----------------------------------------------------------------------------------");
		proxy.removeTopic(1010);
	}
}
