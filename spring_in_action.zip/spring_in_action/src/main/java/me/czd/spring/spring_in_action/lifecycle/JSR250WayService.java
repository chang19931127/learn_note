package me.czd.spring.spring_in_action.lifecycle;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.stereotype.Service;

/**
 * JSR250注解的形式来实现生命周期
 * 
 * @author 43994897
 *
 */
@Service
public class JSR250WayService {
    @PostConstruct
    public void init() {
	System.out.println("JSR250 init method");
    }

    public JSR250WayService() {
	super();
	System.out.println("通过构造函数来初始化对象+JSR250WayService");
    }

    @PreDestroy
    public void destory() {
	System.out.println("JSR250 destory method");
    }
}
