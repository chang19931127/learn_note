package me.test;

public class Demo2 {
	public static void main(String[] args) {
		flyBird b = new Bird();
	}
}

interface fly{
	void flys();
}

interface flyBird extends fly{
	void fly1();
}

class Bird implements flyBird{

	@Override
	public void flys() {
		System.out.println("sss");
	}

	@Override
	public void fly1() {
		System.out.println("ss");
	}
	
}