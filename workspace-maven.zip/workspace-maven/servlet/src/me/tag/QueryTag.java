package me.tag;

import java.io.Writer;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.TagSupport;

/*
 * 掌握了自定义标签，我们就可以写一些高级的标签了
 * 标签流程还是一样，一，标签处理类，二，tld文件，三，导入使用
 * 这里我们整一个带有属性的标签
 * 						1,带属性的标签
 * 						2,带标签体的标签
 * 带属性的标签，首先类中有属性，其次就是tld文件中要有
 */
public class QueryTag extends TagSupport {
	//两个属性
	private String driver;
	private String url;
	public String getDriver() {
		return driver;
	}
	public void setDriver(String driver) {
		this.driver = driver;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	//标签结束标签
	@Override
	public int doEndTag() throws JspException {
		try {
			Writer out = pageContext.getOut();
			out.write("driver----:"+driver);
			out.write("</br>");
			out.write("url-----:"+url);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return EVAL_PAGE;
	}
}
