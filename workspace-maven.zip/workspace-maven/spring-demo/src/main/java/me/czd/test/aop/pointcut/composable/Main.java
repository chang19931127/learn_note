package me.czd.test.aop.pointcut.composable;

import me.czd.test.aop.pointcut.controlflow.WaiterDelegate;
import me.czd.test.aop.pointcut.staticmethod.Waiter;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/*
 * 复合切面
 * 
 * 为什么会存在复合切面，是因为，一般的情况下，单独的切面很难达到我们的需求，
 * 因此，我们需要符合切面
 * 			spring提供了一个类ComposablePointcut           ----这个类就是符合切面，可以通过这个类来让许多个切点进行逻辑组合
 * 形成ygie复合 切点，然后配合增强就使复合切面，然后被我们的  代理工厂bean 进行代理
 * 然后执行逻辑！！！！
 * 
 * 
 * 
 * DefaultPointcutAdvisor --------------------我们执行自己的切面时候一般都会使用spring提供的这个切面
 * 
 * 
 * 
 * 例如下面的需求，就是流程切点，和静态切点配合的使用
 */
public class Main {
	public static void main(String[] args) {
		String configLocation = "beanfactory/beans_static.xml";
		ApplicationContext ctx = new ClassPathXmlApplicationContext(
				configLocation);
		Waiter waiter = (Waiter) ctx.getBean("waiter4");
		WaiterDelegate wd = new WaiterDelegate();
		wd.setWaiter(waiter);
		
		waiter.serveTo("Peter");
		waiter.greetTo("Peter");
		System.out.println("\n   单独调用的时候就不会增强");
		System.out.println("流程调用的时候增强，但是仅仅greetTo()方法增强，形成复合增强");
		wd.service("Peter");
	}
}
