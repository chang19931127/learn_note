package me.czd.test.aop.proxy.ordinary;

//测试
public class Main {
	public static void main(String[] args) {
		ForumService forumService = new ForumServiceImpl();
		forumService.removeForum(10);
		System.out.println("-------------------------------------------------------------------------------");
		forumService.removeTopic(1010);
		//客户端调用很正常，但是 ForumServiceImpl类实现就被性能测试类，介入了，因此我们考虑使用横切
		//我们ForumServiceImpl就是一个完美的 具有边界关系的类
		//			连接点是程序的某个特定位置：
			//如，类开始初始化前，类初始化后，类某个方法调用前，调用后，方法抛出异常后。   也就是具有特定边界的点
		//spring						仅!!!!!!!!!!!!!!!!!支持方法!!!!!!!!!!!!!!!的连接点
											//方法调用前，方法调用后，方法抛出异常时
		//																	
	}
}
