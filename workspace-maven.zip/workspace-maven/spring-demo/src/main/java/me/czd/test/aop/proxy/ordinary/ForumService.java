package me.czd.test.aop.proxy.ordinary;

/*
 * 一个具有连接点的  接口
 */
public interface ForumService {
	void removeTopic(int topicId);
	void removeForum(int forumId);
}
