package me.springmvc.annotation.paramtype;

import java.util.Arrays;

import me.springmvc.annotation.model.UserModel;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/*
 * 这里是redirect是重定向！！！！！！！！！！！
 * 
 */
@Controller
@RequestMapping("/method/param/annotation")
public class RedirectAttributesTypeController {
	
	@RequestMapping(value="/redirect1")
	public String test1(Model model ){
		model.addAttribute("username","zhang");
		model.addAttribute("role",Arrays.asList("admin","user"));
		return "redirect:redirectSuccess";
	}
	
	@RequestMapping(value="/redirect2")
	public String test2(RedirectAttributes redirectAttributes){
		UserModel user = new UserModel();
		user.setUsername("zhang");
		user.setPassword("123");
		redirectAttributes.addFlashAttribute("user", user);
		//其实RedirectAttribute的一个实现类就是RedirectAttributesModelMap 就是一个ModelMap
		return "redirect:redirectSuccess";
	}
	
	@RequestMapping(value="/redirect3")
	public String edit (RedirectAttributes redirectAttributes){
		redirectAttributes.addAttribute("userId",123);
		return "redirect:redirectSuccess";
	}
	
	@RequestMapping(value="/redirectSuccess")
	//这里相当于 从ModelMap中取出user
	public String success( @ModelAttribute("user")UserModel user){
		System.out.println(user);
		return "success";
	}
}
