package me.czd.spring.spring_in_action.event;

import org.springframework.context.ApplicationEvent;

/**
 * 事件源
 * 
 * @author 43994897
 *
 */
public class DemoEvent extends ApplicationEvent {

    private static final long serialVersionUID = 1011330511561031061L;
    private String msg;

    public DemoEvent(Object source, String msg) {
	super(source);
	this.msg = msg;
    }

    public String getMsg() {
	return msg;
    }

    public void setMsg(String msg) {
	this.msg = msg;
    }

}
