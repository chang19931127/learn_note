package me.springmvc.annotation.paramtype;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

/*
 * @PathVariable  -----邦定URL模板变量值                            用于将请求URL中的模板变量映射到功能处理方法的参数上
 * @PathVariable 中的常用参数值
 * value :PathVariable名称
 * 
 * 一般value 就是对应的修饰的参数值
 */
@Controller
@RequestMapping("/method/param/annotation")
public class PathVariableTypeController {
	@RequestMapping(value="/users/{userId}/topics/{topicId}")
	public String test(@PathVariable int userId,@PathVariable int topicId){
		System.out.println("userId="+userId +",topicId="+topicId);
		return "success";
		//获取URL中的值
		//method/param/annotation/users/123/topics/456
		//userId=123,topicId=456
	}
}
