package com.example.demo.cache;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.datajpa.Person;

/**
 * 前台Controller
 * 
 * 一个简单的调用CacheService 进行操作
 * 
 * 只要进行了缓存，那么下次访问就不会再去通过sql 去查询了，
 * 
 * 如果我们不是通过缓存的方式去  更新数据，然后再去 查询，同样还是获得的cache ，
 * 因此更新的时候需要将这个缓存删除掉
 * 
 * @author 43994897
 *
 */
@RestController
@RequestMapping("/cache")
public class CacheController {

    @Autowired
    CacheService cacheService;

    @RequestMapping("/put")
    public Person put(Person person) {
	return cacheService.save(person);
    }

    @RequestMapping("/able")
    public Person cacheable(Person person) {
	return cacheService.findOne(person);
    }

    @RequestMapping("/evit")
    public String evic(Long id) {
	cacheService.remove(id);
	return "ok";
    }
}
