package me.simplemvc;

import java.io.ByteArrayInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/*
 * 当作是数据访问层
 * 结合我们的Derby数据库
 */
public class DbDao {
	// 单例模式
	private static DbDao op;

	// 数据库信息
	private Connection conn;
	private String driver;
	private String url;
	private String username;
	private String password;

	// 构造器私有为了单例
	private DbDao() {
		super();
	}

	private DbDao(String driver, String url, String username, String password) throws Exception {
		super();
		this.driver = driver;
		this.url = url;
		this.username = username;
		this.password = password;
		Class.forName(driver);
		conn = DriverManager.getConnection(url, username, password);
	}

	// get set
	public Connection getConn() {
		return conn;
	}

	public void setConn(Connection conn) {
		this.conn = conn;
	}

	public String getDriver() {
		return driver;
	}

	public void setDriver(String driver) {
		this.driver = driver;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	// 获取数据库联接
	public void getConnection() throws Exception {
		if (conn == null) {
			Class.forName(this.driver);
			conn = DriverManager.getConnection(this.url, this.username,
					this.username);
		}
	}

	// 实例话Dao的入口
	public static DbDao instance() {
		if (op == null) {
			op = new DbDao();
		}
		return op;
	}

	public static DbDao instance(String driver, String url, String username,
			String password) throws Exception {
		if (op == null) {
			op = new DbDao(driver, url, username, password);
		}
		return op;
	}
	
	//插入记录
	public boolean insert(String sql ) throws Exception{
		getConnection();
		Statement statement = conn.createStatement();
		if(statement.executeUpdate(sql) != 1){
			return false;
		}
		return true;
	}
	
	//执行查询
	public ResultSet query(String sql) throws Exception{
		getConnection();
		Statement statement = conn.createStatement();
		return statement.executeQuery(sql);
	}
	
	//执行查询
	public void delete(String sql ) throws Exception{
		getConnection();
		Statement statement = conn.createStatement();
		statement.executeUpdate(sql);
	}
	
	//执行更新
	public void update(String sql ) throws Exception{
		getConnection();
		Statement statement = conn.createStatement();
		statement.executeUpdate(sql);
	}
	
}
