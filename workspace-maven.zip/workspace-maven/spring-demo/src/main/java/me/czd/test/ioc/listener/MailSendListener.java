package me.czd.test.ioc.listener;

import org.springframework.context.ApplicationListener;
import org.springframework.context.event.EventListener;

/*
 * 邮件发送监听器
 * 同样 我们spring 提供了 自己的 ApplicationListener<ApplicationEvent>
 * 
 * ApplicationListener 封装了JDK 提供的 EventListener   并提供了一个响应事件的方法
 */
public class MailSendListener implements ApplicationListener<MailSendEvent>{

	@Override
	public void onApplicationEvent(MailSendEvent event) {
		System.out.println("MailSendListener:向"+event.getTo()+"发送完一封邮件！");
	}
	
	@EventListener()
	public void doit(MailSendEvent event) {
		System.out.println("通过注解实现的 "+event.getTo()+"发送完一封邮件！");
	}
	
	@EventListener(MailSendEvent.class)
	public void doitwithout() {
		System.out.println("通过注解实现的 "+"注解中提供事件参数"+"发送完一封邮件！");
	}

}
