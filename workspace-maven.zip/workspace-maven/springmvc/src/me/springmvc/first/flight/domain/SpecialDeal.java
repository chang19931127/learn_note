package me.springmvc.first.flight.domain;

import java.math.BigDecimal;
import java.util.Date;

import org.springframework.util.Assert;

/*
 * 特价航班
 * javabean 这里  如同Airport类一样     不可变
 * 	这里有一个要点，就是针对货币类型的数据，我们就来用BigDecimal来表示其类型，因为这个类可以精确控制舍入
 * 
 */
public class SpecialDeal {
	private Airport departFrom;	//起始飞机场
	private Airport arriveAt;			//到达飞机场
	private BigDecimal cost;			//花费
	private Date beginOn;				//时间开始
	private Date endOn;					//时间结束
	public SpecialDeal(Airport departFrom, Airport arriveAt, BigDecimal cost,
			Date beginOn, Date endOn) {
		super();
		this.departFrom = departFrom;
		this.arriveAt = arriveAt;
		this.cost = cost;
		this.beginOn = beginOn;
		this.endOn = endOn;
	}
	//只提供部分 get方法
	public Airport getDepartFrom() {
		return departFrom;
	}
	public Airport getArriveAt() {
		return arriveAt;
	}
	public BigDecimal getCost() {
		return cost;
	}
	
	public boolean isValidNow(){
		return isValidOn(new Date());
	}
	//判断当前时间是否特价
	public boolean isValidOn(Date date){
		Assert.notNull(date, "Date must not be null");
		Date dateCopy = new Date(date.getTime());
		//使用副本来保证数据的不可变性，
		return ((dateCopy.equals(beginOn)) || dateCopy.after(beginOn)) &&(dateCopy.equals(endOn) || dateCopy.before(endOn));
	}
}
