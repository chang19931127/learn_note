package com.sys.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.annotation.JsonView;
import com.rometools.rome.feed.atom.Feed;
import com.spring.test.UserVo;
import com.sys.service.IUserService;
import com.sys.vo.JsonVo;
import com.sys.vo.XmlVo;


@Controller
public class BaseController {

	@Autowired
	private IUserService userService;
	
	@RequestMapping(value="/testJson")
	@ResponseBody
	public JsonVo getJson(HttpServletRequest request) {
		JsonVo vo = new JsonVo();
		vo.setId(1);
		vo.setName("json jackson");
		vo.setMobile("1314521");
		vo.setBirthday(new Date());
		System.out.println(vo);
		return vo;
	}
	
	@RequestMapping(value="/testXml")
	@ResponseBody
	public XmlVo getXml() {
		XmlVo vo = new XmlVo();
		vo.setId(1);
		vo.setName("xml jackson");
		vo.setMobile("1314521");
		vo.setBirthday(new Date());
		System.out.println(vo);
		return vo;
	}
	
	
	@RequestMapping(value="/testAtom")
	@ResponseBody
	public  Feed writeFeed() {
		Feed feed = new Feed();
		feed.setFeedType("atom_1.0");
		feed.setTitle("My Atom feed");
		return feed;
	}
	
	@RequestMapping(value="/main")
	@ResponseBody
	public UserVo main() {
		UserVo vo = new UserVo();
		vo.setId(1);
		vo.setName("json jackson");
		userService.add(vo);
		return vo;
	}
	
	@RequestMapping(value="/helloworld")
	@ResponseBody
	public List<String> getString(HttpServletRequest request) {
		List<String> list = new ArrayList<>();
		list.add("开心");
		list.add("完美");
		System.out.println(list);
		return list;
	}
}
