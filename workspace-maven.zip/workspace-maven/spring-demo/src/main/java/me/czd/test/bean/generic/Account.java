package me.czd.test.bean.generic;

public class Account {
	private Integer aid;
	private String name;

	public Account() {
		super();
	}

	public Account(Integer aid, String name) {
		super();
		this.aid = aid;
		this.name = name;
	}

	public Integer getAid() {
		return aid;
	}

	public void setAid(Integer aid) {
		this.aid = aid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	
}
