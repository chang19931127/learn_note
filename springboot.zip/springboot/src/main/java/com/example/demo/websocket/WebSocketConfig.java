package com.example.demo.websocket;

import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.web.socket.config.annotation.AbstractWebSocketMessageBrokerConfigurer;
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;

/**
 * WebSocket先要了解下什么是WebSocket 全双工 通讯，专门针对浏览器和服务器提供的
 * 
 * 使用SocketJs 来屏蔽更多复杂的内容
 * 
 * 正常的webSocket比较复杂，所以出现一个STOMP子协议，类似于 http req resp 等
 * 
 * 这里是spring 的配置WebSocket，
 * 
 * WebSocket有两种方式，一种广播式，一种点对点式
 * topic and endpointWisely 用于广播式
 * queue and endpointChat  用于点对点式
 * 
 * this is 广播式
 * @author 43994897
 *
 */
@Configuration
@EnableWebSocketMessageBroker
public class WebSocketConfig extends AbstractWebSocketMessageBrokerConfigurer {

    @Override
    public void registerStompEndpoints(StompEndpointRegistry registry) {
	//暴露一个端点给 WebSocket  绝对,前台socket 一定要路径找对
	registry.addEndpoint("/endpointWisely").withSockJS();
	registry.addEndpoint("/endpointChat").withSockJS();
	
    }

    @Override
    public void configureMessageBroker(MessageBrokerRegistry registry) {
	//配置消息代理    
	registry.enableSimpleBroker("/topic","/queue");
	//registry.setApplicationDestinationPrefixes("/app");//这里决定了@MessageMapping注解 目标
    }

}
