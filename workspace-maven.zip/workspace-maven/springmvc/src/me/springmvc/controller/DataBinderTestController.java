package me.springmvc.controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import me.springmvc.annotation.model.DataBinderTestModel;
import me.springmvc.annotation.model.PhoneNumberModel;
import me.springmvc.controller.support.editor.PhoneNumberModelEditor;

import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class DataBinderTestController {
	
	//dataBind?username=zhang&bool=yes&schoolInfo.specialty=computer&hobbyList[0]=program&hobbyList[1]=music&map[key1]=value1&map[key2]=value2&phoneNumber=010-12345678&date=2016-3-18 16:48:48&state=blocked
	@RequestMapping("/dataBind")
	public String test(DataBinderTestModel command,Model model){
		//输出command查看是否邦定成功
		System.out.println(command);
		model.addAttribute("dataBinderTest", command);
		return "bind/success";
	}
	
	@InitBinder
	public void intiBinder(ServletRequestDataBinder binder){
		//其实spring 需要的是    注册PropertyEditor 子类
		//注册自定义的属性编辑器
		//1,日期
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		CustomDateEditor dateEditor = new CustomDateEditor(df, true);
		//表示如果命令对象有Date类型的属性，将使用该属性编辑器进行类型替换
		binder.registerCustomEditor(Date.class, dateEditor);
		binder.registerCustomEditor(PhoneNumberModel.class, new PhoneNumberModelEditor());
	}
}
