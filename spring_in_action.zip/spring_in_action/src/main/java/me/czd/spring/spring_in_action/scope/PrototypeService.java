package me.czd.spring.spring_in_action.scope;

import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

/**
 * 原形类
 * @author 43994897
 *
 */
@Service
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)//原形
public class PrototypeService {

}
