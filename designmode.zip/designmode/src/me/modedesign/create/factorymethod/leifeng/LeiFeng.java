package me.modedesign.create.factorymethod.leifeng;

//�׷游��
public class LeiFeng {
	public void sweep(){
		System.out.println("ɨ��");
	}
	
	public void wash(){
		System.out.println("ϴ��");
	}
	
	public void buyRice(){
		System.out.println("����");
	}
}
