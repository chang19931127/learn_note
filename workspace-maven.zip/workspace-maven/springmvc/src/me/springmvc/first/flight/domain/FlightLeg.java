package me.springmvc.first.flight.domain;

import java.util.Date;

/*
 * 中转站类，也就是航班飞行中的 中转站          
 * 不可变
 */
public class FlightLeg {
	private Airport departFrom;	//起飞
	private Date departOn;			//起飞时间
	private Airport arriveAt;			//降落
	private Date arriveOn;				//降落时间
	public FlightLeg(Airport departFrom, Date departOn, Airport arriveAt,
			Date arriveOn) {
		this.departFrom = departFrom;
		this.departOn = departOn;
		this.arriveAt = arriveAt;
		this.arriveOn = arriveOn;
	}
	public Airport getDepartFrom() {
		return departFrom;
	}
	public Date getDepartOn() {
		return departOn;
	}
	public Airport getArriveAt() {
		return arriveAt;
	}
	public Date getArriveOn() {
		return arriveOn;
	}
	
}
