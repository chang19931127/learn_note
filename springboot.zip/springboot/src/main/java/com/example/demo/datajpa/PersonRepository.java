package com.example.demo.datajpa;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.data.rest.core.annotation.RestResource;

/**
 * 
 * JpaRepository 也就是为jpa 提供的接口把，
 * 然后JpaRepository 支持 接口中的方法名来定义查询的，而方法名是根据尸体类的属性来确定的。
 * findByXXXXX 等等就是 查找
 * 
 * JpaRepository 上面是接口 PagingAndSortingRepository extends CrudRepository
 * 
 * 其实这些也基于RepositoryFactory   当然有了factory 就需要有RepositoryFactoryBean
 * 
 * @author 43994897
 *
 */
@RepositoryRestResource(path="people")
public interface PersonRepository extends JpaRepository<Person, Long> {

    List<Person> findByAddress(String name);

    Person findByNameAndAddress(String name, String address);
    
    //根据参数 的前缀进行 query  然后将这个方法 暴露出去
    @RestResource(path="nameStartsWith",rel="nameStartsWith")
    List<Person> findByNameStartsWith(@Param("name") String name);

}
