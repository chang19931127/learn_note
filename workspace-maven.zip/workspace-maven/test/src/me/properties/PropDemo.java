package me.properties;

import java.util.Properties;

public class PropDemo {
	public static void main(String[] args) throws Exception {
		Properties prop = new Properties();
		prop.load(ClassLoader.getSystemResourceAsStream("me/properties/prop.properties"));
		System.out.println(prop.getProperty("a"));
	}
}
