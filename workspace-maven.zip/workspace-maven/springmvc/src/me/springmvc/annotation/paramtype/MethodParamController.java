package me.springmvc.annotation.paramtype;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Writer;
import java.security.Principal;
import java.util.Map;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import me.springmvc.annotation.model.UserModel;

import org.springframework.cglib.core.Local;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/method/param")
public class MethodParamController {
	@RequestMapping("/requestOrResponse")
	public String requestOrResponse(ServletRequest servletRequest,
			HttpServletRequest httpServletRequest,
			ServletResponse servletResponse,
			HttpServletResponse httpServletResponse) {
		// 这里就是获取Servlet API 相关的请求/相应,这里就可以直接调用
		System.out.println(servletRequest.getClass().getName());
		System.out.println(servletResponse.getClass().getName());
		System.out.println(httpServletRequest.getClass().getName());
		System.out.println(httpServletResponse.getClass().getName());
		return "success";
	}

	@RequestMapping("/inputOrOutBody")
	public void inputOrOutBody(InputStream requestBodyIn,
			OutputStream responseBodyOut) throws IOException {
		responseBodyOut.write("success！！！！byte".getBytes());
	}

	@RequestMapping("/readerOrWriterBody")
	public void readerOrWriteBody(Reader reader, Writer writer)
			throws IOException {
		writer.write("hello!!!!!!!这是SpringMVC通过获取字符流流的方式搞的 ");
	}

	@RequestMapping("/webRequest")
	public String webRequest(WebRequest webRequest,
			NativeWebRequest nativeWebRequest) {
		System.out.println(webRequest.getParameter("test"));// 得到的是请求参数test的值
		webRequest.setAttribute("name", "value", WebRequest.SCOPE_REQUEST);
		System.out.println(webRequest.getAttribute("name",
				WebRequest.SCOPE_REQUEST));
		HttpServletRequest request = nativeWebRequest
				.getNativeRequest(HttpServletRequest.class);
		HttpServletResponse response = nativeWebRequest
				.getNativeResponse(HttpServletResponse.class);
		System.out.println(request.getClass().getName());
		System.out.println(response.getClass().getName());
		// 获取到了 request 和response
		return "success";
	}

	@RequestMapping("/session")
	public String session(HttpSession session) {
		System.out.println(session.getClass().getName());
		return "success";
	}

	@RequestMapping(value = "/commandObject", method = RequestMethod.GET)
	public String toCreateUser(HttpServletRequest request, UserModel user) {
		System.out.println(user);
		return "customer/create";
	}

	@RequestMapping(value = "/commandObject", method = RequestMethod.POST)
	public String createUser(HttpServletRequest request, UserModel user) {
		//SpringMVC是十分灵活的，例如我们直接get ? username=asd 就可以直接 邦定到UserModel中的username，因此我们一定要注意命名
		System.out.println(user);
		return "customer/create";
	}

	@SuppressWarnings("unchecked")
	@RequestMapping("model")
	public String createUser(Model model, Map model2,
			ModelMap model3) {
		model.addAttribute("a", "a");
		model2.put("b", "b");
		model3.put("c", "c");
		System.out.println("model =model2--------" + (model == model2));//true
		System.out.println( "model2 == model3--------"+(model2 == model3) );//true
		//得到的结论就是  Model Map ModelMap 三个类的实现类都是一个
		return "success";
	}
	
	@RequestMapping("/mergeModel")
	public ModelAndView mergeModel(Model model){
		model.addAttribute("a", "a");//添加模型数据
		ModelAndView mv = new ModelAndView("success");
		mv.addObject("a", "update");//在渲染视图之前进行更新
		model.addAttribute("a", "new");//修改a 的模型数据
		//视图页面的a将显示"update"而不是"new"
		return mv;
	}
	
	@RequestMapping("/error1")
	public String error1(UserModel user,BindingResult result){
		return "success";
	}
	
	@RequestMapping("/error2")
	public String error2(UserModel user,BindingResult result,Model model){
		return "success";
	}
	
	@RequestMapping("/error3")
	public String error3(UserModel user,Errors errors){
		return "success";
	}
	
	//这个代码在3.1之前抛出BindingResult 错误，现在貌似正常工作
	@RequestMapping("/error4")
	public String error4(UserModel user,Model	 model,Errors errors){
		return "success";
	}
	
	@RequestMapping("/other")
	public String other(Local local,Principal principal){
		System.out.println(local);
		System.out.println(principal);
		return "success";
	}
}
