package me.springmvc.annotation.paramtype;

import me.springmvc.annotation.model.UserModel;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.context.request.WebRequest;

/*
 * @SessionAttributes 邦定命令对象到session
 * 				有时候，我们需要在多个请求之间保持数据，一般情况需要我们明确的调用HttpSession的API来存取会话，如多步骤提交的表单
 * SpringMVC 提供了@SessionAttribute进行请求间透明的存取会话数据。
 * 				常用属性
 * value -----表示模型数据中的名字
 * types -----表示模型数据中的那些类型的对象存储到会话范围内，                  就是对存到会话中的数据进行匹配
 * 
 * 
 */
@Controller
@RequestMapping("/method/param/annotation")
@SessionAttributes(value = { "user" }, types = {})
// 1，标识模型对象中名字如果是"user"将存储在会话范围，并暴露到模型数据中
public class SessionAttributeTypeController {

	//这里如果注掉，就会报错了 ，原因--- 因为标记了@SessionAttribute 因此 该对象的session 是required 因此必须存在，没有的话，就会异常
	@ModelAttribute("user")
	// 2,如果模型中没有user的对象，调用该方法，并存储到模型数据中
	public UserModel initUser() {
		System.out.println("哈哈，这里是最先走的，如果session没有指定对象，就在这里new了0.0");
		return new UserModel();
	}

	@RequestMapping("session1")
	// 3,首先查找模型数据中是否有user对象，有直接使用，没有则创建一个，并将请求参数邦定到该对象上。
	public String session1(@ModelAttribute("user") UserModel user,
			ModelMap model, WebRequest request, SessionStatus status) {
		System.out.println("user == model.get(\"user\")------------------"+(user == model.get("user")));//true
		user.setUsername("zhang");
		return "success";
	}

	@RequestMapping("session2")
	public String session(@ModelAttribute("user") UserModel user,
			ModelMap model, WebRequest request, SessionStatus status) {
		System.out
				.println("(user == request.getAttribute(\"user\",WebRequest.SCOPE_SESSION--------------"
						+ (user == request.getAttribute("user",
								WebRequest.SCOPE_SESSION)));//true
		System.out.println("user == model.get(\"user\")-----------------"
				+ (user == model.get("user")));//true
		System.out.println(user);
		System.out.println((UserModel)model.get("user"));
		System.out.println((UserModel)request.getAttribute("user", WebRequest.SCOPE_SESSION));
		if (true) {
			// 4,如果会话可以终止，就标识会话结束，可以清理掉会话数据了
			status.setComplete();
		}
		return "success";
	}
}
