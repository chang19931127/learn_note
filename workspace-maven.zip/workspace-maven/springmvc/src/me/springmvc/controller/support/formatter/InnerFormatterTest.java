package me.springmvc.controller.support.formatter;


import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.ParseException;
import java.util.Date;
import java.util.Locale;

import junit.framework.Assert;

import org.junit.Test;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.format.datetime.DateFormatter;
import org.springframework.format.number.CurrencyFormatter;
import org.springframework.format.number.NumberFormatter;
import org.springframework.format.number.PercentFormatter;
import org.springframework.format.support.DefaultFormattingConversionService;

/*
 * 在这里，我们就是测试一下spring内部提供的一些Formatter 测试
 * 
 * 并且这里使用了一个DefaultFormattingConversionService  来帮我们对类型转换进行了管理
 * 
 * 两个重要的接口  Printer Prints objects of type T for display.						展示对象
 * 										 Parser  Parses text strings to produce instances of T.  解析string
 */
public class InnerFormatterTest {
	
	public void testNumber(){
		NumberFormatter numberFormatter  = new NumberFormatter("#,##0.##");
		CurrencyFormatter currencyFoematter = new CurrencyFormatter();
		PercentFormatter percentFormatter = new PercentFormatter();
		//现在这三个类 都已经是过去时
	}
	
	@Test
	public void testDate() throws ParseException{
		DateFormatter dateFormatter = new DateFormatter("yyyy-MM-dd");
		//字符串-------------->Date类
		Assert.assertEquals(new Date(2012-1900,4,1), dateFormatter.parse("2012-05-01", Locale.CHINA));
		//Date类---------------->字符串
		Assert.assertEquals("2012-05-01", dateFormatter.print(new Date(2012-1900,4,1), Locale.CHINA));
	}
	
	//SPI
	@Test
	public void testWithDefaultFormattingConversionService(){
		DefaultFormattingConversionService conversionService = new DefaultFormattingConversionService();
		//默认的是不自动注册任何Formatter
		CurrencyFormatter currencyFormatter = new CurrencyFormatter();
		currencyFormatter.setFractionDigits(2);//保留小数点后2 位
		currencyFormatter.setRoundingMode(RoundingMode.CEILING);//舍入模式，ceiling表示的是四舍五入
		//添加
		conversionService.addFormatter(currencyFormatter);
		
		//邦定Locale信息到ThreadLocal       ---------------------------->可以去查看这个类，实际情况是被存放在ThreadLocal中
		//FormattingConversionService内部自动获取作为Locale信息，如果不设置默认值是 Locale.getDefault()
		LocaleContextHolder.setLocale(Locale.US);
		Assert.assertEquals("$1,234.13", conversionService.convert(new BigDecimal("1234.128"), String.class));
		LocaleContextHolder.setLocale(null);
		LocaleContextHolder.setLocale(Locale.CHINA);
		Assert.assertEquals("￥1,234.13", conversionService.convert(new BigDecimal("1234.128"), String.class));
		Assert.assertEquals(new BigDecimal("1234.13"), conversionService.convert("￥1,234.13", BigDecimal.class));	
		LocaleContextHolder.setLocale(null);
	}
}
