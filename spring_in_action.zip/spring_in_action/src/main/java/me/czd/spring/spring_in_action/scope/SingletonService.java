package me.czd.spring.spring_in_action.scope;

import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

/**
 * 期望的单利类
 * @author 43994897
 *
 */
@Service
//@Scope(ConfigurableBeanFactory.SCOPE_SINGLETON)//spring默认的是单例
public class SingletonService {

}
