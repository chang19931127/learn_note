package me.springmvc.annotation.paramtype;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

/*
 * @RequestParam:                        邦定单个请求参数值，用于将请求参数区数据映射到功能处理方法的参数上！！
 * 如：/requestparam1?username=zhang，则自动传入
 * 几个参数：
 * value -----参数名字
 * required -----是否必须
 * defaultValue -----默认值 ---可以使spEL表达式
 * 
 * 如果请求的参数值，是集合的话，尽可能的封装到类中，这样的话报错的时候也好解决
 */
@Controller
@RequestMapping("/method/param/annotation")
public class RequestParamTypeController {

	//这里不写@RequestParam注解也可以，但是请求参数的名字一定要是username才可以接受
	//其实换句话所就是，@RquestParam就是为了让我们更好的邦定请求参数值，因为我们可以主动的定义请求参数对应的名字
	@RequestMapping("/requestparam")
	public String requestparam(String username) {
		System.out.println(username);
		return "success";
	}
	
	@RequestMapping("/requestparam1")//参数中没有username 就会400错误 也就是说默认的是必须存在 required=true 并且默认value='"username"
	public String requestparam1(@RequestParam String username) {
		System.out.println(username);
		return "success";
	}

	@RequestMapping("/requestparam2")//同上，显示表示了
	public String requestparam2(@RequestParam("username") String username) {
		System.out.println(username);
		return "success";
	}

	@RequestMapping("/requestparam3")//同上，显示表示了
	public String requestparam3(
			@RequestParam(value = "username", required = true) String username) {
		System.out.println(username);
		return "success";
	}

	@RequestMapping("/requestparam4")//这里username参数就可有可无了，如果没有username的话，系统会给一个默认值null
	public String requestparam4(
			@RequestParam(value = "username", required = false) String username) {
		System.out.println(username);
		return "success";
	}

	@RequestMapping("/requestparam5")//必须要有username，如果参数中没有username，那么就自动生成一个username，值为默认的
	public String requestparam5(
			@RequestParam(value = "username", required = true, defaultValue = "#{systemProperties['java.vm.version']}") String username) {
		System.out.println(username);
		return "success";
	}

	@RequestMapping("/requestparam6")
	public String requestparam6(@RequestParam(value = "role") String roleList) {
		System.out.println(roleList);
		return "success";
	}

	@RequestMapping("/requestparam7")//显然这里接受的是一个数组数据
	public String requestparam7(@RequestParam(value = "role") String[] roleList) {
		System.out.println(Arrays.toString(roleList));
		return "success";
	}

	@RequestMapping("/requestparam8")//显然这里可以接受的是一个list
	public String requestparam8(@RequestParam(value = "list") List<Integer> list) {
		System.out.println(list);
		return "success";
	}

	@RequestMapping("/requestparam9")//这里就出问题了，Map最为灵活，它需要邦定在对象上使用，因为你不确定Map是否可以转型成功
	public String requestparam9(
			@RequestParam(value = "map") Map<String, String> map) {
		System.out.println(map);
		return "success";
	}
}
