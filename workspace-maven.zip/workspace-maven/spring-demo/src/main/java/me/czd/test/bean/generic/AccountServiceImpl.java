package me.czd.test.bean.generic;

public class AccountServiceImpl extends BaseServiceImpl<Account> {

	@Override
	public Account get() {
		return new Account(17,"name");
	}
	
}
