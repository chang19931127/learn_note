package me.czd.test.ioc.listener;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/*
 * 这里是测试  我们Spring 提供的 监听器
 * 
 * 首先 你需要知道的所有东西
 * 							1，使用Spring 提供的ApplicationContextEvent  来帮你创建一个事件，因为这个事件要被特定的监听器监听
 * 							2，使用Spring提供的ApplicationListener<ApplicationEvent>   来帮我们创建一个可以监听事件的监听器类
 * 							3，使用Spring提供的ApplicationContextAware 来帮你创建一个可以发出事件的类，
 * 																																			然后在这个类的方法中去通知监听器
 * 
 * 
 * 还有一个这个类   ApplicationEventPublisher 专门用来注册事件      必定有一个集合 存储各种事件
 * 																											当然监听器也有一个集合来存储，
 * 							因为一个事件必须对应一个监听器
 */
public class Main {
	public static void main(String[] args) {
		String configLocation = "beanfactory/beans_listener.xml";
		ApplicationContext ctx = new ClassPathXmlApplicationContext(configLocation);
		
		MailSender mailSender = ctx.getBean("mailSender", MailSender.class);
		mailSender.sendMail("541398591@qq.com");
	}
}
