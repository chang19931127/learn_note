package me.czd.spring.spring_in_action.lifecycle;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * 配置类 这里通过@Bean 应为类中没有加 注解
 * 
 * @author 43994897
 *
 */
@Configuration
@ComponentScan
public class LifyCycleConfig {

    @Bean(initMethod = "init", destroyMethod = "destory")//相当于使用配置spring自己提供的
    BeanWayService beanWayService() {
	return new BeanWayService();
    }

    @Autowired
    JSR250WayService jsr250WayService;
}
