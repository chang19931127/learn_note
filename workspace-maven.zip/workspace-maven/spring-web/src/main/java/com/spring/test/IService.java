package com.spring.test;

public interface IService<T> {

	void add(T t);
}
