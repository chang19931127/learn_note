package me.czd.webservice.adapter;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.annotation.adapters.XmlAdapter;

import me.czd.webservice.entity.Role;

/*
 * 适配器
 * 将能接受的数组，转化成不能接受的Map
 * 这里就是使用数组来存储一个对象，这个对象就是Map的Entry
 */
public class MapAdapter extends XmlAdapter<MyRole[], Map<String, List<Role>>> {

	@Override
	public Map<String, List<Role>> unmarshal(MyRole[] v) throws Exception {
		Map<String , List<Role>> map = new HashMap<String, List<Role>>();
		for (int i = 0; i < v.length; i++) {
			MyRole r = v[i];
			map.put(r.getKey(), r.getValue());
		}
		return map;
	}

	@Override
	public MyRole[] marshal(Map<String, List<Role>> v) throws Exception {
		MyRole[] roles = new MyRole[v.size()];
		int i = 0;
		for (String	 key : v.keySet()) {
			roles[i] = new MyRole();
			roles[i].setKey(key);
			roles[i].setValue(v.get(key));
			i++;
		}
		return null;
	}

}
