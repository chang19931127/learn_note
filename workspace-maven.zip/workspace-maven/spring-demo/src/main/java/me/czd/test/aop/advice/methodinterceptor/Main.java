package me.czd.test.aop.advice.methodinterceptor;

import me.czd.test.aop.advice.beforeadvice.Waiter;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

//这里是测试环绕通知的，其实环绕通知就和我们的  动态代理 代理很像，我们随意添加增强
public class Main {
		@Test
		public void test2(){
			String configLocation = "beanfactory/beans_around.xml";
			ApplicationContext ctx = new ClassPathXmlApplicationContext(configLocation);
			//这里就是我们之前的    FactoryBean        -----------就是可以直接 得到bean
			//--------------------ProxyFactoryBean
			Waiter waiter = (Waiter) ctx.getBean("waiter");
			waiter.greetTo("John");
		}
}
