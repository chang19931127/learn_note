package me.czd.test.aop.advice.afteradvice;

import java.lang.reflect.Method;

import org.springframework.aop.AfterReturningAdvice;

/*
 * 后置增强！！！！！！！！
 * 我们要实现一个接口  AfterReturningAdvice  ............
 */
public class GreetingAfterAdvice implements AfterReturningAdvice{

	/**
	 * @param   	returnObj
	 * 	为目标实例方法返回的结果
	 * @param	method
	 * 为目标类的方法
	 * @param	args
	 * 为目标实例的方法如参
	 * @param	obj
	 * 为目标实例
	 */
	@Override
	public void afterReturning(Object returnValue, Method method,
			Object[] args, Object target) throws Throwable {
		System.out.println("Please enjoy yourself!!!!!!!");
	}

}
