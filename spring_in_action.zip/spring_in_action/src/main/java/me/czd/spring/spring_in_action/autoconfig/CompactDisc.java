package me.czd.spring.spring_in_action.autoconfig;

/**
 * 接口
 * @author 43994897
 *
 */
public interface CompactDisc {
    void play();
}
