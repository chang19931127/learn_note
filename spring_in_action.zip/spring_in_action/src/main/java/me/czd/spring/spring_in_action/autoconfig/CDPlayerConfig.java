package me.czd.spring.spring_in_action.autoconfig;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * spring java 配置类
 * 其实也是一个组件
 * @author 43994897
 *
 */
@Configuration
@ComponentScan//扫当前包
public class CDPlayerConfig {
    /**
     * 这里也可以通过xml 来进行配置
     */
}
