package com.example.demo.websocket;

/**
 * 浏览器向服务器发送的消息，用于接收 
 * @author 43994897
 *
 */
public class WiselyMessage {

    private String name;

    public String getName() {
	return name;
    }

}
