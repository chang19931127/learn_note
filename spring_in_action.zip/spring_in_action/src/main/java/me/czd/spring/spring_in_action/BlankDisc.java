package me.czd.spring.spring_in_action;

/**
 * Disc实体类
 * 
 * @author 43994897
 *
 */
public class BlankDisc {
    private String title;
    private String artist;

    public BlankDisc() {
	super();
    }

    public BlankDisc(String title, String artist) {
	super();
	this.title = title;
	this.artist = artist;
    }

    @Override
    public String toString() {
	return "title:" + title + "artist:" + artist;
    }

}
