package me.czd.spring.spring_in_action.event;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

/**
 * 事件发布类
 * 利用spring application 容器来进行事件的发布，然后被事件监听者去发现！
 * @author 43994897
 *
 */
@Component
public class DemoPublisher {

    @Autowired
    ApplicationContext applicationContext;
    
    public void publish(String msg){
	applicationContext.publishEvent(new DemoEvent(this, msg));
    }
}
