package me.czd.test.aop.advice.beforeadvice;

import org.junit.Test;
import org.springframework.aop.BeforeAdvice;
import org.springframework.aop.framework.ProxyFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

//前置增强的 测试
public class Main {
	@Test
	public void  test1() {
		//有一个 服务生，也就是目标类
		Waiter target  = new NalveWaiter();
		
		//创建一个增强
		BeforeAdvice advice = new GreetingBeforeAdvice();
		
		ProxyFactory pf = new ProxyFactory();
		pf.setTarget(target);//添加代理目标
		pf.addAdvice(advice);//添加代理增强
		
		//这里就是添加了礼貌用语的服务生代理类
		Waiter proxy = (Waiter) pf.getProxy();
		proxy.greetTo("John");
		proxy.serveTo("Tom");	
		/*
		 * ProxyFactory这个类里面有很多可以选择  优化的
		 * pf.setInterfaces()    指定对接口进行代理
		 * pf.setOptimize()    启动优化
		 */
	}
	
	/*
	 * 这里是通过传统的配置spring  xml的方式  进行了   aop   目标类的增强，
	 * 使用的是ProxyFactoryBean 类
	 */
	@Test
	public void test2(){
		String configLocation = "beanfactory/beans.xml";
		ApplicationContext ctx = new ClassPathXmlApplicationContext(configLocation);
		//这里就是我们之前的    FactoryBean        -----------就是可以直接 得到bean
		//--------------------ProxyFactoryBean
		Waiter waiter = (Waiter) ctx.getBean("waiter");
		waiter.greetTo("John");
	}
}
