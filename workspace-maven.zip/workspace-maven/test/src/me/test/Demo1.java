package me.test;

public class Demo1 {
	private Demo1() {
	}

	private static Demo1 demo = new Demo1();
	
	public static Demo1 getNewInstance() {
		return demo;
	}

	public static void main(String[] args) {
		System.out.println( Demo1.getNewInstance());
		System.out.println(Demo1.getNewInstance());
		System.out.println(Demo1.demo);
	}
}
