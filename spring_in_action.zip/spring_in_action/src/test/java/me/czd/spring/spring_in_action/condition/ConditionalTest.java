package me.czd.spring.spring_in_action.condition;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * 测试类 
 * @author 43994897
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = ConditionConfig.class)
public class ConditionalTest {
    
    @Autowired
    private ApplicationContext context ;
    
    @Autowired
    private ListService listService;
 
    @Test
    public void test(){
	System.out.println(context.getEnvironment().getProperty("os.name") + "系统下的列表命令是"+listService.showListCmd());
    }

}
