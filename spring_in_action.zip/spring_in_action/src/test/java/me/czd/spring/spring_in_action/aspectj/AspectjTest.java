package me.czd.spring.spring_in_action.aspectj;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * 测试类
 * 
 * @author 43994897
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = AopConfig.class)
public class AspectjTest {
    @Autowired
    private AnntationService anntationService;
    
    @Autowired
    private MethodService methodService;
    
    @Test
    public void test(){
	anntationService.add();
	methodService.add();
    }
}
