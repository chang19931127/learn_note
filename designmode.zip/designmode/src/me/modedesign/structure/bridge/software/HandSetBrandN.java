package me.modedesign.structure.bridge.software;

/*
 * ������ֻ�Ʒ�� n
 */
public class HandSetBrandN extends HandSetBrand {

	@Override
	public void run() {
		soft.run();
	}
	
}
