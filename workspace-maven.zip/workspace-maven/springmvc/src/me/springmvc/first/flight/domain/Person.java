package me.springmvc.first.flight.domain;

/*
 * 这里的一个bean，目的是为了进行数据邦定
 * 进行传递！
 */
public class Person {
	private String name;
	private int age;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
}
