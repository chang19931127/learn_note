package me.tag;

import java.io.IOException;
import java.util.Collection;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.SimpleTagSupport;

/*
 * jsp2.0中标签也被简单化，直接继承SimpleTagSupport
 * 其他就是，tld文件，加载，jsp引入
 * 
 * SimpleTagSupport其实就是针对SampleTag接口的实现
 */
public class SimpleTag extends SimpleTagSupport {
	private String bean;// 标签属性

	public String getBean() {
		return bean;
	}

	public void setBean(String bean) {
		this.bean = bean;
	}

	@Override
	public void doTag() throws JspException, IOException {
		Collection<String> itemList = (Collection<String>) getJspContext()
				.getAttribute(bean);
		for (String string : itemList) {
			getJspContext().setAttribute("item", string);
			getJspBody().invoke(null);
		}
	}

}
