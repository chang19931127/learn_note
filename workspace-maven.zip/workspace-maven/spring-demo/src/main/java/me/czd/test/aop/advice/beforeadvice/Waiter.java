package me.czd.test.aop.advice.beforeadvice;

//服务员接口
public interface Waiter {
	void greetTo(String name);

	void serveTo(String name);
}
