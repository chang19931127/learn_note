package me.czd.test.aspectj.simple;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

//通过注解标示一个切面
@Aspect
public class PreGreetingAspect {

	// 通过注解定义切点和增强类型
	/*
	 * execution(返回值 方法名 参数)
	 * 关键字-------------------			操作参数														含义
	 * execution									* * *   	方法匹配模式串							目标类方法匹配
	 * @annotation							注解	方法注解类名								标注特定注解的
	 * args											类		类名		
	 * @args                                   
	 * within 
	 * target
	 * @within
	 * @target
	 * this
	 */
	
	//这里运用的是匿名  切点
	@Before(value = "execution(* greetTo(..))&&args(name)")
	public void beforeGreeting(String name) {
		System.out.println("增强中通过参数邦定获取到了连接点传过来的参数name:"+name);
		System.out.println("How are you!!!!!");
	}
}
