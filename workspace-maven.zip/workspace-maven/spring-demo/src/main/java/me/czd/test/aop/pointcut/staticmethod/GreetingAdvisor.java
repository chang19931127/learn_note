package me.czd.test.aop.pointcut.staticmethod;

import java.lang.reflect.Method;

import org.springframework.aop.ClassFilter;
import org.springframework.aop.support.StaticMethodMatcherPointcutAdvisor;

/*
 * 切面类，当然切面类，是要包含切点和增强的
 * 
 * 这里我们继承的是静态普通方法切面   StaticMethodMatcherPointcutAdvisor
 * 
 * 这里我们弄了两个匹配规则，	第一个就是matchers方法，
 * 																		第二个就是ClassFilter，类过滤
 */
public class GreetingAdvisor extends StaticMethodMatcherPointcutAdvisor {

	private static final long serialVersionUID = 7523754298775410868L;

	@Override
	public boolean matches(Method method, Class<?> targetClass) {
		return "greetTo".equals(method.getName());
	}

	// 切点类匹配规则：为Waiter的类或子类
	@Override
	public ClassFilter getClassFilter() {
		return new ClassFilter() {

			@Override
			public boolean matches(Class<?> clazz) {
				// 判定此 Class 对象所表示的类或接口与指定的 Class 参数所表示的类或接口是否相同，或是否是其超类或超接口。
				return Waiter.class.isAssignableFrom(clazz);
			}
		};
	}

}
