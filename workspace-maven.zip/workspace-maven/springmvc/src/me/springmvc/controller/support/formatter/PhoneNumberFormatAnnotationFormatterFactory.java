package me.springmvc.controller.support.formatter;

import java.util.HashSet;
import java.util.Set;

import me.springmvc.annotation.model.PhoneNumberModel;

import org.springframework.format.AnnotationFormatterFactory;
import org.springframework.format.Formatter;
import org.springframework.format.Parser;
import org.springframework.format.Printer;

/*
 * 这里就是我们的注解-----------------针对的解决类
 * 														自定义注解，格式化
 * 																							1，首先我们要有一个格式化的bean PhoneNumberModel
 * 																							2，之后我们要有一个格式化类PhoneNumberFormatter
 * 																																										实现Formatter<PhoneNumberModel> 
 * 																							3，其次我们要有一个注解PhoneNumber
 * 																							4，最后我们要有一个注解处理类PhoneNumberFormatAnnotationFormatterFactory
 * 																																										实现AnnotationFormatterFactory<PhoneNumber>
 * 														之后就可以测试了
 */
public class PhoneNumberFormatAnnotationFormatterFactory implements AnnotationFormatterFactory<PhoneNumber> {

	//指定可以解析/格式化的字段注解类型
	//我们的final字段选择在构造函数中初始化
	//并且在构造函数中，为我们的泛型进行   确定化
	private final Set<Class<?>> fieldTypes ;
	private final PhoneNumberFormatter formatter;
	@Override
	
	
	public Set<Class<?>> getFieldTypes() {
		// TODO Auto-generated method stub
		return fieldTypes;
	}

	public PhoneNumberFormatAnnotationFormatterFactory() {
		Set<Class<?>> set = new HashSet<Class<?>>();
		set.add(PhoneNumberModel.class);
		this.fieldTypes = set;
		this.formatter = new PhoneNumberFormatter();
	}

	@Override
	public Printer<?> getPrinter(PhoneNumber annotation, Class<?> fieldType) {
		// TODO Auto-generated method stub
		return formatter;
	}

	@Override
	public Parser<?> getParser(PhoneNumber annotation, Class<?> fieldType) {
		// TODO Auto-generated method stub
		return formatter;
	}

}
