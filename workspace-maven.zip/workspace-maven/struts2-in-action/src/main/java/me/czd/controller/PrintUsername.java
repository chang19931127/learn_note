package me.czd.controller;

/**
 * 
 * @author 43994897
 *	一个Controller  用来测试我们的拦截器
 */
public class PrintUsername {
	private String username;
	
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String execute(){
		System.out.println("PrintUsername execute() !!!    username="+username);
		return "toPrintUsernameJSP";
	}
}
