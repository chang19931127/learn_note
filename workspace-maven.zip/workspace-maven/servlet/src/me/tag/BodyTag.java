package me.tag;

import java.io.IOException;
import java.util.List;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.BodyTagSupport;

/*
 * 介绍了简单的，和属性的
 * 这里我们就该了解带有标签体的标签了
 * 带有标签体的标签
 * 										继承BodyTagSupport
 * 													BodyTagSupport继承了TagSupport类
 * 需要两个方法doAfterBody()和doInitBody()方法
 * 带有标签体的标签肯定不止一个处理类，因为一个标签类仅处理一个标签
 * 仔细看看
 * 
 * 我们通过这个例子来实现一个 具有迭代功能的标签
 */
public class BodyTag extends BodyTagSupport {
	//标签要迭代的集合的对象名
	private String bean;
	//集合对象的元素
	private String item;
	//集合当前的索引
	private int i = 0;
	private int size;
	private List<String> itemList;
	//get set
	public String getBean() {
		return bean;
	}
	public void setBean(String bean) {
		this.bean = bean;
	}
	public String getItem() {
		return item;
	}
	public void setItem(String item) {
		this.item = item;
	}
	//开始处理标签时，调用该方法
	@Override
	public int doStartTag() throws JspException {
		itemList = (List<String>) pageContext.getAttribute(bean);
		size = itemList.size();
		pageContext.setAttribute(item, itemList.get(i));
		//需要处理标签体
		return EVAL_BODY_BUFFERED;
	}
	@Override
	public int doAfterBody() throws JspException {
		i++;
		if(i >= size){
			i=0;
			return SKIP_BODY;
		}
		pageContext.setAttribute(item, itemList.get(i));
		return EVAL_BODY_AGAIN;
	}
	@Override
	public int doEndTag() throws JspException {
		try {
			bodyContent.writeOut(pageContext.getOut());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return EVAL_PAGE;
	}
	
	
}
