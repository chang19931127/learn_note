package me.czd.extconverter;

import java.util.Map;

import me.czd.entity.Point;

import org.apache.struts2.util.StrutsTypeConverter;

/**
 * 
 * @author 43994897
 *	这是一个自定义转换类 数据类型转换器
 *	这里是局部的类型转换器
 *	然后再全局应用这个转换器，需要借助于properties文件
 *	我们是应用于特定类，因此在特定类目录下
 */
public class PointConverter	extends StrutsTypeConverter {

	@Override
	public Object convertFromString(Map context, String[] values, Class toClass) {
		System.out.println("执行了 convertFromString");
		String[] pointArray = values[0].split(",");
		Point point = new Point();
		point.setX(pointArray[0]);
		point.setY(pointArray[1]);
		return point;
	}

	@Override
	public String convertToString(Map context, Object o) {
		System.out.println("执行了converterToString");
		return ((Point)o).toString();
	}

}
