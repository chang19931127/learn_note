package me.czd.test.aop.advice.introducted;

import org.aopalliance.intercept.MethodInvocation;
import org.springframework.aop.support.DelegatingIntroductionInterceptor;

/*
 * 这里是另外一种增强，引介增强，
 * 					什么是引介增强，引介增强，是类级别的，为我们的目标类添加一个接口的实现，
 * 									就是原来目标类未实现某个接口，通过引介增强可以为目标类创建实现某接口的代理
 * 
 * 这里就是一个引介增强，好好去看下他的结构
 * 
 * spring 提供了一个接口 IntroductionInterceptor,和DelegatingIntroductionInterceptor
 */
public class ControllablePerformanceMonitor extends DelegatingIntroductionInterceptor implements Monitorable{

	private static final long serialVersionUID = -7358322394089873031L;
	private ThreadLocal<Boolean> monitorStatusMap = new ThreadLocal<Boolean>();
	@Override
	public void setMonitorActive(boolean active) {
		monitorStatusMap.set(active);
	}
	
	//引介代理执行方法        这里有一个逻辑就是判断，是否开启监控功能
	@Override
	public Object invoke(MethodInvocation mi) throws Throwable {
		Object obj = null;
		//对于支持性能监视可控代理，通过判断其状态是否可开启性能监控功能
		if(monitorStatusMap.get() != null && monitorStatusMap.get()){
			PerformanceMonitor .begin(mi.getClass().getName()+"."+mi.getMethod().getName());
			obj = super.invoke(mi);
			PerformanceMonitor.end();
		}else{
			obj=super.invoke(mi);
		}
		return obj;
	}
	
	
	
}
