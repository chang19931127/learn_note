package com.example.demo.cache;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.example.demo.datajpa.Person;
import com.example.demo.datajpa.PersonRepository;

/**
 * CacheService 的实现类
 * 
 * Spring 为了缓存提供了一套注解
 * 
 * @CachePut 加入缓存，或更新缓存
 * @CacheEvict 从缓存中移出
 * @Cacheable 将这个数据缓存
 * 
 *            其实都是通过 aop 来进行缓存的使用
 * 
 * @author 43994897
 *
 */
@Service
public class CacheServiceImpl implements CacheService {

    @Autowired
    private PersonRepository personRepository;

    @Override
    @CachePut(value = "people", key = "#person.id")
    public Person save(Person person) {
	Person p = personRepository.save(person);
	System.out.println("为id，key 为：" + p.getId() + "数据作了缓存");
	return p;
    }

    @Override
    @CacheEvict(value = "people")
    public void remove(Long id) {
	System.out.println("删除了id，key为" + id + "的数据缓存");
	personRepository.delete(id);
    }

    @Override
    @Cacheable(value = "people", key = "#person.id")
    public Person findOne(Person person) {
	Person p = personRepository.findOne(person.getId());
	System.out.println("为id，key为：" + p.getId() + "数据做了缓存");
	return p;
    }

}
