package me.springmvc.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.core.NamedThreadLocal;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

/*
 * 这里这个拦截器就是一个具体的应用，--------------来记录时间的，一个页面或者一个请求处理时间
 * ！！！！！！！！！！！！首先拦截器是单例！！！！！！！！！！！！！！！！！！！！！！！
 * 	----------------------------------------------单例如何解决线程安全问题--------------------------------------------------------------
 * ----------------------------------------------ThreadLocal模式来解决--------------------------------------ThreadLocal邦定当前线程
 */
public class StopWatchHandlerInterceptor implements HandlerInterceptor {
	
	//这个NameThreadLocal是ThreadLocal的子类
	private NamedThreadLocal<Long> startTimeThreadLocal = new NamedThreadLocal<>("StopWatch-StartTime");
	
	@Override
	public boolean preHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler) throws Exception {
		//1，开始时间
		long beginTime = System.currentTimeMillis();
		//线程邦定变量(导致该数据仅被当前线程所共享)
		startTimeThreadLocal.set(beginTime);
		//继续流程
		return true;
	}

	@Override
	public void postHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		//无作为
	}

	@Override
	public void afterCompletion(HttpServletRequest request,
			HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		//2，结束时间
		long endTime = System.currentTimeMillis();
		//得到线程邦定的局部变量(开始时间)
		long beginTime = startTimeThreadLocal.get();
		//消耗的时间
		long consumeTime = endTime - beginTime;
			System.out.println(String.format("%s consume %d millis", request.getRequestURI(),consumeTime));
	}

}
