package me.czd.service;

/*
 * 登陆信息的 Service
 */
public class UserinfoService {
	public boolean login(String username, String password) {
		if ("sa".equals(username) && "sa".equals(password))
			return true;
		return false;
	}
}
