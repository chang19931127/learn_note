package me.czd.test.bean.context;

import me.czd.test.bean.Beans;
import me.czd.test.bean.Car;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * 
 * @author 43994897
 *	这里我们进行ApplicationContext
 * 	我们开发人员一般直接接触的就是ApplicationContext
 * 	主要是ApplicationContext提供了更多的内容，帮助开发者
 * 	例如这里我们的注册不再使用配制文件，而是使用一个类@Configuration
 */
public class AnnotationApplicationContext {
	public static void main(String[] args) {
		//1，通过一个带有@Configuration的POJO装载Bean配置
		ApplicationContext ctx =new AnnotationConfigApplicationContext(Beans.class);
		Car car = ctx.getBean("car", Car.class);
		System.out.println("car:"+car);
	}
}
