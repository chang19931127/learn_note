package me.czd.test.ioc.replace;

import java.lang.reflect.Method;

import me.czd.test.bean.Car;

import org.springframework.beans.factory.support.MethodReplacer;

public class Boss2 implements MethodReplacer {

	@Override
	public Object reimplement(Object obj, Method method, Object[] args)
			throws Throwable {
		Car car = new Car();
		car.setBrand("捷豹");
		return car;
	}

}
