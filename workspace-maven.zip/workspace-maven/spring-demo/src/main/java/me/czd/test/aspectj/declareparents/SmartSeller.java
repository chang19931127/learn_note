package me.czd.test.aspectj.declareparents;

/*
 * Seller实现类
 */
public class SmartSeller implements Seller {

	@Override
	public void sell(String string, String string1) {
		System.out.println("SmartSell:sell " + string + " to " + string1);
	}

}
