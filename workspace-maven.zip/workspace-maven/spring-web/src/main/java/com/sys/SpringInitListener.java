package com.sys;

import javax.servlet.ServletContextEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.context.ContextLoaderListener;

@Slf4j
public class SpringInitListener extends ContextLoaderListener {

	public void contextInitialized(ServletContextEvent event) {
		super.contextInitialized(event);
		log.info("contextInitialized");
	}
	
	public void contextDestroyed(ServletContextEvent event) {
		super.contextDestroyed(event);
		log.info("contextDestroyed");
	}
	
}
