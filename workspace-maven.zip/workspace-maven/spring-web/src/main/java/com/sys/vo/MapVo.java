package com.sys.vo;

import java.util.Map;
import lombok.Data;
@Data
public class MapVo {

	private Map<String, Object> map;
}
