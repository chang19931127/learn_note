package com.example.demo.websocket;

/**
 * 服务器向浏览器发送的消息，也就是相应，广播的
 * @author 43994897
 *
 */
public class WiselyResponse {
    private String responseMessage;

    public WiselyResponse(String responseMessage) {
	super();
	this.responseMessage = responseMessage;
    }


    public String getResponseMessage() {
        return responseMessage;
    }
    
    
}
