package me.czd;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.sql.DataSource;

import org.junit.BeforeClass;
import org.junit.Test;
/*
 *  jdbc l连接Derby数据库的测试类
 */
public class DerbyTest {
	private static String driver = "org.apache.derby.jdbc.EmbeddedDriver";// 嵌套驱动
	// private static String driver =
	// "org.apache.derby.jdbc.ClientDriver";//网络模式驱动
	private static String protocol = "jdbc:derby:c:/users/43994897/mydb;user=root;password=root";// url
	
	@BeforeClass
	public static void loadDriver(){
		try {
			Class.forName(driver).newInstance();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public  void test(){
		DerbyTest derby = new DerbyTest();
		derby.getDataFormDerby();
		System.out.println(DataSource.class);
	}


	public  void getDataFormDerby() {
		try {
			Connection conn = DriverManager.getConnection(protocol);
			Statement statement = conn.createStatement();
			// statement.execute("create table t_user(name varchar(40),password varchar(40))");
			// statement.execute("insert into t_user values('Richard','richard')");
			// statement.execute("insert into t_user values('James','james')");
			// statement.execute("insert into t_user values('Black','black')");
			ResultSet resultSet = statement
					.executeQuery("select  *  from  t_user");
			while (resultSet.next()) {
				System.out.println(resultSet.getString(1));
				System.out.println(resultSet.getString(2));
			}
			resultSet.close();
			statement.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
