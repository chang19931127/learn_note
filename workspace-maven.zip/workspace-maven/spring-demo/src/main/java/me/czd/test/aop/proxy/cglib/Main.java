package me.czd.test.aop.proxy.cglib;

import me.czd.test.aop.proxy.jdk.ForumServiceImpl;
import me.czd.test.aop.proxy.ordinary.ForumService;

//Cglib的测试
public class Main {
	public static void main(String[] args) {
		CglibProxy proxy = new CglibProxy();
		//这里是得到的类的       代理
		ForumService forumService = (ForumService) proxy.getProxy(ForumServiceImpl.class);
		forumService.removeForum(10);
		System.out.println("-------------------------------------------------------------");
		forumService.removeTopic(1010);
		//可以通过这里 发现  使用的类  发生了变化
	}
}
