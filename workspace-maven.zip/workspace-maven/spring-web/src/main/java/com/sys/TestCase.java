package com.sys;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import com.spring.test.UserVo;
import com.sys.service.IUserService;
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"classpath:appconfig.xml"})
public class TestCase {
	
	@Autowired
	private IUserService userService;
	
	@Test
	public void test() {
		UserVo vo = new UserVo();
		vo.setId(1);
		vo.setName("json jackson");
		userService.add(vo);
	}
	
}
