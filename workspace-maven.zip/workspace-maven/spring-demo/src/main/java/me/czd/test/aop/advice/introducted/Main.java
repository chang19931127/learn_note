package me.czd.test.aop.advice.introducted;

import org.junit.Test;
import org.springframework.aop.framework.ProxyFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/*
 * 引介增强，发现没，我们代理的时候，我们代理的实现类还实现了一个接口，这个厉害了吧
 * 哈哈，因此引介增强是基于类的，可以帮助我们代理一个类并且实现接口
 */
public class Main {
	public static void main(String[] args) {
		
		/*
		 * 好好理解一下这些内容吧
		 * ProxyFactory						---------这就使一个代理工厂
		 * ProxyFactoryBean            	---------这就是帮助我们创建bean-------------
		 * 													FactoryBean 就是为了让我们xml里面注册bean方便按照我们的想法生成bean
		 */
		ForumServiceImpl forumService = new ForumServiceImpl();
		
		ControllablePerformanceMonitor cpm = new ControllablePerformanceMonitor();
		ProxyFactory pf = new ProxyFactory();
		pf.setInterfaces(Monitorable.class);
		pf.setTarget(forumService);
		pf.addAdvice(cpm);
		pf.setProxyTargetClass(true);
		
		forumService.removeForum(10);
		forumService.removeTopic(1010);
		
		ForumService proxy = (ForumService) pf.getProxy();
		
		//这里我们打开开关
		Monitorable moniterable = (Monitorable) proxy;
		moniterable.setMonitorActive(true);
		
		
		System.out.println(proxy.getClass());
		proxy.removeForum(10);
		proxy.removeTopic(1010);
	}
	
	@Test
	public void test1(){
		String configLocation = "beanfactory/beans.xml";
		ApplicationContext ctx = new ClassPathXmlApplicationContext(configLocation);
		ForumService forumService = (ForumService) ctx.getBean("forumService");
		forumService.removeForum(10);
		forumService.removeTopic(1010);
		
		Monitorable moniterable = (Monitorable) forumService;
		moniterable.setMonitorActive(true);
		
		forumService.removeForum(10);
		forumService.removeTopic(1010);
	}
}
