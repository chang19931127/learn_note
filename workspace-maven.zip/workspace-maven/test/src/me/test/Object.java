package me.test;

/*
 * 通过Debug 可以看出来  子类 拥有父类的属性，如果属性字段相同的话，那么就隐藏父类字段
 */
public class Object {
	public static void main(String[] args) {
		Man p = new Man();
		System.out.println("Man . name"+p.name);
		System.out.println("Man ---> Person . name"+((Person)p).name);
		
		p.show();
		((Person)p).show();
	}
}

class Person{
	public String name ="Person" ;
	
	public void show(){
		System.out.println("this is Person name ");
	}
}

class Man extends Person{
	public String first = "JACK";
	public String name = "Man";
	
	public void show(){
		System.out.println("this is Man name");
	}
	
	public void go(){
		System.out.println("this is Man practice method");
	}
}