package me.springmvc.consumesproduces.contenttype;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.charset.Charset;

import org.springframework.http.HttpMethod;
import org.springframework.http.client.ClientHttpRequest;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.http.client.SimpleClientHttpRequestFactory;

public class ResposneContentTypeClient {
	public static void main(String[] args) throws IOException, URISyntaxException {
		xmlRequest();
		jsonRequest();
	}
	
	private static void xmlRequest() throws IOException, URISyntaxException{
		//请求地址
		String url = "http://localhost:8080/springmvc/app/response/ContentType";
		//1，创建Http Request
		ClientHttpRequest request = new SimpleClientHttpRequestFactory().createRequest(new URI(url), HttpMethod.POST);
		//2，设置客户端可接受的媒体类型
		request.getHeaders().set("Accept", "application/xml");
		//3，发送请求并得到响应
		ClientHttpResponse response = request.execute();
		//4，得到响应体的编码方式
		Charset charset = response.getHeaders().getContentType().getCharset();
		//5，得到响应体的内容
		InputStream is = response.getBody();
		byte[] bytes=new byte[(int) response.getHeaders().getContentLength()];
		is.read(bytes);
		String xmlData = new String(bytes,charset);
		System.out.println("charset:"+charset+",xml data :"+xmlData);
	}
	private static void jsonRequest() throws IOException, URISyntaxException{
		String url = "http://localhost:8080/springmvc/app/response/ContentType";
		ClientHttpRequest request = new SimpleClientHttpRequestFactory().createRequest(new URI(url), HttpMethod.POST);
		request.getHeaders().set("Accept", "application/json");
		ClientHttpResponse response = request.execute();
		Charset charset = response.getHeaders().getContentType().getCharset();
		InputStream is = response.getBody();
		byte[] bytes=new byte[(int) response.getHeaders().getContentLength()];
		is.read(bytes);
		String jsonData = new String(bytes,charset);
		System.out.println("charset:"+charset+",json data :"+jsonData);
	}
}
