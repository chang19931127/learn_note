package me.czd.test.ioc.replace;

import me.czd.test.bean.Car;
import me.czd.test.ioc.lookup.Boss;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;




/*
 * 我们 在 工厂中注册了  
 * Boss1                	---------就是一个简单的Boos1   里面有一个方法，getCar    得到宝马Z4
 * Boss2					---------一个实现了MethodReplacer接口的Boss2 
 * 
 * 经过某些配制后，我们通过Boos1 .getCar 得到的    是捷豹....嘿嘿嘿，被莫名的乾坤大挪移
 * 一般平常不怎么使用，
 * 
 * 
 * 
 * 
 * 平常使用最多的还是     属性注入，构造函数注入.................
 * 
 */

public class Main {
	//这里就是用来测试的
	public static void main(String[] args) {
		ApplicationContext ac = new  ClassPathXmlApplicationContext("beanfactory/beans_replace.xml");
		Boss1 boss1 = ac.getBean("boss1", Boss1.class);
		Car car2 = boss1.getCar();
		System.out.println(car2);
		//Boos1 从宝马变成了捷豹
	}
}
