package com.spring.test;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ServiceImpl implements IService<UserVo> {

	public void add(UserVo t) {
		log.info(t.toString());
	}

}
