package me.cn;

import java.applet.Applet;
import java.awt.Color;
import java.awt.Graphics;

/*
 * 虽说不用Applet 。但是我们这里了解一下
 */
public class Hello  extends Applet	{
	//重写paint 方法 ，该方法将在Applet上绘图
	public void paint(Graphics g){
		g.drawString(getParameter("hello"), 20, 30);//画字符串
		g.setColor(new Color(255,200,200));//设置颜色
		g.fillRect(50, 60, 200, 150);//画矩形
	}
}
