package me.czd.main;

import me.czd.dbutils.MybatisUtils;
import me.czd.orm.Userinfo;

import org.apache.ibatis.session.SqlSession;
import org.junit.Test;

public class Main {
	public static void main(String[] args) {
		SqlSession sqlSession = MybatisUtils.getSqlSession();
		Userinfo userinfo = sqlSession.selectOne("me.czd.orm.UserinfoMapper.getUserinfoById",2);
		System.out.println(userinfo.getUsername());
	}
	
	@Test
	public void test(){
		SqlSession sqlSession = MybatisUtils.getSqlSession();
		Userinfo userinfo = sqlSession.selectOne("me.czd.orm.UserinfoMapper.getUserinfoById",2);
		System.out.println(userinfo.getUsername());
	}
}
