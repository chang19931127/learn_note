package me.czd.entity;

import lombok.Data;

/**
 * 
 * @author 43994897
 *	实体bean
 */
@Data
public class Point {
	private String x;
	private String y;

}
