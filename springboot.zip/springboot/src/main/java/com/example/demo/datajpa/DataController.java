package com.example.demo.datajpa;

import java.util.List;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 
 * JpaData 的Contoller ，我们已经通过JpaConfig 进行了数据的预处理
 * 
 * 都是通过Repository 来进行操作的，数据存储在内存数据库中
 * 
 * 这里我们可以尝试下，看是否可以使用
 * 
 * @author 43994897
 *
 */
@RestController
@RequestMapping("/jpa")
public class DataController {

    @Autowired
    private PersonRepository personRepository;

    @GetMapping("/save")
    public Person save(String name, String address, Integer age) {
	Person p = personRepository.save(new Person(name, age, address));
	return p;
    }

    @GetMapping("/persons")
    public List<Person> queryPeople() {
	List<Person> people = personRepository.findAll();
	return people;
    }

    @GetMapping("/persons/{id}")
    public Person queryPerson(@PathVariable(value = "id") long id) {
	Person people = personRepository.findOne(id);
	return people;
    }

    @GetMapping("/sort")
    public List<Person> sort() {
	List<Person> people = personRepository.findAll(new Sort(Direction.ASC, "age"));
	return people;
    }

    // 分页的内容
    @GetMapping("/page/{id}/{count}")
    public Page<Person> page(@PathVariable(value="id") Integer page, @PathVariable Integer count) {
	Page<Person> pagePeople = null;
	if (page >= 0 && count >= 1 && page != null && count != null) {
	    pagePeople = personRepository.findAll(new PageRequest(page, count));
	} else {
	    pagePeople = personRepository.findAll(new PageRequest(1, (int) personRepository.count()));
	}
	return pagePeople;
    }
}
